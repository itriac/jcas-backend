package jcas.jms.mqtt;

import jcas.jms.model.mode.ModeTransientData;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MqttAgent is the class to send MQTT message to AGV.
 *
 * @author Industrial Technology Research Institute
 */
public class MqttAgent implements MqttCallbackExtended {
  private static final Logger LOGGER = LoggerFactory.getLogger(MqttAgent.class);
  private static MqttAgent instance = new MqttAgent();
  private MqttClient mqttClient;

  private MqttAgent() {

  }

  public static MqttAgent getInstance() {
    return instance;
  }

  /**
   * Subscribes MQTT topic.
   *
   * @param topic The MQTT Topic
   */
  public void executeMqttSubscribe(String topic) {
    initConnection();
    try {
      mqttClient.subscribe(topic);
    } catch (MqttException me) {
      LOGGER.error(me.getMessage());
    }
  }

  /**
   * Publishes MQTT message.
   *
   * @param topic   The MQTT topic
   * @param content The message content
   */
  public void executeMqttPublish(String topic, String content) {
    initConnection();
    try {
      MqttMessage message = new MqttMessage(content.getBytes("UTF-8"));
      mqttClient.publish(topic, message);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    }
  }

  @Override
  public void connectionLost(Throwable cause) {
    LOGGER.warn("MQTT Agent Connection Lost " + cause.getMessage());

  }

  @Override
  public void messageArrived(String topic, MqttMessage message) throws Exception {
    LOGGER.info("MQTT Message Arrived - Topic: " + topic + ", Message: " + message);

    try {
      // 假設消息內容是 JSON 格式
      String payload = new String(message.getPayload(), "UTF-8");
      JSONObject jsonObject = (JSONObject) JSONValue.parse(payload);

      if (topic.equals("k300_dog_1/status")) {
        String status = (String) jsonObject.get("action");
        ModeTransientData.DOG_1_STATUS = status;
        // LOGGER.info("Updated DOG_1_STATUS to: " + status);
      } else if (topic.equals("k300_dog_2/status")) {
        String status = (String) jsonObject.get("action");
        ModeTransientData.DOG_2_STATUS = status;
        // LOGGER.info("Updated DOG_2_STATUS to: " + status);
      }
    } catch (Exception e) {
      LOGGER.error("Error processing MQTT message: " + e.getMessage(), e);
    }
  }

  @Override
  public void deliveryComplete(IMqttDeliveryToken token) {
    // LOGGER.info("MQTT Agent Delivery Complete");

  }

  @Override
  public void connectComplete(boolean reconnect, String serverUri) {
    LOGGER.info("MQTT Agent Connect Complete");

  }

  private void initConnection() {
    String mqttServer = System.getProperty("mqttServer");
    String mqttPort = System.getProperty("mqttPort");
    String mqttAccount = System.getProperty("mqttAccount");
    String mqttPassword = System.getProperty("mqttPassword");
    String mqttBroker = "tcp://" + mqttServer + ":" + mqttPort;

    // for unit testing String mqttServer = "192.168.100.129"; String mqttPort = "1883"; String mqttAccount = "k300";
    // String mqttPassword = "k300test"; String mqttBroker = "tcp://" + mqttServer + ":" + mqttPort;

    MqttConnectOptions connectOptions = new MqttConnectOptions();
    connectOptions.setCleanSession(true);
    connectOptions.setKeepAliveInterval(60000);
    if (mqttAccount != null && !mqttAccount.isEmpty() && mqttPassword != null && !mqttPassword.isEmpty()) {
      connectOptions.setUserName(mqttAccount);
      connectOptions.setPassword(mqttPassword.toCharArray());
    }
    connectOptions.setAutomaticReconnect(true);
    try {
      if (mqttClient == null) {
        mqttClient = new MqttClient(mqttBroker, MqttClient.generateClientId(), new MemoryPersistence());
        mqttClient.setCallback(this);
      }
      if (!mqttClient.isConnected()) {
        mqttClient.connect(connectOptions);
      }
    } catch (MqttException me) {
      LOGGER.error(me.getMessage());
    }

  }

  /**
   * MqttAgent main.
   *
   * @param args For extension use
   */
  @SuppressWarnings("resource")
  public static void main(String[] args) {
    String mqttServer = "192.168.100.129";
    String mqttPort = "1883";
    String mqttAccount = "k300";
    String mqttPassword = "k300test";
    String mqttBroker = "tcp://" + mqttServer + ":" + mqttPort;

    MqttConnectOptions connectOptions = new MqttConnectOptions();
    connectOptions.setCleanSession(true);
    connectOptions.setKeepAliveInterval(60); // Keep Alive Interval in seconds
    connectOptions.setAutomaticReconnect(true);

    if (mqttAccount != null && !mqttAccount.isEmpty() && mqttPassword != null && !mqttPassword.isEmpty()) {
      connectOptions.setUserName(mqttAccount);
      connectOptions.setPassword(mqttPassword.toCharArray());
    }

    try {
      MqttClient mqttClient = new MqttClient(mqttBroker, MqttClient.generateClientId(), new MemoryPersistence());

      // 設定回調處理
      mqttClient.setCallback(new MqttCallback() {
        @Override
        public void connectionLost(Throwable cause) {
          System.out.println("Connection lost: " + cause.getMessage());
        }

        @Override
        public void messageArrived(String topic, MqttMessage message) throws Exception {
          System.out.println(
              "Message received - Topic: " + topic + ", Message: " + new String(message.getPayload(), "UTF-8"));
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {
          try {
            System.out.println("Delivery complete for message: " + token.getMessage());
          } catch (MqttException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
        }
      });

      // 連線到 MQTT Broker
      mqttClient.connect(connectOptions);

      // 訂閱主題以接收訊息
      String topicToSubscribe = "k300_dog_1/status";
      mqttClient.subscribe(topicToSubscribe);
      System.out.println("Subscribed to topic: " + topicToSubscribe);

      // 保持主程式運行
      System.out.println("Waiting for messages...");
      while (true) {
        // 主執行緒保持存活，等待接收訊息
        Thread.sleep(1000);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

  }
}
