package jcas.jms.db;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * DbManager is the class for DB management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class DbManager {
  private static final Logger LOGGER = LoggerFactory.getLogger(DbManager.class);
  private DataSource datasource;

  public DbManager(@Autowired DataSource datasource) {
    this.datasource = datasource;
  }

  /**
   * Gets DB Connection.
   *
   * @return {@code Connection}
   * @throws SQLException The SQL exception
   */
  public Connection getConnection() throws SQLException {
    Connection connection = null;
    connection = datasource.getConnection();
    return connection;
  }

  /**
   * Closes DB Connection.
   *
   * @param connection {@code Connection}
   */
  public void closeConnection(Connection connection) {
    try {
      if (connection != null) {
        connection.close();
        connection = null;
      }
    } catch (SQLException e) {
      LOGGER.error(e.getMessage());
    }
  }

  /**
   * Creates PreparedStatement.
   *
   * @param sql        The SQL string
   * @param connection {@code Connection}
   * @return {@code PreparedStatement}
   * @throws SQLException The SQL exception
   */
  public PreparedStatement createPreparedStatement(String sql, Connection connection)
      throws SQLException {
    PreparedStatement preparedStatement = null;
    if (sql != null && connection != null) {
      preparedStatement = connection.prepareStatement(sql);
    }
    return preparedStatement;
  }

  /**
   * Closes PreparedStatement.
   *
   * @param preparedStatement {@code PreparedStatement}
   * @throws SQLException The SQL exception
   */
  public void closePreparedStatement(PreparedStatement preparedStatement) throws SQLException {
    if (preparedStatement != null) {
      preparedStatement.close();
      preparedStatement = null;
    }
  }

  /**
   * Gets ResultSet.
   *
   * @param preparedStatement {@code PreparedStatement}
   * @param connection        {@code Connection}
   * @return {@code ResultSet}
   * @throws SQLException The SQL exception
   */
  public ResultSet select(PreparedStatement preparedStatement, Connection connection)
      throws SQLException {
    if (preparedStatement != null && connection != null && !connection.isClosed()) {
      ResultSet resultSet = preparedStatement.executeQuery();
      return resultSet;
    }
    return null;
  }

  /**
   * Gets ResultSet by parameter list.
   *
   * @param preparedStatement {@code PreparedStatement}
   * @param parameterList     The parameter list
   * @return {@code ResultSet}
   * @throws SQLException The SQL exception
   */
  public ResultSet select(PreparedStatement preparedStatement, ArrayList<?> parameterList)
      throws SQLException {
    for (int i = 0; i < parameterList.size(); i++) {
      setState(preparedStatement, i + 1, parameterList.get(i));
    }
    ResultSet resultSet = preparedStatement.executeQuery();
    return resultSet;
  }

  /**
   * Executes SQL command.
   *
   * @param preparedStatement {@code PreparedStatement}
   * @param parameterList     The parameter list
   * @return (1) the row count; (2) nothing
   * @throws SQLException The SQL exception
   */
  public int update(PreparedStatement preparedStatement, ArrayList<?> parameterList)
      throws SQLException {
    int result = 0;
    for (int i = 0; i < parameterList.size(); i++) {
      setState(preparedStatement, i + 1, parameterList.get(i));
    }
    result = preparedStatement.executeUpdate();
    return result;
  }

  private void setState(PreparedStatement preparedStatement, int index, Object object)
      throws SQLException {
    String name = "";
    if (object != null) {
      name = object.getClass().getName();
    }
    if (name.compareTo("java.sql.Timestamp") == 0) {
      preparedStatement.setTimestamp(index, (Timestamp) object);
    } else if (name.compareTo("java.sql.Date") == 0) {
      preparedStatement.setDate(index, (Date) object);
    } else if (name.compareTo("javax.sql.rowset.serial.SerialBlob") == 0) {
      preparedStatement.setBlob(index, (Blob) object);
    } else if (name.compareTo("java.lang.String") == 0) {
      preparedStatement.setString(index, (String) object);
    } else if (name.compareTo("java.lang.Long") == 0) {
      preparedStatement.setLong(index, ((Long) object).longValue());
    } else if (name.compareTo("java.lang.Integer") == 0) {
      preparedStatement.setInt(index, ((Integer) object).intValue());
    } else if (name.compareTo("java.lang.Double") == 0) {
      preparedStatement.setDouble(index, ((Double) object).doubleValue());
    } else {
      preparedStatement.setBytes(index, (byte[]) object);
    }
  }

}