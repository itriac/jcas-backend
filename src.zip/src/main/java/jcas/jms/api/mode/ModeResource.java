package jcas.jms.api.mode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.api.posture.PostureResource;
import jcas.jms.model.mode.ModeTransientData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ModeResource is the class for mode resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/mode")
@Api(tags = { "Mode API (Mode Management)" })
public class ModeResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(ModeResource.class);
  private static final ExecutorService executor = Executors.newCachedThreadPool();

  /**
   * Obtains mmW posture mode status.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/mmW_posture")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains mmW posture mode status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getMmWavePostureMode() {
    String responseString = "";
    Boolean mmWavePostureDog1 = ModeTransientData.mmWPostureMap.getOrDefault(("DOG1"), false);
    responseString = "DOG1 : " + mmWavePostureDog1 + ", ";
    Boolean mmWavePostureDog2 = ModeTransientData.mmWPostureMap.getOrDefault(("DOG2"), false);
    responseString += "DOG2 : " + mmWavePostureDog2 + ", ";
    Boolean mmWavePostureAmr1 = ModeTransientData.mmWPostureMap.getOrDefault(("AMR1"), false);
    responseString += "AMR1 : " + mmWavePostureAmr1;

    // LOGGER.info("Fetching mmW posture mode status map");
    return Response.status(200).entity(responseString).build();
  }

  /**
   * Obtains CSI posture mode status.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/csi_posture")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains CSI posture mode status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getCsiPostureMode() {
    String responseString = "";
    Boolean csiPostureDog1 = ModeTransientData.csiPostureMap.getOrDefault(("DOG1"), false);
    responseString = "DOG1 : " + csiPostureDog1 + ", ";
    Boolean csiPostureDog2 = ModeTransientData.csiPostureMap.getOrDefault(("DOG2"), false);
    responseString += "DOG2 : " + csiPostureDog2 + ", ";
    Boolean csiPostureAmr1 = ModeTransientData.csiPostureMap.getOrDefault(("AMR1"), false);
    responseString += "AMR1 : " + csiPostureAmr1;

    LOGGER.info("Fetching CSI posture mode status map");
    return Response.status(200).entity(responseString).build();
  }

  /**
   * Obtains lottery mode status.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/lottery_mode")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains lottery mode status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getLotteryMode() {
    String responseString = "";
    Boolean lottery1 = ModeTransientData.lotteryMap.getOrDefault(("LOTTERY1"), false);
    responseString = "LOTTERY1 : " + lottery1;

    LOGGER.info("Fetching lottery mode status map");
    return Response.status(200).entity(responseString).build();
  }

  /**
   * Obtains robot navigation mode status.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/robot_navi")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains robot navigation mode status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getRobotNavigationMode() {
    String responseString = "";
    Boolean robotNavigationDog1 = ModeTransientData.robotNaviMap.getOrDefault(("DOG1"), false);
    responseString = "DOG1 : " + robotNavigationDog1 + ", ";
    Boolean robotNavigationDog2 = ModeTransientData.robotNaviMap.getOrDefault(("DOG2"), false);
    responseString += "DOG2 : " + robotNavigationDog2 + ", ";
    Boolean robotNavigationAmr1 = ModeTransientData.robotNaviMap.getOrDefault(("AMR1"), false);
    responseString += "AMR1 : " + robotNavigationAmr1;

    LOGGER.info("Fetching robot navigation mode status map");
    return Response.status(200).entity(responseString).build();
  }

  /**
   * Enables the mmW posture mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @PUT
  @Path("/mmW_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Enables the mmW "
      + "posture mode binding with a specific robot", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putMmWavePostureMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    LOGGER.info("Enabling mmWave Mode robotId: " + robotId);

    // Verify robotId
    if (!ModeTransientData.mmWPostureMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.mmWPostureMap.put(robotId, true);
    ModeTransientData.mmWPostureMap.put("DOG2", true);

    ModeTransientData.lotteryMap.put("LOTTERY1", false);
    ModeTransientData.robotNaviMap.put(robotId, false);

    ModeTransientData.POSTURE_SUPPRESSION_TIME = 3000;

    // 非同步執行任務
    executor.submit(() -> {
      try {
        // 模擬等待 2 秒
        Thread.sleep(2000);
        PostureResource pr = new PostureResource();
        pr.postMmWavePosture("0", "APT_SWING");
        LOGGER.info("APT_SWING command sent.");
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt(); // 重新設置中斷狀態
        LOGGER.error("Task interrupted", e);
      }
    });

    LOGGER.info("Enabling mmWave Mode");
    return Response.status(200).entity("Mode Enabled").build();
  }

  /**
   * Disables the mmW posture mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @DELETE
  @Path("/mmW_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Disables the mmW "
      + "posture mode binding with a specific robot", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteMmWavePostureMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    // Verify robotId
    if (!ModeTransientData.mmWPostureMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.mmWPostureMap.put(robotId, false);
    ModeTransientData.mmWPostureMap.put("DOG2", false);

    LOGGER.info("Disabling mmWave Mode");
    return Response.status(200).entity("Mode Disabled").build();
  }

  /**
   * Enables the CSI posture mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @PUT
  @Path("/csi_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Enables the CSI "
      + "posture mode binding with a specific robot", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putCsiPostureMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    // Verify robotId
    if (!ModeTransientData.csiPostureMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.csiPostureMap.put(robotId, true);
    ModeTransientData.lotteryMap.put("LOTTERY1", false);
    ModeTransientData.robotNaviMap.put(robotId, false);

    ModeTransientData.POSTURE_SUPPRESSION_TIME = 3000;

    LOGGER.info("Enabling CSI Mode");
    return Response.status(200).entity("Mode Enabled").build();
  }

  /**
   * Disables the CSI posture mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @DELETE
  @Path("/csi_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Disables the CSI "
      + "posture mode binding with a specific robot", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteCsiPostureMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    // Verify robotId
    if (!ModeTransientData.csiPostureMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.csiPostureMap.put(robotId, false);

    LOGGER.info("Disabling CSI Mode");
    return Response.status(200).entity("Mode Disabled").build();
  }

  /**
   * Enables the lottery mode.
   *
   * @return {@code Response}
   */
  @PUT
  @Path("/lottery_mode")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Enables the lottery "
      + "mode", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putLotteryMode() {

    ModeTransientData.lotteryMap.put("LOTTERY1", true);
    ModeTransientData.robotNaviMap.put("DOG1", false);
    ModeTransientData.mmWPostureMap.put("DOG1", false);
    ModeTransientData.csiPostureMap.put("DOG1", false);
    ModeTransientData.robotNaviMap.put("DOG2", false);
    ModeTransientData.mmWPostureMap.put("DOG2", false);
    ModeTransientData.csiPostureMap.put("DOG2", false);

    ModeTransientData.POSTURE_SUPPRESSION_TIME = 300;

    LOGGER.info("Enabling Lottery Mode");
    return Response.status(200).entity("Mode Enabled").build();
  }

  /**
   * Disables the lottery mode.
   *
   * @return {@code Response}
   */
  @DELETE
  @Path("/lottery_mode")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Disables the lottery "
      + "mode", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteLotteryMode() {

    ModeTransientData.lotteryMap.put("LOTTERY1", false);

    LOGGER.info("Disabling Lottery Mode");
    return Response.status(200).entity("Mode Disabled").build();
  }

  /**
   * Enables the navigation mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @PUT
  @Path("/robot_navi")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Enables the navigation "
      + "mode binding with a specific robot", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putRobotNavigationMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    // Verify robotId
    if (!ModeTransientData.robotNaviMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.robotNaviMap.put(robotId, true);
    ModeTransientData.mmWPostureMap.put(robotId, false);
    ModeTransientData.csiPostureMap.put(robotId, false);
    ModeTransientData.lotteryMap.put("LOTTERY1", false);

    ModeTransientData.POSTURE_SUPPRESSION_TIME = 300;

    LOGGER.info("Enabling Navigation Mode");
    return Response.status(200).entity("Mode Enabled").build();
  }

  /**
   * Disables the navigation mode binding with a specific robot.
   *
   * @param  robotId The Robot ID
   * @return         {@code Response}
   */
  @DELETE
  @Path("/robot_navi")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Disables the navigation "
      + "mode binding with a specific robot", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteRobotNavigationMode(
      @ApiParam(value = "The Robot ID", required = true) @QueryParam("robotId") String robotId) {
    // Verify robotId
    if (!ModeTransientData.robotNaviMap.containsKey(robotId)) {
      return Response.status(404).entity("Invalid robotId").build();
    }

    ModeTransientData.robotNaviMap.put(robotId, false);

    LOGGER.info("Disabling Navigation Mode");
    return Response.status(200).entity("Mode Disabled").build();
  }

}
