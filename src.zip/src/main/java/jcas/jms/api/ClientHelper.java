package jcas.jms.api;

import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ClientHelper is the class for SSL client.
 *
 * @author Industrial Technology Research Institute
 */
public class ClientHelper {
  private static final Logger LOGGER = LoggerFactory.getLogger(ClientHelper.class);

  /**
   * Generates SSLContext.
   *
   * @return {@code SSLContext}
   */
  public static SSLContext configureSsl() {
    TrustManager[] certs = new TrustManager[] { new X509TrustManager() {
      @Override
      public X509Certificate[] getAcceptedIssuers() {
        return null;
      }

      @Override
      public void checkServerTrusted(X509Certificate[] chain, String authType)
          throws CertificateException {
      }

      @Override
      public void checkClientTrusted(X509Certificate[] chain, String authType)
          throws CertificateException {
      }
    } };
    SSLContext ctx = null;
    try {
      ctx = SSLContext.getInstance("TLS");
      ctx.init(null, certs, new SecureRandom());
    } catch (java.security.GeneralSecurityException ex) {
      LOGGER.error(ex.getMessage());
    } catch (Exception ex) {
      LOGGER.error(ex.getMessage());
    }
    return ctx;
  }

  /**
   * Generates WebTarget.
   *
   * @param uri The target URI
   * @return {@code WebTarget}
   */
  public static WebTarget createTarget(String uri) {
    if (uri.indexOf("https") == 0) {
      return ClientBuilder.newBuilder().sslContext(ClientHelper.configureSsl())
          .hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
              return true;
            }
          }).build().target(uri);
    } else {
      return ClientBuilder.newClient().target(uri);
    }
  }
}
