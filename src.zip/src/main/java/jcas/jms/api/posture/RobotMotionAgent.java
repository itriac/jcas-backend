package jcas.jms.api.posture;

import jcas.jms.mqtt.MqttAgent;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * RobotMotionAgent is the class to control motion of robot.
 *
 * @author Industrial Technology Research Institute
 */
public class RobotMotionAgent {
  private static final Logger LOGGER = LoggerFactory.getLogger(RobotMotionAgent.class);
  private Boolean mqttEnable = Boolean.parseBoolean(System.getProperty("mqttEnable"));
  private String robotId;
  private String mqttTopicMotion;

  public RobotMotionAgent(String robotId) {
    super();
    this.robotId = robotId;
    if (robotId.equalsIgnoreCase("DOG1")) {
      this.mqttTopicMotion = "k300_dog_1/motion";
    } else if (robotId.equalsIgnoreCase("DOG2")) {
      this.mqttTopicMotion = "k300_dog_2/motion";
    } else if (robotId.equalsIgnoreCase("AMR1")) {
      this.mqttTopicMotion = "k300_amr_1/motion";
    }

  }

  @SuppressWarnings("unchecked")
  public void execRobotRaiseLeft() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "raise_left");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Raise Left");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotRaiseRight() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "raise_right");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Raise Right");
    }
  }

  // @SuppressWarnings("unchecked") public void execRobotRaiseBoth() { if (mqttEnable) { JSONObject motionJsonObject =
  // new JSONObject(); motionJsonObject.put("posture", "raise_both"); motionJsonObject.put("move", "0");
  // motionJsonObject.put("lottery", "rolling"); MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion,
  // motionJsonObject.toJSONString()); LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Raise
  // Both"); } }

  @SuppressWarnings("unchecked")
  public void execRobotStepping() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "stepping");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Stepping");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotRotate() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "rotate");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Rotate");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotRaiseHigh() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "raise_high");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Raise High");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotIdle() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "idle");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Idle");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotWalking() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "csi_walking");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Walking");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotSquat() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "csi_squat");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Squat");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotNavi(String nineSquareIndex) {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "no");
      motionJsonObject.put("move", nineSquareIndex);
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER
          .info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + ", Move to Nine-Square: " + nineSquareIndex);
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotLotteryRolling() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "no");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "rolling");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Lottery Rolling");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotLotteryStop() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "no");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Lottery Stop");
    }
  }

  @SuppressWarnings("unchecked")
  public void execRobotLotteryToggle() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "no");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "toggle");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " Lottery Toggle");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptDance() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_dance");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT Dance");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptSwing() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_swing");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT Swing");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptCircle() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_circle");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT Circle");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptLeftRight() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_left_right");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT LeftRight");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptSquat() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_squat");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT Squat");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptBackForward() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_back_forward");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT BackForward");
    }
  }

  @SuppressWarnings("unchecked")
  public void execAptRush() {
    if (mqttEnable) {
      JSONObject motionJsonObject = new JSONObject();
      motionJsonObject.put("posture", "apt_rush");
      motionJsonObject.put("move", "0");
      motionJsonObject.put("lottery", "stop");
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, motionJsonObject.toJSONString());
      LOGGER.info("MQTT Topic: " + mqttTopicMotion + ", Robot: " + robotId + " APT Rush");
    }
  }

}
