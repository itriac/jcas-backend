package jcas.jms.api.posture;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.mode.ModeTransientData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PostureResource is the class for posture resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/posture")
@Api(tags = { "Posture API (Posture Management)" })
public class PostureResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(PostureResource.class);
  // Store the last execution time stamp for each postureName
  private static final ConcurrentHashMap<String, Long> lastExecutionTimeMap = new ConcurrentHashMap<>();
  // private static final long SUPPRESSION_TIME = 1000; // 1 seconds in milliseconds private static long lastRollingTime
  // = 0;
  private static boolean isRolling = false;

  /**
   * Adds the mmW posture.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/mmW_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the mmW posture", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postMmWavePosture(
      @ApiParam(value = "The Person Id", required = false) @QueryParam("personId") String personId,
      @ApiParam(value = "The Posture Name", required = true) @QueryParam("postureName") String postureName) {
    LOGGER.info("mmWave Posture received: " + postureName);
    long currentTime = System.currentTimeMillis();

    // Check if the same postureName was executed in the last 3 seconds
    Long lastExecutionTime = lastExecutionTimeMap.get(postureName);
    if (lastExecutionTime != null && (currentTime - lastExecutionTime < ModeTransientData.POSTURE_SUPPRESSION_TIME)) {
      LOGGER.info("Action suppressed, try again later.");
      return Response.status(400).entity("Action suppressed, try again later.").build();
    }

    // Update the last execution time for this postureName
    lastExecutionTimeMap.put(postureName, currentTime);

    if (!ModeTransientData.DOG_1_STATUS.isEmpty() || !ModeTransientData.DOG_2_STATUS.isEmpty()) {
      LOGGER.info("Dog Action not completes, try again later.");
      return Response.status(400).entity("Dog Action not completes, try again later.").build();
    }

    for (String robotId : ModeTransientData.mmWPostureMap.keySet()) {
      if (ModeTransientData.mmWPostureMap.get(robotId)) {
        // Enabled
        RobotMotionAgent motionAgent = new RobotMotionAgent(robotId);
        switch (postureName) {
        case "ARM_RAISE_LEFT":
          // motionAgent.execRobotRaiseLeft();
          break;
        case "ARM_RAISE_RIGHT":
          // motionAgent.execRobotRaiseRight();
          break;
        case "POSTURE_STEPPING":
          // motionAgent.execRobotStepping();
          break;
        case "POSTURE_IDLE_LONG":
          // motionAgent.execRobotIdle();
          break;
        case "ARM_ROTATE_SINGLE":
          // motionAgent.execRobotRotate();
          break;
        case "ARM_RAISE_HIGH":
          // motionAgent.execRobotRaiseHigh();
          break;
        case "APT_SWING":
          motionAgent.execAptSwing();
          break;
        case "APT_CIRCLE":
          motionAgent.execAptCircle();
          break;
        case "APT_LEFT_RIGHT":
          motionAgent.execAptLeftRight();
          break;
        case "APT_SQUAT":
          motionAgent.execAptSquat();
          break;
        case "APT_BACK_FORWARD":
          motionAgent.execAptBackForward();
          break;
        case "APT_RUSH":
          motionAgent.execAptRush();
          break;
        default:
          return Response.status(404).entity("Invalid postureName").build();
        }

        LOGGER.info("mmWave Posture send: " + postureName);
      }
    }

    // Lottery
    for (String lotteryId : ModeTransientData.lotteryMap.keySet()) {
      if (ModeTransientData.lotteryMap.get(lotteryId)) {
        RobotMotionAgent motionAgent = new RobotMotionAgent("DOG2");
        switch (postureName) {
        case "ARM_ROTATE_SINGLE":
          motionAgent.execRobotLotteryRolling();
          // lastRollingTime = System.currentTimeMillis(); 記錄開始rolling的時間 try { if (!isRolling) {
          // sendHttpRequest("http://192.168.42.1/start", "GET", null, null); isRolling = true; } } catch (Exception e)
          // { LOGGER.info("Lottery: " + e.getMessage()); }
          break;
        default:
          // if (System.currentTimeMillis() - lastRollingTime >= 3000) { try { if (isRolling) {
          // sendHttpRequest("http://192.168.42.1/stop", "GET", null, null); isRolling = false; } } catch (Exception e)
          // { LOGGER.info("Lottery: " + e.getMessage()); } } else { System.out.println("等待三秒後再停止"); }
        }

        // LOGGER.info("Postting mmWave Posture: " + postureName);
      }
    }

    return Response.status(201).entity("mmWave Posture Created").build();
  }

  /**
   * Adds the CSI posture.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/csi_posture")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the CSI posture", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postCsiPosture(
      @ApiParam(value = "The Posture Name", required = true) @QueryParam("postureName") String postureName) {
    long currentTime = System.currentTimeMillis();

    // Check if the same postureName was executed in the last 3 seconds
    Long lastExecutionTime = lastExecutionTimeMap.get(postureName);
    if (lastExecutionTime != null && (currentTime - lastExecutionTime < ModeTransientData.POSTURE_SUPPRESSION_TIME)) {
      return Response.status(400).entity("Action suppressed, try again later.").build();
    }

    // Update the last execution time for this postureName
    lastExecutionTimeMap.put(postureName, currentTime);

    for (String robotId : ModeTransientData.csiPostureMap.keySet()) {
      if (ModeTransientData.csiPostureMap.get(robotId)) {
        // Enabled
        RobotMotionAgent motionAgent = new RobotMotionAgent(robotId);
        switch (postureName) {
        case "POSTURE_WALKING":
          motionAgent.execRobotWalking();
          break;
        case "POSTURE_SQUAT":
          motionAgent.execRobotSquat();
          break;
        default:
          return Response.status(404).entity("Invalid postureName").build();
        }

        LOGGER.info("Postting CSI Posture: " + postureName);
      }
    }

    return Response.status(201).entity("CSI Posture Created").build();
  }

  /**
   * Adds the open dance.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/open_dance")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the open dance", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postOpenDance() {
    RobotMotionAgent motionAgent1 = new RobotMotionAgent("DOG1");
    RobotMotionAgent motionAgent2 = new RobotMotionAgent("DOG2");
    try {
      // 左浪花
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      // 右浪花
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      // 小恭喜
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      motionAgent1.execRobotStepping();
      motionAgent2.execRobotStepping();
      Thread.sleep(500);
      // 左浪花
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      motionAgent1.execRobotRaiseLeft();
      Thread.sleep(500);
      // 右浪花
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      motionAgent2.execRobotRaiseRight();
      Thread.sleep(500);
      // 大恭喜
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
      motionAgent1.execRobotRotate();
      motionAgent2.execRobotRotate();
      Thread.sleep(500);
    } catch (InterruptedException e) {
      LOGGER.error(e.getMessage());
    }
    return Response.status(201).entity("Open Dance Created").build();
  }

  /**
   * Adds the lottery rolling.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/lottery_rolling")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the lottery rolling", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postLotteryRolling() {
    RobotMotionAgent motionAgent1 = new RobotMotionAgent("DOG2");

    try {
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
      motionAgent1.execRobotLotteryRolling();
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      LOGGER.error(e.getMessage());
    }
    return Response.status(201).entity("Lottery Rolling Created").build();
  }

  /**
   * Adds the lottery stop.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/lottery_stop")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the lottery stop", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postLotteryStop() {
    RobotMotionAgent motionAgent1 = new RobotMotionAgent("DOG2");

    try {
      motionAgent1.execRobotLotteryStop();
      Thread.sleep(500);
      motionAgent1.execRobotLotteryStop();
      Thread.sleep(500);
      motionAgent1.execRobotLotteryStop();
      Thread.sleep(500);
      motionAgent1.execRobotLotteryStop();
      Thread.sleep(500);
      motionAgent1.execRobotLotteryStop();
      Thread.sleep(500);
    } catch (InterruptedException e) {
      LOGGER.error(e.getMessage());
    }
    return Response.status(201).entity("Lottery Stop Created").build();
  }

  /**
   * Adds the lottery toggle.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/lottery_toggle")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the lottery toggle", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postLotteryToggle() {
    RobotMotionAgent motionAgent = new RobotMotionAgent("DOG2");
    motionAgent.execRobotLotteryToggle();
    if (isRolling) {
      isRolling = false;
    } else {
      isRolling = true;
    }
    return Response.status(201).entity("Lottery Rolling: " + isRolling).build();
  }

  /**
   * 發送 HTTP 請求並返回回應內容
   *
   * @param  urlPath     遠端網址
   * @param  method      HTTP 方法 ("GET", "POST", "PUT", "DELETE")
   * @param  requestBody 請求主體 (適用於 POST/PUT，GET/DELETE 傳入 null)
   * @param  contentType Content-Type，例如 "application/json"
   * @return             回應字串
   * @throws Exception   當發生錯誤時丟出例外
   */
  @SuppressWarnings("unused")
  private String sendHttpRequest(String urlPath, String method, String requestBody, String contentType)
      throws Exception {
    // 建立 URL 物件
    URL url = new URL(urlPath);
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();

    // 設定請求方法
    connection.setRequestMethod(method);

    // 設定請求屬性 (Headers)
    if (contentType != null) {
      connection.setRequestProperty("Content-Type", contentType);
    }
    connection.setRequestProperty("Accept", "application/json");

    // 如果是 POST/PUT，寫入請求主體
    if ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method)) {
      connection.setDoOutput(true);
      if (requestBody != null) {
        try (OutputStream os = connection.getOutputStream()) {
          os.write(requestBody.getBytes("UTF-8"));
          os.flush();
        }
      }
    }

    // 取得回應碼
    int responseCode = connection.getResponseCode();
    System.out.println("Response Code: " + responseCode);

    // 讀取回應內容
    try (BufferedReader br = new BufferedReader(new InputStreamReader(
        responseCode >= 200 && responseCode < 300 ? connection.getInputStream() : connection.getErrorStream(),
        "UTF-8"))) {
      StringBuilder response = new StringBuilder();
      String line;
      while ((line = br.readLine()) != null) {
        response.append(line);
      }
      return response.toString();
    } finally {
      connection.disconnect();
    }
  }

  /**
   * Adds the APT dance.
   *
   * @return {@code Response}
   */
  @POST
  @Path("/apt_dance")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the APT dance", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postAptDance() {
    RobotMotionAgent motionAgent1 = new RobotMotionAgent("DOG1");
    RobotMotionAgent motionAgent2 = new RobotMotionAgent("DOG2");
    motionAgent2.execAptDance();
    motionAgent1.execAptDance();

    return Response.status(201).entity("APT Dance Created").build();
  }

  /**
   * Adds the dog control.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/dog_control")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains mmW posture mode status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response execDogControl(
      @ApiParam(value = "The Control Name", required = true) @QueryParam("controlName") String controlName) {

    // if (!ModeTransientData.DOG_1_STATUS.isEmpty() || !ModeTransientData.DOG_2_STATUS.isEmpty()) { return
    // Response.status(400).entity("Dog Action not completes, try again later.").build(); }
    LOGGER.info("DOG_1_STATUS: " + ModeTransientData.DOG_1_STATUS);
    LOGGER.info("DOG_2_STATUS: " + ModeTransientData.DOG_2_STATUS);
    while (!ModeTransientData.DOG_1_STATUS.isEmpty() || !ModeTransientData.DOG_2_STATUS.isEmpty()) {
      try {
        // 等待 0.5 秒
        Thread.sleep(500);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt(); // 重新設置中斷狀態
        return Response.status(500).entity("Internal server error.").build();
      }
    }

    RobotMotionAgent motionAgent1 = new RobotMotionAgent("DOG1");
    RobotMotionAgent motionAgent2 = new RobotMotionAgent("DOG2");
    switch (controlName) {
    case "APT_SWING":
      motionAgent1.execAptSwing();
      motionAgent2.execAptSwing();
      break;
    case "APT_CIRCLE":
      motionAgent1.execAptCircle();
      motionAgent2.execAptCircle();
      break;
    case "APT_LEFT_RIGHT":
      motionAgent1.execAptLeftRight();
      motionAgent2.execAptLeftRight();
      break;
    case "APT_SQUAT":
      motionAgent1.execAptSquat();
      motionAgent2.execAptSquat();
      break;
    case "APT_BACK_FORWARD":
      motionAgent1.execAptBackForward();
      motionAgent2.execAptBackForward();
      break;
    case "APT_RUSH":
      motionAgent1.execAptRush();
      motionAgent2.execAptRush();
      break;
    default:
      return Response.status(404).entity("Invalid controlName").build();
    }

    return Response.status(200).entity("Dog Control Executed").build();
  }
}
