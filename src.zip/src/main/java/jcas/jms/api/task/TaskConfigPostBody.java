package jcas.jms.api.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * TaskConfigPostBody is the class for TaskConfigPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("TaskConfigPostBody")
public class TaskConfigPostBody {
  private String taskName;
  private Integer taskPriority;
  private Integer taskLatencyMs;
  private Integer cpuMinCore;
  private Long gpuMinByte;
  private Long memoryMinByte;
  private Boolean taskPowerPlugged;

  @ApiModelProperty(value = "Name of Task", required = true)
  public String getTaskName() {
    return taskName;
  }

  public void setTaskName(String taskName) {
    this.taskName = taskName;
  }

  @ApiModelProperty(value = "Priority of Task", required = true)
  public Integer getTaskPriority() {
    return taskPriority;
  }

  public void setTaskPriority(Integer taskPriority) {
    this.taskPriority = taskPriority;
  }

  @ApiModelProperty(value = "Latency of Task", required = true)
  public Integer getTaskLatencyMs() {
    return taskLatencyMs;
  }

  public void setTaskLatencyMs(Integer taskLatencyMs) {
    this.taskLatencyMs = taskLatencyMs;
  }

  @ApiModelProperty(value = "CPU Prerequisite of Task Exec", required = true)
  public Integer getCpuMinCore() {
    return cpuMinCore;
  }

  public void setCpuMinCore(Integer cpuMinCore) {
    this.cpuMinCore = cpuMinCore;
  }

  @ApiModelProperty(value = "GPU Prerequisite of Task Exec", required = true)
  public Long getGpuMinByte() {
    return gpuMinByte;
  }

  public void setGpuMinByte(Long gpuMinByte) {
    this.gpuMinByte = gpuMinByte;
  }

  @ApiModelProperty(value = "Memory Prerequisite of Task Exec", required = true)
  public Long getMemoryMinByte() {
    return memoryMinByte;
  }

  public void setMemoryMinByte(Long memoryMinByte) {
    this.memoryMinByte = memoryMinByte;
  }

  @ApiModelProperty(value = "Power Plugged Prerequisite of Task Exec", required = true)
  public Boolean getTaskPowerPlugged() {
    return taskPowerPlugged;
  }

  public void setTaskPowerPlugged(Boolean taskPowerPlugged) {
    this.taskPowerPlugged = taskPowerPlugged;
  }

}
