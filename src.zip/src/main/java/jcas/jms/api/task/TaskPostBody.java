package jcas.jms.api.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * TaskPostBody is the class for TaskPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("TaskPostBody")
public class TaskPostBody {
  private Integer taskConfigId;
  private String cnSourceId;
  private String cnExecId;
  private String taskAction;
  private Integer cpuUsedCore;
  private Long gpuUsedByte;
  private Long memoryUsedByte;
  // private Integer nicUsedBit;
  private Double cnSourceUsedPowerW;
  // private Double nicUsedPowerW;
  private Double cnExecUsedPowerW;
  private Integer execTimeMs;
  private String execResult;
  private String taskStatus;

  @ApiModelProperty(value = "ID of Task Config", required = true)
  public Integer getTaskConfigId() {
    return taskConfigId;
  }

  public void setTaskConfigId(Integer taskConfigId) {
    this.taskConfigId = taskConfigId;
  }

  @ApiModelProperty(value = "ID of Source Computing Node", required = true)
  public String getCnSourceId() {
    return cnSourceId;
  }

  public void setCnSourceId(String cnSourceId) {
    this.cnSourceId = cnSourceId;
  }

  @ApiModelProperty(value = "ID of Exec Computing Node", required = true)
  public String getCnExecId() {
    return cnExecId;
  }

  public void setCnExecId(String cnExecId) {
    this.cnExecId = cnExecId;
  }

  @ApiModelProperty(value = "Action of Task", required = true)
  public String getTaskAction() {
    return taskAction;
  }

  public void setTaskAction(String taskAction) {
    this.taskAction = taskAction;
  }

  @ApiModelProperty(value = "Used CPU of Task Exec", required = true)
  public Integer getCpuUsedCore() {
    return cpuUsedCore;
  }

  public void setCpuUsedCore(Integer cpuUsedCore) {
    this.cpuUsedCore = cpuUsedCore;
  }

  @ApiModelProperty(value = "Used GPU of Task Exec", required = true)
  public Long getGpuUsedByte() {
    return gpuUsedByte;
  }

  public void setGpuUsedByte(Long gpuUsedByte) {
    this.gpuUsedByte = gpuUsedByte;
  }

  @ApiModelProperty(value = "Used Memory of Task Exec", required = true)
  public Long getMemoryUsedByte() {
    return memoryUsedByte;
  }

  public void setMemoryUsedByte(Long memoryUsedByte) {
    this.memoryUsedByte = memoryUsedByte;
  }

  // @ApiModelProperty(value = "Used NIC of Task Exec", required = true)
  // public Integer getNicUsedBit() {
  // return nicUsedBit;
  // }

  // public void setNicUsedBit(Integer nicUsedBit) {
  // this.nicUsedBit = nicUsedBit;
  // }

  @ApiModelProperty(value = "Used Power of Task Exec in Source Node", required = true)
  public Double getCnSourceUsedPowerW() {
    return cnSourceUsedPowerW;
  }

  public void setCnSourceUsedPowerW(Double cnSourceUsedPowerW) {
    this.cnSourceUsedPowerW = cnSourceUsedPowerW;
  }

  // @ApiModelProperty(value = "Used Power of Task Exec in NIC", required = true)
  // public Double getNicUsedPowerW() {
  // return nicUsedPowerW;
  // }

  // public void setNicUsedPowerW(Double nicUsedPowerW) {
  // this.nicUsedPowerW = nicUsedPowerW;
  // }

  @ApiModelProperty(value = "Used Power of Task Exec in Exec Node", required = true)
  public Double getCnExecUsedPowerW() {
    return cnExecUsedPowerW;
  }

  public void setCnExecUsedPowerW(Double cnExecUsedPowerW) {
    this.cnExecUsedPowerW = cnExecUsedPowerW;
  }

  @ApiModelProperty(value = "Exec Time of Task", required = true)
  public Integer getExecTimeMs() {
    return execTimeMs;
  }

  public void setExecTimeMs(Integer execTimeMs) {
    this.execTimeMs = execTimeMs;
  }

  @ApiModelProperty(value = "Exec Result of Task", required = true)
  public String getExecResult() {
    return execResult;
  }

  public void setExecResult(String execResult) {
    this.execResult = execResult;
  }

  @ApiModelProperty(value = "Status of Task", required = true)
  public String getTaskStatus() {
    return taskStatus;
  }

  public void setTaskStatus(String taskStatus) {
    this.taskStatus = taskStatus;
  }

}
