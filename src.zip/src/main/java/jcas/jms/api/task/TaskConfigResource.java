package jcas.jms.api.task;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.task.TaskConfig;
import jcas.jms.model.task.TaskConfigService;
import jcas.jms.model.task.TaskTransientData;
import jcas.jms.util.TransientDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * TaskConfigResource is the class for task config resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/task/config")
@Api(tags = { "Task Config API (Task Management)" })
public class TaskConfigResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskConfigResource.class);

  /**
   * Adds task config.
   *
   * @param postBody {@code TaskConfigPostBody}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds "
      + "task config", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postTaskConfig(@ApiParam(value = "The Post Body", required = true) TaskConfigPostBody postBody) {

    // Verify taskName
    if (TaskTransientData.taskConfigMap.containsKey(postBody.getTaskName())) {
      return Response.status(400).entity("Invalid taskName").build();
    }

    TaskConfig newTaskConfig = new TaskConfig();
    newTaskConfig.setTaskName(postBody.getTaskName());
    newTaskConfig.setTaskPriority(postBody.getTaskPriority());
    newTaskConfig.setTaskLatencyMs(postBody.getTaskLatencyMs());
    newTaskConfig.setCpuMinCore(postBody.getCpuMinCore());
    newTaskConfig.setGpuMinByte(postBody.getGpuMinByte());
    newTaskConfig.setMemoryMinByte(postBody.getMemoryMinByte());
    newTaskConfig.setTaskPowerPlugged(postBody.getTaskPowerPlugged());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    TaskConfigService taskConfigService = ac.getBean(jcas.jms.model.task.TaskConfigService.class);
    taskConfigService.addTaskConfig(newTaskConfig);
    // Refresh Memory
    TransientDataUtil.refreshTaskConfigMap();

    LOGGER.info("Posting TM New TaskConfig");

    TaskConfig taskConfig = TaskTransientData.taskConfigMap.get(postBody.getTaskName());
    Integer taskConfigId = taskConfig.getTaskConfigId();
    return Response.status(201).entity(taskConfigId).build();
  }

  /**
   * Obtains task config list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains task config list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getTaskConfigList() {
    List<TaskConfig> taskConfigList = new ArrayList<TaskConfig>(TaskTransientData.taskConfigMap.values());

    LOGGER.info("Fetching TM TaskConfig List");

    GenericEntity<List<TaskConfig>> entity = new GenericEntity<List<TaskConfig>>(taskConfigList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates task config.
   *
   * @param taskName The task name
   * @param putBody  {@code TaskConfigPutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{taskName}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates "
      + "task config", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putTaskConfig(
      @ApiParam(value = "The Task Name", required = true) @PathParam("taskName") String taskName,
      @ApiParam(value = "The Put Body", required = true) TaskConfigPutBody putBody) {
    // Verify taskName
    if (!TaskTransientData.taskConfigMap.containsKey(taskName)) {
      return Response.status(404).entity("Invalid taskName").build();
    }

    TaskConfig updateTaskConfig = TaskTransientData.taskConfigMap.get(taskName);
    updateTaskConfig.setTaskPriority(putBody.getTaskPriority());
    updateTaskConfig.setTaskLatencyMs(putBody.getTaskLatencyMs());
    updateTaskConfig.setCpuMinCore(putBody.getCpuMinCore());
    updateTaskConfig.setGpuMinByte(putBody.getGpuMinByte());
    updateTaskConfig.setMemoryMinByte(putBody.getMemoryMinByte());
    updateTaskConfig.setTaskPowerPlugged(putBody.getTaskPowerPlugged());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    TaskConfigService taskConfigService = ac.getBean(jcas.jms.model.task.TaskConfigService.class);
    taskConfigService.updateTaskConfig(updateTaskConfig);
    // Refresh Memory
    TransientDataUtil.refreshTaskConfigMap();

    LOGGER.info("Putting TM TaskConfig");
    return Response.status(200).entity("TaskConfig Updated").build();
  }

  /**
   * Deletes task config.
   *
   * @param taskName The task name
   * @return {@code Response}
   */
  @DELETE
  @Path("/{taskName}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes "
      + "task config", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteTaskConfig(
      @ApiParam(value = "The Task Name", required = true) @PathParam("taskName") String taskName) {
    // Verify taskName
    if (!TaskTransientData.taskConfigMap.containsKey(taskName)) {
      return Response.status(404).entity("Invalid taskName").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    TaskConfigService taskConfigService = ac.getBean(jcas.jms.model.task.TaskConfigService.class);
    TaskConfig taskConfig = TaskTransientData.taskConfigMap.get(taskName);
    taskConfigService.deleteTaskConfig(String.valueOf(taskConfig.getTaskConfigId()));
    // Refresh Memory
    TransientDataUtil.refreshTaskConfigMap();

    LOGGER.info("Deleting TM TaskConfig");
    return Response.status(204).entity("TaskConfig Deleted").build();
  }
}
