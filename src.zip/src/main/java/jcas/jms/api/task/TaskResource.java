package jcas.jms.api.task;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.resource.ComputingNode;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.model.task.Task;
import jcas.jms.model.task.TaskConfig;
import jcas.jms.model.task.TaskTransientData;
import jcas.jms.util.Md5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * TaskResource is the class for task resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/task")
@Api(tags = { "Task API (Task Management)" })
public class TaskResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskResource.class);

  /**
   * Adds task.
   *
   * @param postBody {@code TaskPostBody}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds task", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postTask(@ApiParam(value = "The Post Body", required = true) TaskPostBody postBody) {
    // Verify taskConfigId, cnSourceId, cnExecId
    List<Integer> taskConfigIdList = new ArrayList<Integer>();
    List<TaskConfig> taskConfigList = new ArrayList<TaskConfig>(TaskTransientData.taskConfigMap.values());
    for (TaskConfig taskConfig : taskConfigList) {
      taskConfigIdList.add(taskConfig.getTaskConfigId());
    }
    if (!taskConfigIdList.contains(postBody.getTaskConfigId())) {
      return Response.status(404).entity("Invalid taskConfigId").build();
    }
    if (!ComputingNodeTransientData.cnMap.containsKey(postBody.getCnSourceId())) {
      return Response.status(404).entity("Invalid cnSourceId").build();
    }
    if (!ComputingNodeTransientData.cnMap.containsKey(postBody.getCnExecId())) {
      return Response.status(404).entity("Invalid cnExecId").build();
    }

    String taskId = Md5Util.getMd5(postBody.getTaskConfigId() + postBody.getCnSourceId());
    if (TaskTransientData.taskMap.containsKey(taskId)) {
      return Response.status(400).entity("Task already exists").build();
    }

    Task newTask = new Task();
    newTask.setTaskId(taskId);
    newTask.setTaskConfigId(postBody.getTaskConfigId());
    newTask.setCnSourceId(postBody.getCnSourceId());
    newTask.setCnExecId(postBody.getCnExecId());
    newTask.setTaskAction(postBody.getTaskAction());
    newTask.setCpuUsedCore(postBody.getCpuUsedCore());
    newTask.setGpuUsedByte(postBody.getGpuUsedByte());
    newTask.setMemoryUsedByte(postBody.getMemoryUsedByte());
    // newTask.setNicUsedBit(postBody.getNicUsedBit());
    newTask.setCnSourceUsedPowerW(postBody.getCnSourceUsedPowerW());
    // newTask.setNicUsedPowerW(postBody.getNicUsedPowerW());
    newTask.setCnExecUsedPowerW(postBody.getCnExecUsedPowerW());
    newTask.setExecTimeMs(postBody.getExecTimeMs());
    newTask.setExecResult(postBody.getExecResult());
    newTask.setTaskStatus(postBody.getTaskStatus());
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    newTask.setCreateTime(nowTime);
    newTask.setUpdateTime(nowTime);
    TaskTransientData.taskMap.put(taskId, newTask);

    // Refresh Computing Node
    ComputingNode cn = ComputingNodeTransientData.cnMap.get(postBody.getCnExecId());
    List<String> taskIdList = cn.getTaskIds();
    if (taskIdList != null && !taskIdList.contains(taskId)) {
      taskIdList.add(taskId);
    }

    LOGGER.info("Posting TM New Task");

    return Response.status(201).entity(taskId).build();
  }

  /**
   * Obtains task list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains task list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getTaskList() {
    List<Task> taskList = new ArrayList<Task>(TaskTransientData.taskMap.values());

    LOGGER.info("Fetching TM Task List");

    GenericEntity<List<Task>> entity = new GenericEntity<List<Task>>(taskList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates task.
   *
   * @param taskId  The task id
   * @param putBody {@code TaskPutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{taskId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates task", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putTask(@ApiParam(value = "The Task Id", required = true) @PathParam("taskId") String taskId,
      @ApiParam(value = "The Put Body", required = true) TaskPutBody putBody) {
    // Verify cnExecId
    if (!ComputingNodeTransientData.cnMap.containsKey(putBody.getCnExecId())) {
      return Response.status(404).entity("Invalid cnExecId").build();
    }
    // Verify taskId
    if (!TaskTransientData.taskMap.containsKey(taskId)) {
      return Response.status(404).entity("Invalid taskId").build();
    }

    Task updateTask = TaskTransientData.taskMap.get(taskId);
    updateTask.setCnExecId(putBody.getCnExecId());
    updateTask.setTaskAction(putBody.getTaskAction());
    updateTask.setCpuUsedCore(putBody.getCpuUsedCore());
    updateTask.setGpuUsedByte(putBody.getGpuUsedByte());
    updateTask.setMemoryUsedByte(putBody.getMemoryUsedByte());
    // updateTask.setNicUsedBit(putBody.getNicUsedBit());
    updateTask.setCnSourceUsedPowerW(putBody.getCnSourceUsedPowerW());
    // updateTask.setNicUsedPowerW(putBody.getNicUsedPowerW());
    updateTask.setCnExecUsedPowerW(putBody.getCnExecUsedPowerW());
    updateTask.setExecTimeMs(putBody.getExecTimeMs());
    updateTask.setExecResult(putBody.getExecResult());
    updateTask.setTaskStatus(putBody.getTaskStatus());
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    updateTask.setUpdateTime(nowTime);
    TaskTransientData.taskMap.put(taskId, updateTask);

    // Refresh Computing Node
    String originalCnExecId = "";
    List<ComputingNode> cnList = new ArrayList<ComputingNode>(ComputingNodeTransientData.cnMap.values());
    for (ComputingNode cn : cnList) {
      if (cn.getTaskIds().contains(taskId)) {
        originalCnExecId = cn.getCnId();
        break;
      }
    }
    if (!originalCnExecId.equals(putBody.getCnExecId())) {
      ComputingNode originalCn = ComputingNodeTransientData.cnMap.get(originalCnExecId);
      originalCn.getTaskIds().remove(taskId);
      ComputingNode cn = ComputingNodeTransientData.cnMap.get(putBody.getCnExecId());
      List<String> taskIdList = cn.getTaskIds();
      if (taskIdList != null && !taskIdList.contains(taskId)) {
        taskIdList.add(taskId);
      }
    }

    LOGGER.info("Putting TM Task");
    return Response.status(200).entity("Task Updated").build();
  }

}
