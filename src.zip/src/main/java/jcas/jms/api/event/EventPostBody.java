package jcas.jms.api.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * EventPostBody is the class for EventPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("EventPostBody")
public class EventPostBody {
  private String eventType;
  private String eventName;
  private String eventMessage;
  private String eventInfo;

  @ApiModelProperty(value = "Type of Event", required = true, example = "SENSING_EVENT")
  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  @ApiModelProperty(value = "Name of Event", required = true, example = "PERSON_POSTURE")
  public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  @ApiModelProperty(value = "Message of Event", required = true, example = "ARM_RAISE_BOTH")
  public String getEventMessage() {
    return eventMessage;
  }

  public void setEventMessage(String eventMessage) {
    this.eventMessage = eventMessage;
  }

  @ApiModelProperty(value = "Info of Event", required = true, example = "soId")
  public String getEventInfo() {
    return eventInfo;
  }

  public void setEventInfo(String eventInfo) {
    this.eventInfo = eventInfo;
  }

}
