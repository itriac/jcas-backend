package jcas.jms.api.event;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.api.agv.AgvMotionAgent;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.event.Event;
import jcas.jms.model.event.EventConfig;
import jcas.jms.model.event.EventService;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.util.Md5Util;
import jcas.jms.util.TransientDataUtil;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * EventResource is the class for event resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/event")
@Api(tags = { "Event API (Event Management)" })
public class EventResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventResource.class);

  /**
   * Adds the event binding with a specific region.
   *
   * @param  regionId The Region ID
   * @param  postBody {@code EventPostBody}
   * @return          {@code Response}
   */
  @SuppressWarnings({ "unchecked", "unlikely-arg-type" })
  @POST
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the event "
      + "binding with a specific region", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postEvent(@ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "The Post Body", required = true) EventPostBody postBody) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<EventConfig> ecList = new ArrayList<EventConfig>(EventTransientData.ecMap.values());
    EventConfig eventConfig = null;
    for (EventConfig ec : ecList) {
      if (ec.getEventType().equals(postBody.getEventType()) && ec.getEventName().equals(postBody.getEventName())
          && ec.getMessage().equals(postBody.getEventMessage()) && ec.getBindingRegionId().equals(regionId)) {
        eventConfig = ec;
      }
    }

    // Verify eventConfig
    if (eventConfig == null) {
      return Response.status(404).entity("Invalid eventConfig").build();
    }

    // Verify execEnable
    if (!eventConfig.getExecEnable()) {
      return Response.status(400).entity("Event Config Not Enable").build();
    }

    // Verify occurCondition
    if (!eventConfig.getOccurConditionConfig().getOccurEvent()) {
      return Response.status(400).entity("Event Config Occur Condition Error").build();
    }

    // Verify eventType and eventName
    String eventType = eventConfig.getEventType();
    String eventName = eventConfig.getEventName();
    Boolean sensingTrigger = false;
    if (eventType.equals("SENSING_EVENT") && eventName.equals("PERSON_POSTURE")) {
      sensingTrigger = true;
    } else if (eventType.equals("SENSING_EVENT") && eventName.equals("HAND_GESTURE")) {
      sensingTrigger = true;
    } else if (eventType.equals("SENSING_EVENT") && eventName.equals("AGV_STATUS")) {
      sensingTrigger = true;
    } else if (eventType.equals("SENSING_ALARM") && eventName.equals("PERSON_POSTURE")) {
      sensingTrigger = true;
    }
    if (!sensingTrigger) {
      return Response.status(400).entity("Event Config Not Allow").build();
    }

    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

    String unfinishedEventKey = Md5Util.getMd5(eventConfig.getEventConfigId() + "_" + postBody.getEventInfo());
    if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
      // NEW!! Insert DB and memory
      Event newEvent = new Event();
      newEvent.setEventConfig(eventConfig);
      newEvent.setCreateTime(nowTime);
      newEvent.setOccurTime(nowTime);
      JSONObject eventInfoJsonObject = new JSONObject();
      eventInfoJsonObject.put("unfinishedEventKey", unfinishedEventKey);
      eventInfoJsonObject.put("extraInfo", postBody.getEventInfo());
      newEvent.setEventInfo(eventInfoJsonObject.toJSONString());
      eventService.addEvent(newEvent);
      // Refresh memory
      TransientDataUtil.refreshUnfinishedEventMap();
    } else {
      // AGAIN!! Update occur time in memory
      EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setOccurTime(nowTime);
    }

    // Verify navigation
    List<AgvNavi> agvNaviList = new ArrayList<AgvNavi>(AgvTransientData.agvNaviMap.values());
    List<String> navigatingAgvIdList = new ArrayList<String>();
    for (AgvNavi an : agvNaviList) {
      if (!an.getNaviStatus().equals("finish")) {
        navigatingAgvIdList.add(an.getSoAgvId());
      }
    }

    // Person Posture
    Integer soAgvIdPosture = 0;
    AgvMotionAgent agvMotionAgentPosture = new AgvMotionAgent(soAgvIdPosture);
    String eventMessage = eventConfig.getMessage();
    Boolean cooperatingPosture = AgvTransientData.cooperatingMap.getOrDefault(("posture_" + soAgvIdPosture + "_AGV"),
        false);
    if (eventMessage.equals("ARM_RAISE_LEFT") && cooperatingPosture) {
      agvMotionAgentPosture.execTurnLeftSlowly();
      LOGGER.info("EM Event ARM_RAISE_LEFT");
    } else if (eventMessage.equals("ARM_RAISE_RIGHT") && cooperatingPosture) {
      agvMotionAgentPosture.execTurnRightSlowly();
      LOGGER.info("EM Event ARM_RAISE_RIGHT");
    } else if (eventMessage.equals("POSTURE_STEPPING") && cooperatingPosture) {
      agvMotionAgentPosture.execForwardSlowly();
      LOGGER.info("EM Event POSTURE_STEPPING");
    } else if (eventMessage.equals("POSTURE_IDLE_LONG") && cooperatingPosture) {
      agvMotionAgentPosture.execAgvStop();
      LOGGER.info("EM Event POSTURE_IDLE_LONG");
    } else if (eventMessage.equals("ARM_ROTATE_SINGLE") && cooperatingPosture) {
      agvMotionAgentPosture.execBackwardSlowly();
      LOGGER.info("EM Event ARM_ROTATE_SINGLE");
    } else if (eventMessage.equals("ARM_RAISE_BOTH")) {
      if (navigatingAgvIdList.contains(soAgvIdPosture)) {
        return Response.status(400).entity("AGV" + soAgvIdPosture + " Navigating").build();
      } else if (AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + soAgvIdPosture + "_AGV"), false)) {
        return Response.status(400).entity("AGV" + soAgvIdPosture + " controlled by Gesture").build();
      } else {
        AgvTransientData.cooperatingMap.put(("posture_" + soAgvIdPosture + "_AGV"), true);
      }
      LOGGER.info("EM Event ARM_RAISE_BOTH");
    } else if (eventMessage.equals("POSTURE_SQUAT")) {
      AgvTransientData.cooperatingMap.put(("posture_" + soAgvIdPosture + "_AGV"), false);
      LOGGER.info("EM Event POSTURE_SQUAT");
    }

    // Hand Gesture
    Integer soAgvIdGesture = 1;
    AgvMotionAgent agvMotionAgentGesture = new AgvMotionAgent(soAgvIdGesture);
    eventMessage = eventConfig.getMessage();
    Boolean cooperatingGesture = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + soAgvIdGesture + "_AGV"),
        false);
    if (eventMessage.equals("HAND_ROTATE_COUNTERCLOCKWISE") && cooperatingGesture) {
      agvMotionAgentGesture.execTurnLeftSlowly();
      LOGGER.info("EM Event HAND_ROTATE_COUNTERCLOCKWISE");
    } else if (eventMessage.equals("HAND_ROTATE_CLOCKWISE") && cooperatingGesture) {
      agvMotionAgentGesture.execTurnRightSlowly();
      LOGGER.info("EM Event HAND_ROTATE_CLOCKWISE");
    } else if (eventMessage.equals("HAND_HORIZONTAL_LEFT") && cooperatingGesture) {
      agvMotionAgentGesture.execForwardSlowly();
      LOGGER.info("EM Event HAND_HORIZONTAL_LEFT");
    } else if (eventMessage.equals("HAND_HORIZONTAL_REVERSE") && cooperatingGesture) {
      agvMotionAgentGesture.execAgvStop();
      LOGGER.info("EM Event HAND_HORIZONTAL_REVERSE");
    } else if (eventMessage.equals("HAND_HORIZONTAL_RIGHT") && cooperatingGesture) {
      agvMotionAgentGesture.execBackwardSlowly();
      LOGGER.info("EM Event HAND_HORIZONTAL_RIGHT");
    } else if (eventMessage.equals("HAND_GESTURE_ENABLE")) {
      if (AgvTransientData.cooperatingMap.getOrDefault(("posture_" + soAgvIdGesture + "_AGV"), false)) {
        return Response.status(400).entity("AGV" + soAgvIdGesture + " controlled by Posture").build();
      } else {
        AgvTransientData.cooperatingMap.put(("gesture_" + soAgvIdGesture + "_AGV"), true);
      }
      LOGGER.info("EM Event HAND_GESTURE_ENABLE");
    } else if (eventMessage.equals("HAND_GESTURE_DISABLE")) {
      AgvTransientData.cooperatingMap.put(("gesture_" + soAgvIdGesture + "_AGV"), false);
      // AgvTransientData.cooperatingMap.remove("gesture_" + soAgvIdGesture + "_AGV");
      LOGGER.info("EM Event HAND_GESTURE_DISABLE");
    }

    // AGV Navi, AGV Binding soAgvId = 1; AgvMotionAgent agv2MotionAgent = new AgvMotionAgent(soAgvId); if
    // (eventMessage.equals("ARM_RAISE_HIGH_BOTH_MULTI")) { agv2MotionAgent.execAgvConfused(); }

    LOGGER.info("Postting EM Event");

    return Response.status(201).entity("Event Created").build();

  }

  /**
   * Obtains history events of a specific region.
   *
   * @param  regionId  The Region ID
   * @param  startTime Start Time
   * @param  endTime   End Time
   * @return           {@code Response}
   */
  @GET
  @Path("/history/{regionId}")
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains history events "
      + "of a specific region", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getHistoryEventList(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "Start Time", required = false) @QueryParam("startTime") String startTime,
      @ApiParam(value = "End Time", required = false) @QueryParam("endTime") String endTime) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<Event> eventList = new ArrayList<Event>();
    // Unfinished
    List<Event> unfinishedEventList = new ArrayList<Event>(EventTransientData.unfinishedEventMap.values());
    for (Event e : unfinishedEventList) {
      if (e.getEventConfig().getBindingRegionId().equals(regionId)) {
        eventList.add(e);
      }
    }

    DateFormat utcDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    utcDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    Calendar calendar = Calendar.getInstance();
    Date date = new Date();
    Timestamp endDateTime = new Timestamp(date.getTime());
    calendar.setTime(date);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    Timestamp startDateTime = new Timestamp(calendar.getTime().getTime());
    if (startTime != null && endTime != null) {
      try {
        Date startDate = utcDateFormat.parse(startTime);
        Date endDate = utcDateFormat.parse(endTime);
        if (startDate.after(endDate)) {
          return Response.status(400).entity("Invalid time").build();
        }
        startDateTime = new Timestamp(startDate.getTime());
        endDateTime = new Timestamp(endDate.getTime());
      } catch (ParseException e1) {
        LOGGER.error(e1.getMessage());
        return Response.status(400).entity("Invalid time#2").build();
      }
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);
    for (Event e : eventService.getEventList()) {
      // Finished
      if (e.getEventConfig().getBindingRegionId().equals(regionId) && e.getFinished()) {
        if (e.getFinishTime().after(startDateTime) && e.getFinishTime().before(endDateTime)) {
          eventList.add(e);
        }
      }
    }

    LOGGER.info("Fetching EM History Event List");
    GenericEntity<List<Event>> entity = new GenericEntity<List<Event>>(eventList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Obtains unfinished events of a specific region.
   *
   * @param  regionId The Region ID
   * @return          {@code Response}
   */
  @GET
  @Path("/unfinished/{regionId}")
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains unfinished event "
      + "of a specific region", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getUnfinishedEventList(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<Event> eventList = new ArrayList<Event>();
    // Unfinished
    List<Event> unfinishedEventList = new ArrayList<Event>(EventTransientData.unfinishedEventMap.values());
    for (Event e : unfinishedEventList) {
      if (e.getEventConfig().getBindingRegionId().equals(regionId)) {
        eventList.add(e);
      }
    }

    // LOGGER.info("Fetching EM Unfinished Event List");
    GenericEntity<List<Event>> entity = new GenericEntity<List<Event>>(eventList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates the event binding with a specific region.
   *
   * @param  regionId           The Region ID
   * @param  unfinishedEventKey The Event Unfinished Key
   * @return                    {@code Response}
   */
  @PUT
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates the event "
      + "binding with a specific region", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putEvent(@ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "Key", required = true) @QueryParam("unfinishedEventKey") String unfinishedEventKey) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
      // NEW or finished!!
      return Response.status(404).entity("Invalid unfinishedEventKey").build();
    } else {
      // Update notify in memory
      EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setNotified(true);
      EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setNotifyTime(nowTime);
    }

    LOGGER.info("Putting EM Event");
    return Response.status(200).entity("Event Updated").build();
  }

  /**
   * Deletes the event binding with a specific region.
   *
   * @param  regionId           The Region ID
   * @param  unfinishedEventKey The Event Unfinished Key
   * @return                    {@code Response}
   */
  @DELETE
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes the event "
      + "binding with a specific region", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteEvent(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "Key", required = true) @QueryParam("unfinishedEventKey") String unfinishedEventKey) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

    if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
      // NEW or finished!!
      return Response.status(404).entity("Invalid unfinishedEventKey").build();
    } else {
      // Update finish in memory
      Event finishedEvent = EventTransientData.unfinishedEventMap.get(unfinishedEventKey);
      finishedEvent.setFinished(true);
      finishedEvent.setFinishTime(nowTime);
      eventService.updateEvent(finishedEvent);
      EventTransientData.unfinishedEventMap.remove(unfinishedEventKey);
    }

    LOGGER.info("Deleting EM Event");
    return Response.status(204).entity("Event Deleted").build();
  }

  /**
   * Deletes all events.
   *
   * @return {@code Response}
   */
  @DELETE
  @Path("/all")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes all events"
      + "", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteAllEvent() {
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);
    // Update finish in memory
    for (String unfinishedEventKey : EventTransientData.unfinishedEventMap.keySet()) {
      Event finishedEvent = EventTransientData.unfinishedEventMap.get(unfinishedEventKey);
      finishedEvent.setFinished(true);
      finishedEvent.setFinishTime(nowTime);
      eventService.updateEvent(finishedEvent);
    }
    // Refresh memory
    TransientDataUtil.refreshUnfinishedEventMap();

    LOGGER.info("Deleting EM ALL Event");
    return Response.status(204).entity("ALL Event Deleted").build();
  }

  /**
   * Adds intrusion alarm with a specific region.
   *
   * @return {@code Response}
   */
  @SuppressWarnings("unchecked")
  @POST
  @Path("/add_intrusion_alarm")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds intrusion alarm "
      + "with a specific region", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response addIntrusionAlarm() {
    // Delete All Date date = new Date(); Timestamp nowTime = new Timestamp(date.getTime());
    // @SuppressWarnings("resource") ApplicationContext ac = new
    // AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class); EventService eventService =
    // ac.getBean(jcas.jms.model.event.EventService.class); // Update finish in memory for (String unfinishedEventKey :
    // EventTransientData.unfinishedEventMap.keySet()) { Event finishedEvent =
    // EventTransientData.unfinishedEventMap.get(unfinishedEventKey); finishedEvent.setFinished(true);
    // finishedEvent.setFinishTime(nowTime); eventService.updateEvent(finishedEvent); } // Refresh memory
    // TransientDataUtil.refreshUnfinishedEventMap();

    // pre-config
    String regionId = "d5c6bbcfcbc0e0efb00ed68f8ca64e1a";
    EventPostBody postBody = new EventPostBody();
    postBody.setEventName("PERSON_STATUS");
    postBody.setEventType("SENSING_ALARM");
    postBody.setEventMessage("PERSON_INTRUSION");

    List<EventConfig> ecList = new ArrayList<EventConfig>(EventTransientData.ecMap.values());
    EventConfig eventConfig = null;
    for (EventConfig ec : ecList) {
      if (ec.getEventType().equals(postBody.getEventType()) && ec.getEventName().equals(postBody.getEventName())
          && ec.getMessage().equals(postBody.getEventMessage()) && ec.getBindingRegionId().equals(regionId)) {
        eventConfig = ec;
      }
    }

    // Verify eventConfig
    if (eventConfig == null) {
      return Response.status(404).entity("Invalid eventConfig").build();
    }

    // Verify execEnable
    if (!eventConfig.getExecEnable()) {
      return Response.status(400).entity("Event Config Not Enable").build();
    }

    // Verify occurCondition
    if (!eventConfig.getOccurConditionConfig().getOccurEvent()) {
      return Response.status(400).entity("Event Config Occur Condition Error").build();
    }

    // Verify eventType and eventName
    String eventType = eventConfig.getEventType();
    String eventName = eventConfig.getEventName();
    Boolean sensingTrigger = false;
    if (eventType.equals("SENSING_ALARM") && eventName.equals("PERSON_STATUS")) {
      sensingTrigger = true;
    }
    if (!sensingTrigger) {
      return Response.status(400).entity("Event Config Not Allow").build();
    }

    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

    String unfinishedEventKey = Md5Util.getMd5(eventConfig.getEventConfigId() + "_" + postBody.getEventInfo());
    if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
      // NEW!! Insert DB and memory
      Event newEvent = new Event();
      newEvent.setEventConfig(eventConfig);
      newEvent.setCreateTime(nowTime);
      newEvent.setOccurTime(nowTime);
      JSONObject eventInfoJsonObject = new JSONObject();
      eventInfoJsonObject.put("unfinishedEventKey", unfinishedEventKey);
      eventInfoJsonObject.put("extraInfo", postBody.getEventInfo());
      newEvent.setEventInfo(eventInfoJsonObject.toJSONString());
      eventService.addEvent(newEvent);
      // Refresh memory
      TransientDataUtil.refreshUnfinishedEventMap();
    } else {
      // AGAIN!! Update occur time in memory
      EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setOccurTime(nowTime);
    }

    LOGGER.info("Adding EM Intrusion Alarm");

    return Response.status(201).entity("Alarm Created").build();

  }
}