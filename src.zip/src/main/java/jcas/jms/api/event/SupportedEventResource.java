package jcas.jms.api.event;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.event.EventSeverity;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.event.EventType;
import jcas.jms.model.event.SupportedEvent;
import jcas.jms.model.event.SupportedEventService;
import jcas.jms.util.TransientDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * SupportedEventResource is the class for supported event resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/supported-event")
@Api(tags = { "Supported Event API (Event Management)" })
public class SupportedEventResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(SupportedEventResource.class);

  /**
   * Adds the supported event.
   *
   * @param supportedEvent {@code SupportedEvent}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the "
      + "supported event", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postSupportedEvent(
      @ApiParam(value = "Supported Event", required = true) SupportedEvent supportedEvent) {
    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    // Verify supportedEvent
    Integer supportedEventCode = supportedEvent.getSupportedEventCode();
    List<Integer> eventCodeList = new ArrayList<Integer>();
    for (SupportedEvent se : supportedEventList) {
      eventCodeList.add(se.getSupportedEventCode());
    }
    if (eventCodeList.contains(supportedEventCode)) {
      return Response.status(400).entity("Invalid supportedEventCode").build();
    }

    String supportedEventName = supportedEvent.getSupportedEventName();
    List<String> eventNameList = new ArrayList<String>();
    for (SupportedEvent se : supportedEventList) {
      eventNameList.add(se.getSupportedEventName());
    }
    if (!eventNameList.contains(supportedEventName)) {
      return Response.status(400).entity("Invalid supportedEventName").build();
    }

    String supportedEventType = supportedEvent.getSupportedEventType();
    List<String> eventTypeList = new ArrayList<String>();
    for (EventType et : EventType.values()) {
      eventTypeList.add(et.name());
    }
    if (!eventTypeList.contains(supportedEventType) || !supportedEventType.contains("ALARM")) {
      return Response.status(400).entity("Invalid supportedEventType").build();
    }

    String supportedMessage = supportedEvent.getSupportedMessage();
    List<String> messageList = new ArrayList<String>();
    for (SupportedEvent se : supportedEventList) {
      messageList.add(se.getSupportedMessage());
    }
    if (messageList.contains(supportedMessage)) {
      return Response.status(400).entity("Invalid supportedMessage").build();
    }

    if (supportedEventType.equals("CPU_ALARM")) {
      if (supportedEventCode < 6101 || supportedEventCode > 6199) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("CPU")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("MEMORY_ALARM")) {
      if (supportedEventCode < 6201 || supportedEventCode > 6299) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("MEMORY")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("GPU_ALARM")) {
      if (supportedEventCode < 6301 || supportedEventCode > 6399) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("GPU")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("POWER_ALARM")) {
      if (supportedEventCode < 6401 || supportedEventCode > 6499) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("POWER")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    }

    if (supportedEvent.getBuiltIn()) {
      return Response.status(400).entity("Invalid builtIn").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    SupportedEventService supportedEventService = ac.getBean(jcas.jms.model.event.SupportedEventService.class);
    supportedEventService.addSupportedEvent(supportedEvent);
    TransientDataUtil.refreshSupportedEventMap();

    LOGGER.info("Postting EM Supported Event");

    return Response.status(201).entity("Supported Event Created").build();
  }

  /**
   * Obtains the supported event list.
   *
   * @param eventType The Supported Event Type
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains the supported event " + "list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getSupportedEventList(
      @ApiParam(value = "Event Type", required = false) @QueryParam("eventType") String eventType) {
    // Verify eventType
    List<String> eventTypeList = new ArrayList<String>();
    for (EventType et : EventType.values()) {
      eventTypeList.add(et.name());
    }
    if (eventType != null && !eventTypeList.contains(eventType)) {
      return Response.status(400).entity("Invalid eventType").build();
    }

    List<SupportedEvent> tempSupportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>();
    for (SupportedEvent se : tempSupportedEventList) {
      if (eventType == null) {
        // ALL
        supportedEventList.add(se);
      } else if (eventType != null && se.getSupportedEventType().equals(eventType)) {
        supportedEventList.add(se);
      }
    }

    LOGGER.debug("Fetching EM Supported Event List");
    GenericEntity<List<SupportedEvent>> entity = new GenericEntity<List<SupportedEvent>>(supportedEventList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates the supported event.
   *
   * @param supportedEvent {@code SupportedEvent}
   * @return {@code Response}
   */
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates the "
      + "supported event", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putSupportedEvent(
      @ApiParam(value = "Supported Event", required = true) SupportedEvent supportedEvent) {
    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    // Verify supportedEvent
    Integer supportedEventCode = supportedEvent.getSupportedEventCode();
    List<Integer> eventCodeList = new ArrayList<Integer>();
    for (SupportedEvent se : supportedEventList) {
      eventCodeList.add(se.getSupportedEventCode());
    }
    if (!eventCodeList.contains(supportedEventCode)) {
      return Response.status(400).entity("Invalid supportedEventCode").build();
    }

    String supportedEventName = supportedEvent.getSupportedEventName();
    List<String> eventNameList = new ArrayList<String>();
    for (SupportedEvent se : supportedEventList) {
      eventNameList.add(se.getSupportedEventName());
    }
    if (!eventNameList.contains(supportedEventName)) {
      return Response.status(400).entity("Invalid supportedEventName").build();
    }

    String supportedEventType = supportedEvent.getSupportedEventType();
    List<String> eventTypeList = new ArrayList<String>();
    for (EventType et : EventType.values()) {
      eventTypeList.add(et.name());
    }
    if (!eventTypeList.contains(supportedEventType) || !supportedEventType.contains("ALARM")) {
      return Response.status(400).entity("Invalid supportedEventType").build();
    }

    String supportedMessage = supportedEvent.getSupportedMessage();
    List<String> messageList = new ArrayList<String>();
    for (SupportedEvent se : supportedEventList) {
      if (se.getSupportedEventCode() != supportedEventCode) {
        messageList.add(se.getSupportedMessage());
      }
    }
    if (messageList.contains(supportedMessage)) {
      return Response.status(400).entity("Invalid supportedMessage").build();
    }

    if (supportedEventType.equals("CPU_ALARM")) {
      if (supportedEventCode < 6101 || supportedEventCode > 6199) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("CPU")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("MEMORY_ALARM")) {
      if (supportedEventCode < 6201 || supportedEventCode > 6299) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("MEMORY")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("GPU_ALARM")) {
      if (supportedEventCode < 6301 || supportedEventCode > 6399) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("GPU")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    } else if (supportedEventType.equals("POWER_ALARM")) {
      if (supportedEventCode < 6401 || supportedEventCode > 6499) {
        return Response.status(400).entity("Invalid supportedEventCode#2").build();
      }
      if (!supportedEventName.contains("POWER")) {
        return Response.status(400).entity("Invalid supportedEventName#2").build();
      }
    }

    if (supportedEvent.getBuiltIn()) {
      return Response.status(400).entity("Invalid builtIn").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    SupportedEventService supportedEventService = ac.getBean(jcas.jms.model.event.SupportedEventService.class);
    supportedEventService.updateSupportedEvent(supportedEvent);
    TransientDataUtil.refreshSupportedEventMap();

    LOGGER.info("Putting EM Supported Event");
    return Response.status(200).entity("Supported Event Updated").build();
  }

  /**
   * Deletes the supported event.
   *
   * @param seCode The Supported Event Code
   * @return {@code Response}
   */
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes the "
      + "supported event", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteSupportedEvent(
      @ApiParam(value = "Event Code", required = true) @QueryParam("seCode") Integer seCode) {
    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    // Verify seCode
    List<Integer> eventCodeList = new ArrayList<Integer>();
    for (SupportedEvent se : supportedEventList) {
      if (se.getSupportedEventCode() == seCode && se.getBuiltIn()) {
        return Response.status(400).entity("Invalid builtIn").build();
      }
      eventCodeList.add(se.getSupportedEventCode());
    }
    if (!eventCodeList.contains(seCode)) {
      return Response.status(400).entity("Invalid supportedEventCode").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    SupportedEventService supportedEventService = ac.getBean(jcas.jms.model.event.SupportedEventService.class);

    supportedEventService.deleteSupportedEvent(seCode);
    TransientDataUtil.refreshSupportedEventMap();

    LOGGER.info("Deleting EM Supported Event");
    return Response.status(204).entity("Supported Event Deleted").build();
  }

  /**
   * Obtains EM supported severity of a event.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/severity")
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains EM supported severity of a "
      + "event", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getSupportedSeverityList() {
    List<String> supportedSeverityList = new ArrayList<String>();
    for (EventSeverity es : EventSeverity.values()) {
      supportedSeverityList.add(es.name());
    }

    LOGGER.info("Fetching EM Supported Severity List");
    GenericEntity<List<String>> entity = new GenericEntity<List<String>>(supportedSeverityList) {
    };
    return Response.status(200).entity(entity).build();
  }
}
