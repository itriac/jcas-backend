package jcas.jms.api.event;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.event.EventConfig;
import jcas.jms.model.event.EventConfigService;
import jcas.jms.model.event.EventSeverity;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.event.OccurConditionConfig;
import jcas.jms.model.event.SupportedEvent;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.util.TransientDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * EventConfigResource is the class for event config resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/event/config")
@Api(tags = { "Event Config API (Event Management)" })
public class EventConfigResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventConfigResource.class);

  /**
   * Adds the event config binding with a specific region.
   *
   * @param regionId The Region ID
   * @param postBody {@code EventConfigPostBody}
   * @return {@code Response}
   */
  @POST
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds the event "
      + "config binding with a specific region", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postEventConfig(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "The Post Body", required = true) EventConfigPostBody postBody) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    // Verify eventConfig
    Integer eventCode = postBody.getEventCode();
    List<Integer> eventCodeList = new ArrayList<Integer>();
    for (SupportedEvent se : supportedEventList) {
      eventCodeList.add(se.getSupportedEventCode());
    }
    if (!eventCodeList.contains(eventCode)) {
      return Response.status(400).entity("Invalid eventCode").build();
    }

    SupportedEvent supportedEvent = EventTransientData.sem.get(eventCode);

    String eventName = postBody.getEventName();
    if (!eventName.equals(supportedEvent.getSupportedEventName())) {
      return Response.status(400).entity("Invalid eventName").build();
    }

    String eventType = postBody.getEventType();
    if (!eventType.equals(supportedEvent.getSupportedEventType())) {
      return Response.status(400).entity("Invalid eventType").build();
    }

    String severity = postBody.getSeverity();
    List<String> severityList = new ArrayList<String>();
    for (EventSeverity es : EventSeverity.values()) {
      severityList.add(es.name());
    }
    if (!severityList.contains(severity)) {
      return Response.status(400).entity("Invalid severity").build();
    }

    String message = postBody.getMessage();
    if (!message.equals(supportedEvent.getSupportedMessage())) {
      return Response.status(400).entity("Invalid message").build();
    }

    OccurConditionConfig ocConfig = postBody.getOccurConditionConfig();
    Boolean isOccurCondition = false;
    if (ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && ocConfig.getOccurEvent()) {
      isOccurCondition = true;
    }
    if (!isOccurCondition) {
      return Response.status(400).entity("Invalid occurConditionConfig").build();
    }

    String bindingRegionId = postBody.getBindingRegionId();
    if (!bindingRegionId.equals(regionId)) {
      return Response.status(400).entity("Invalid binding regionId #2").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventConfig eventConfig = new EventConfig();
    eventConfig.setEventName(eventName);
    eventConfig.setEventCode(eventCode);
    eventConfig.setEventType(eventType);
    eventConfig.setSeverity(severity);
    eventConfig.setMessage(message);
    eventConfig.setOccurConditionConfig(ocConfig);
    eventConfig.setExecEnable(postBody.getExecEnable());
    eventConfig.setNotifyMethodConfig(postBody.getNotifyMethodConfig());
    eventConfig.setNotifyInterval(postBody.getNotifyInterval());
    eventConfig.setSop(postBody.getSop());
    eventConfig.setBindingRegionId(bindingRegionId);
    EventConfigService eventConfigService = ac.getBean(jcas.jms.model.event.EventConfigService.class);
    eventConfigService.addEventConfig(eventConfig);
    TransientDataUtil.refreshEventConfigMap();

    LOGGER.info("Postting EM Event Config");

    return Response.status(201).entity("Event Config Created").build();
  }

  /**
   * Obtains the event config binding with a specific region.
   *
   * @param regionId The Region ID
   * @return {@code Response}
   */
  @GET
  @Path("/{regionId}")
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains the event config "
      + "binding with a specific region", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getEventConfigList(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<EventConfig> eventConfigList = new ArrayList<EventConfig>();
    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventConfigService eventConfigService = ac.getBean(jcas.jms.model.event.EventConfigService.class);
    for (EventConfig ec : eventConfigService.getEventConfigList()) {
      if (ec.getBindingRegionId().equals(regionId)) {
        eventConfigList.add(ec);
      }
    }

    LOGGER.debug("Fetching EM Event Config List");

    GenericEntity<List<EventConfig>> entity = new GenericEntity<List<EventConfig>>(eventConfigList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates the event config binding with a specific region.
   *
   * @param regionId The Region ID
   * @param putBody  {@code EventConfigPutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates the event "
      + "config binding with a specific region", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putEventConfig(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "The Put Body", required = true) EventConfigPutBody putBody) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>(EventTransientData.sem.values());

    // Verify eventConfig
    Integer eventCode = putBody.getEventCode();
    List<Integer> eventCodeList = new ArrayList<Integer>();
    for (SupportedEvent se : supportedEventList) {
      eventCodeList.add(se.getSupportedEventCode());
    }
    if (!eventCodeList.contains(eventCode)) {
      return Response.status(400).entity("Invalid eventCode").build();
    }

    SupportedEvent supportedEvent = EventTransientData.sem.get(eventCode);

    String eventName = putBody.getEventName();
    if (!eventName.equals(supportedEvent.getSupportedEventName())) {
      return Response.status(400).entity("Invalid eventName").build();
    }

    String eventType = putBody.getEventType();
    if (!eventType.equals(supportedEvent.getSupportedEventType())) {
      return Response.status(400).entity("Invalid eventType").build();
    }

    String severity = putBody.getSeverity();
    List<String> severityList = new ArrayList<String>();
    for (EventSeverity es : EventSeverity.values()) {
      severityList.add(es.name());
    }
    if (!severityList.contains(severity)) {
      return Response.status(400).entity("Invalid severity").build();
    }

    String message = putBody.getMessage();
    if (!message.equals(supportedEvent.getSupportedMessage())) {
      return Response.status(400).entity("Invalid message").build();
    }

    OccurConditionConfig ocConfig = putBody.getOccurConditionConfig();
    Boolean isOccurCondition = false;
    if (ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && ocConfig.getLessThreshold()
        && !ocConfig.getOccurEvent() && ocConfig.getThresholdValue() != null) {
      isOccurCondition = true;
    } else if (!ocConfig.getGreaterThreshold() && !ocConfig.getEqualThreshold() && !ocConfig.getLessThreshold()
        && ocConfig.getOccurEvent()) {
      isOccurCondition = true;
    }
    if (!isOccurCondition) {
      return Response.status(400).entity("Invalid occurConditionConfig").build();
    }

    String bindingRegionId = putBody.getBindingRegionId();
    if (!bindingRegionId.equals(regionId)) {
      return Response.status(400).entity("Invalid binding regionId #2").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventConfigService eventConfigService = ac.getBean(jcas.jms.model.event.EventConfigService.class);

    // Verify eventConfigId
    Boolean isEventConfigExist = false;
    for (EventConfig ec : eventConfigService.getEventConfigList()) {
      if (ec.getEventConfigId() == putBody.getEventConfigId()) {
        isEventConfigExist = true;
        break;
      }
    }
    if (!isEventConfigExist) {
      return Response.status(400).entity("Invalid eventConfigId").build();
    }

    EventConfig eventConfig = new EventConfig();
    eventConfig.setEventConfigId(putBody.getEventConfigId());
    eventConfig.setEventName(eventName);
    eventConfig.setEventCode(eventCode);
    eventConfig.setEventType(eventType);
    eventConfig.setSeverity(severity);
    eventConfig.setMessage(message);
    eventConfig.setOccurConditionConfig(ocConfig);
    eventConfig.setExecEnable(putBody.getExecEnable());
    eventConfig.setNotifyMethodConfig(putBody.getNotifyMethodConfig());
    eventConfig.setNotifyInterval(putBody.getNotifyInterval());
    eventConfig.setSop(putBody.getSop());
    eventConfig.setBindingRegionId(bindingRegionId);
    eventConfigService.updateEventConfig(eventConfig);
    TransientDataUtil.refreshEventConfigMap();

    LOGGER.info("Putting EM Event Config");

    return Response.status(200).entity("Event Config Updated").build();
  }

  /**
   * Deletes the event config binding with a specific region.
   *
   * @param regionId The Region ID
   * @param ecId     The Event Config ID
   * @return {@code Response}
   */
  @DELETE
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes the event "
      + "config binding with a specific region", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteEventConfig(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "EventConfig ID", required = true) @QueryParam("ecId") Integer ecId) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    EventConfigService eventConfigService = ac.getBean(jcas.jms.model.event.EventConfigService.class);

    // Verify ecId
    Boolean isEventConfigExist = false;
    for (EventConfig ec : eventConfigService.getEventConfigList()) {
      if (ec.getEventConfigId() == ecId) {
        isEventConfigExist = true;
        break;
      }
    }
    if (!isEventConfigExist) {
      return Response.status(400).entity("Invalid eventConfigId").build();
    }

    eventConfigService.deleteEventConfig(ecId);
    TransientDataUtil.refreshEventConfigMap();

    LOGGER.info("Deleting EM Event Config");
    return Response.status(204).entity("Event Config Deleted").build();
  }
}
