package jcas.jms.api.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jcas.jms.model.event.NotifyMethodConfig;
import jcas.jms.model.event.OccurConditionConfig;

/**
 * EventConfigPostBody is the class for EventConfigPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("EventConfigPostBody")
public class EventConfigPostBody {
  private String eventName;
  private Integer eventCode;
  private String eventType;
  private String severity;
  private String message;
  private OccurConditionConfig occurConditionConfig;
  private Boolean execEnable;
  private NotifyMethodConfig notifyMethodConfig;
  private Integer notifyInterval;
  private String sop;
  private String bindingRegionId;

  @ApiModelProperty(value = "Name of Event", required = true)
  public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  @ApiModelProperty(value = "Code of Event", required = true)
  public Integer getEventCode() {
    return eventCode;
  }

  public void setEventCode(Integer eventCode) {
    this.eventCode = eventCode;
  }

  @ApiModelProperty(value = "Type of Event", required = true)
  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  @ApiModelProperty(value = "Severity of Event Config", required = true)
  public String getSeverity() {
    return severity;
  }

  public void setSeverity(String severity) {
    this.severity = severity;
  }

  @ApiModelProperty(value = "Message of Event Config", required = true)
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @ApiModelProperty(value = "Occur Condition of Event Config", required = true)
  public OccurConditionConfig getOccurConditionConfig() {
    return occurConditionConfig;
  }

  public void setOccurConditionConfig(OccurConditionConfig occurConditionConfig) {
    this.occurConditionConfig = occurConditionConfig;
  }

  @ApiModelProperty(value = "Exec Enable of Event Config", required = true, example = "true")
  public Boolean getExecEnable() {
    return execEnable;
  }

  public void setExecEnable(Boolean execEnable) {
    this.execEnable = execEnable;
  }

  @ApiModelProperty(value = "Notify Method of Event Config", required = true)
  public NotifyMethodConfig getNotifyMethodConfig() {
    return notifyMethodConfig;
  }

  public void setNotifyMethodConfig(NotifyMethodConfig notifyMethodConfig) {
    this.notifyMethodConfig = notifyMethodConfig;
  }

  @ApiModelProperty(value = "Notify Interval of Event Config", required = true)
  public Integer getNotifyInterval() {
    return notifyInterval;
  }

  public void setNotifyInterval(Integer notifyInterval) {
    this.notifyInterval = notifyInterval;
  }

  @ApiModelProperty(value = "SOP of Event Config", required = false)
  public String getSop() {
    return sop;
  }

  public void setSop(String sop) {
    this.sop = sop;
  }

  @ApiModelProperty(value = "Binding RegionId of Event Config", required = true)
  public String getBindingRegionId() {
    return bindingRegionId;
  }

  public void setBindingRegionId(String bindingRegionId) {
    this.bindingRegionId = bindingRegionId;
  }
}
