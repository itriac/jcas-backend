package jcas.jms.api;

import io.swagger.jaxrs.config.BeanConfig;
import org.eclipse.persistence.jaxb.BeanValidationMode;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.glassfish.jersey.moxy.json.MoxyJsonConfig;
import org.glassfish.jersey.moxy.json.MoxyJsonFeature;
import org.glassfish.jersey.moxy.xml.MoxyXmlFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

/**
 * SwaggerJaxrsConfig is the class for Swagger UI ResourceConfig.
 *
 * @author Industrial Technology Research Institute
 */
public class SwaggerJaxrsConfig extends ResourceConfig {

  /**
   * SwaggerJaxrsConfig constructor.
   */
  public SwaggerJaxrsConfig() {
    BeanConfig beanConfig = new BeanConfig();
    beanConfig.setTitle("JCaS JMS API");
    beanConfig.setDescription("Provided for JCaS JUI or internal component use");
    String projectVersion = System.getProperty("projectVersion");
    beanConfig.setVersion(projectVersion);
    beanConfig.setSchemes(new String[] { "http" });
    String hostUrl = System.getProperty("hostUrl");
    beanConfig.setHost(hostUrl);
    beanConfig.setBasePath("/api");
    beanConfig.setResourcePackage("jcas.jms.api");
    beanConfig.setScan(true);
    property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, Boolean.TRUE);
    packages("jcas.jms.api");
    packages("io.swagger.jaxrs.listing");
    register(MoxyJsonFeature.class);
    register(new MoxyJsonConfig().setFormattedOutput(true)
        .property(MarshallerProperties.BEAN_VALIDATION_MODE, BeanValidationMode.NONE).resolver());
    // Turn off BV otherwise the entities on server would be validated by MOXy
    register(MoxyXmlFeature.class);
    register(RolesAllowedDynamicFeature.class);
  }
}