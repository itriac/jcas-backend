package jcas.jms.api.agv;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvNaviAid;
import jcas.jms.model.agv.AgvTransientData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AgvNaviAidResource is the class for agv navi aid resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/agv/navi/aid")
@Api(tags = { "AGV Navi Aid API (AGV Management)" })
public class AgvNaviAidResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvNaviAidResource.class);

  /**
   * Adds agv navi aid.
   *
   * @param postBody {@code List<NaviAidPostBody>}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds "
      + "agv navi aid", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postAgvNaviAid(@ApiParam(value = "The Post Body", required = true) List<NaviAidPostBody> postBody) {
    for (NaviAidPostBody pb : postBody) {
      String soAgvIdType = pb.getSoAgvId() + "_" + pb.getSoAgvType();

      if (!AgvTransientData.agvNaviMap.containsKey(soAgvIdType)) {
        LOGGER.info("404 " + "Invalid soAgvIdType");
        return Response.status(404).entity("Invalid soAgvIdType").build();
      }

      AgvNavi an = AgvTransientData.agvNaviMap.get(soAgvIdType);
      if (!an.getSoTargetId().equals(pb.getSoTargetId()) || !an.getSoTargetType().equals(pb.getSoTargetType())) {
        LOGGER.info("400 " + "Invalid soTargetIdType");
        return Response.status(400).entity("Invalid soTargetIdType").build();
      }

      AgvNaviAid aid = new AgvNaviAid();
      aid.setSoAgvId(pb.getSoAgvId());
      aid.setSoAgvType(pb.getSoAgvType());
      aid.setSoTargetId(pb.getSoTargetId());
      aid.setSoTargetType(pb.getSoTargetType());
      aid.setAgvTargetAngle(pb.getAgvTargetAngle());
      aid.setAgvTargetDistance(pb.getAgvTargetDistance());
      aid.setCreateTime(pb.getTargetCreateTime());
      aid.setUpdateTime(pb.getTargetUpdateTime());
      // TODO
      AgvTransientData.agvNaviAidMap.put(soAgvIdType, aid);
      // for debug
      LOGGER.info("Posting AM New AgvNaviAid, AGV Id: " + pb.getSoAgvId() + ", Target Id: " + pb.getSoTargetId()
          + ", Angle: " + pb.getAgvTargetAngle() + ", Distance: " + pb.getAgvTargetDistance() + ", Target Time: "
          + pb.getTargetUpdateTime());
    }

    return Response.status(201).entity("All AgvNaviAids Added").build();
  }

  /**
   * Obtains agv navi aid list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains agv navi aid list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getAgvNaviAidList() {
    List<AgvNaviAid> agvNaviAidList = new ArrayList<AgvNaviAid>(AgvTransientData.agvNaviAidMap.values());

    LOGGER.info("Fetching AM AgvNaviAid List");

    GenericEntity<List<AgvNaviAid>> entity = new GenericEntity<List<AgvNaviAid>>(agvNaviAidList) {
    };
    return Response.status(200).entity(entity).build();
  }
}
