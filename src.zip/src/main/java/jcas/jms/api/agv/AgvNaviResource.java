package jcas.jms.api.agv;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.vecmath.Point3d;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.agv.NaviRoute;
import jcas.jms.model.agv.NaviTrajectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AgvNaviResource is the class for agv navi resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/agv/navi")
@Api(tags = { "AGV Navi API (AGV Management)" })
public class AgvNaviResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvNaviResource.class);
  private Boolean agvOrigin = true;

  /**
   * Starts agv navi.
   *
   * @param soTargetId      The target sensing object id
   * @param soTargetType    The target sensing object type
   * @param targetRegionId  The target locating region id
   * @param targetPositionX The target x position
   * @param targetPositionY The target y position
   * @param targetPositionZ The target z position
   * @param soAgvId         The agv sensing object id
   * @param soAgvType       The agv sensing object type
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Starts "
      + "agv navi", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postAgvNavi(
      @ApiParam(value = "The Target ID", required = false) @QueryParam("soTargetId") String soTargetId,
      @ApiParam(value = "The Target Type", required = false) @QueryParam("soTargetType") String soTargetType,
      @ApiParam(value = "The Target Region ID", required = false) @QueryParam("targetRegionId") String targetRegionId,
      @ApiParam(value = "The X Position", required = false) @QueryParam("targetPositionX") Double targetPositionX,
      @ApiParam(value = "The Y Position", required = false) @QueryParam("targetPositionY") Double targetPositionY,
      @ApiParam(value = "The Z Position", required = false) @QueryParam("targetPositionZ") Double targetPositionZ,
      @ApiParam(value = "The AGV ID", required = true) @QueryParam("soAgvId") String soAgvId,
      @ApiParam(value = "The AGV Type", required = true) @QueryParam("soAgvType") String soAgvType) {
    // Verify targetPosition
    if ((soTargetId == null || soTargetType == null || targetRegionId == null)
        && (targetPositionX == null || targetPositionY == null || targetPositionZ == null)) {
      LOGGER.info("400 " + "Invalid targetPosition");
      return Response.status(400).entity("Invalid targetPosition").build();
    }

    // Verify cooperation
    Boolean cooperatingPosture = AgvTransientData.cooperatingMap.getOrDefault(("posture_" + soAgvId + "_AGV"), false);
    Boolean cooperatingGesture = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + soAgvId + "_AGV"), false);
    if (cooperatingPosture || cooperatingGesture) {
      return Response.status(400).entity("Invalid soAgvId").build();
    }

    String naviType = "fixed";
    String regionSoTargetIdType = "";
    Point3d positionTarget = new Point3d();
    String navigatingKey = "";
    if (soTargetId != null && soTargetType != null && targetRegionId != null) {
      naviType = "following";
      regionSoTargetIdType = targetRegionId + "_" + soTargetId + "_" + soTargetType;
      navigatingKey = regionSoTargetIdType + "_" + soAgvId + "_" + soAgvType;
    } else {
      positionTarget.x = targetPositionX;
      positionTarget.y = targetPositionY;
      positionTarget.z = targetPositionZ;
      navigatingKey = soAgvId + "_" + soAgvType;
    }

    // Verify Navigating
    // if (AgvTransientData.navigatingMap.containsKey(navigatingKey)) {
    // LOGGER.info("400 " + navigatingKey + " is Navigating");
    // return Response.status(400).entity(navigatingKey + " is Navigating").build();
    // }

    AgvNavi agvNavi = new AgvNavi();
    agvNavi.setSoAgvId(soAgvId);
    agvNavi.setSoAgvType(soAgvType);
    if (naviType.equalsIgnoreCase("following")) {
      agvNavi.setSoTargetId(soTargetId);
      agvNavi.setSoTargetType(soTargetType);
      agvNavi.setTargetRegionId(targetRegionId);
    }
    agvNavi.setNaviType(naviType);
    agvNavi.setAgvMotion("");
    agvNavi.setNaviStatus("init");
    agvNavi.setHistoryTrajectorys(new ArrayList<NaviTrajectory>());
    agvNavi.setPlanningRoutes(new ArrayList<NaviRoute>());

    String soAgvIdType = soAgvId + "_" + soAgvType;
    AgvTransientData.agvNaviMap.put(soAgvIdType, agvNavi);

    AgvNaviThread agvNaviThread = new AgvNaviThread(regionSoTargetIdType, positionTarget, soAgvIdType, naviType);
    AgvTransientData.agvNaviThreadMap.put(soAgvIdType, agvNaviThread);
    AgvTransientData.navigatingMap.put(navigatingKey, true);

    AgvTransientData.executorService.submit(agvNaviThread);

    LOGGER.info("Posting AM New AgvNavi: " + navigatingKey);
    return Response.status(201).entity(soAgvType + soAgvId + " Starts Navigating to " + soTargetType + soTargetId)
        .build();
  }

  /**
   * Obtains agv navi list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains agv navi list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getAgvNaviList() {
    List<AgvNavi> agvNaviList = new ArrayList<AgvNavi>(AgvTransientData.agvNaviMap.values());

    // LOGGER.info("Fetching AM AgvNavi List");

    GenericEntity<List<AgvNavi>> entity = new GenericEntity<List<AgvNavi>>(agvNaviList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Interrupts agv navi.
   *
   * @param soTargetId     The target sensing object id
   * @param soTargetType   The target sensing object type
   * @param targetRegionId The target locating region id
   * @param soAgvId        The agv sensing object id
   * @param soAgvType      The agv sensing object type
   * @return {@code Response}
   */
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Interrupts "
      + "agv navi", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteAgvNavi(
      @ApiParam(value = "The Target ID", required = false) @QueryParam("soTargetId") String soTargetId,
      @ApiParam(value = "The Target Type", required = false) @QueryParam("soTargetType") String soTargetType,
      @ApiParam(value = "The Target Region ID", required = false) @QueryParam("targetRegionId") String targetRegionId,
      @ApiParam(value = "The AGV ID", required = true) @QueryParam("soAgvId") String soAgvId,
      @ApiParam(value = "The AGV Type", required = true) @QueryParam("soAgvType") String soAgvType) {
    LOGGER.info("deleteAgvNavi Start, agvOrigin: " + agvOrigin);

    if (soTargetId != null && soTargetType != null && targetRegionId != null) {
      AgvTransientData.navigatingMap
          .put((targetRegionId + "_" + soTargetId + "_" + soTargetType + "_" + soAgvId + "_" + soAgvType), false);
    } else {
      AgvTransientData.navigatingMap.put((soAgvId + "_" + soAgvType), false);
    }

    if (AgvTransientData.agvNaviThreadMap.containsKey(soAgvId + "_" + soAgvType)) {
      AgvTransientData.agvNaviThreadMap.get(soAgvId + "_" + soAgvType).stop();
      if (agvOrigin) {
        try {
          Thread.sleep(4000);
        } catch (InterruptedException e) {
          LOGGER.error(e.getMessage());
        }
      }
    }

    if (soTargetId != null && soTargetType != null && targetRegionId != null) {
      AgvTransientData.navigatingMap
          .remove(targetRegionId + "_" + soTargetId + "_" + soTargetType + "_" + soAgvId + "_" + soAgvType);
    } else {
      AgvTransientData.navigatingMap.remove(soAgvId + "_" + soAgvType);
    }

    LOGGER.info("Deleting AM AgvNavi: " + soAgvType + soAgvId + " to " + soTargetType + soTargetId);
    return Response.status(204).entity(soAgvType + soAgvId + " Stops Navigating to " + soTargetType + soTargetId)
        .build();
  }
}
