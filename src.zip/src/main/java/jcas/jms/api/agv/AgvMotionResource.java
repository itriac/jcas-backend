package jcas.jms.api.agv;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.mqtt.MqttAgent;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AgvMotionResource is the class for agv motion resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/agv/motion")
@Api(tags = { "AGV Motion API (AGV Management)" })
public class AgvMotionResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvMotionResource.class);

  /**
   * Controls agv motion.
   *
   * @param soAgvId     The agv sensing object id
   * @param soAgvType   The agv sensing object type
   * @param agvControl  The agv control
   * @param agvSpeed    The agv speed
   * @param agvInterval The agv interval
   * @return {@code Response}
   */
  @SuppressWarnings("unchecked")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Controls "
      + "agv motion", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postAgvMotion(@ApiParam(value = "The AGV ID", required = true) @QueryParam("soAgvId") String soAgvId,
      @ApiParam(value = "The AGV Type", required = true) @QueryParam("soAgvType") String soAgvType,
      @ApiParam(value = "The AGV Control", required = true) @QueryParam("agvControl") String agvControl,
      @ApiParam(value = "The AGV Speed", required = true) @QueryParam("agvSpeed") Double agvSpeed,
      @ApiParam(value = "The AGV Interval", required = true) @QueryParam("agvInterval") Double agvInterval) {
    // MQTT
    Boolean mqttEnable = Boolean.parseBoolean(System.getProperty("mqttEnable"));
    if (mqttEnable) {
      if (agvInterval == 0.0) {
        AgvMotionAgent agvMotionAgent = new AgvMotionAgent(Integer.valueOf(soAgvId));
        if (agvControl.equals("stop")) {
          agvMotionAgent.execAgvStop();
        } else if (agvControl.equals("forward")) {
          agvMotionAgent.execForwardSlowly();
        } else if (agvControl.equals("backward")) {
          agvMotionAgent.execBackwardSlowly();
        } else if (agvControl.equals("left")) {
          agvMotionAgent.execTurnLeftSlowly();
        } else if (agvControl.equals("right")) {
          agvMotionAgent.execTurnRightSlowly();
        }
      } else {
        JSONObject agvJsonObject = new JSONObject();
        agvJsonObject.put("agvControl", agvControl);
        agvJsonObject.put("agvSpeed", agvSpeed);
        agvJsonObject.put("agvInterval", agvInterval);
        // String mqttTopic = System.getProperty("mqttTopic");
        String mqttTopic = "k300_agv_" + soAgvId + "/motion";
        String agvMessage = agvJsonObject.toJSONString();
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMessage);
      }
    }

    LOGGER.info("Posting AM New AgvMotion: " + soAgvType + soAgvId);
    return Response.status(201)
        .entity(soAgvType + soAgvId + " " + agvControl + ", by speed: " + agvSpeed + ", for seconds: " + agvInterval)
        .build();
  }

  /**
   * Controls agv appear confused.
   *
   * @param soAgvId   The agv sensing object id
   * @param soAgvType The agv sensing object type
   * @return {@code Response}
   */
  @SuppressWarnings("unchecked")
  @POST
  @Path("/confused")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Controls "
      + "agv appear confused", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postAgvConfused(
      @ApiParam(value = "The AGV ID", required = true) @QueryParam("soAgvId") String soAgvId,
      @ApiParam(value = "The AGV Type", required = true) @QueryParam("soAgvType") String soAgvType) {
    // MQTT
    Boolean mqttEnable = Boolean.parseBoolean(System.getProperty("mqttEnable"));
    if (mqttEnable) {
      String mqttTopic = "k300_agv_" + soAgvId + "/motion";
      JSONObject agvJsonObject = new JSONObject();
      String agvMessage = "";

      for (int i = 0; i < 2; i++) {
        agvJsonObject.put("agvControl", "right");
        agvJsonObject.put("agvSpeed", 0.8);
        agvJsonObject.put("agvInterval", 1);
        agvMessage = agvJsonObject.toJSONString();
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMessage);

        agvJsonObject.put("agvControl", "left");
        agvJsonObject.put("agvSpeed", 0.8);
        agvJsonObject.put("agvInterval", 2);
        agvMessage = agvJsonObject.toJSONString();
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMessage);

        agvJsonObject.put("agvControl", "right");
        agvJsonObject.put("agvSpeed", 0.8);
        agvJsonObject.put("agvInterval", 1);
        agvMessage = agvJsonObject.toJSONString();
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMessage);
      }

    }
    LOGGER.info("Posting AM New AgvMotion Confused: " + soAgvType + soAgvId);
    return Response.status(201).entity(soAgvType + soAgvId + " Motion Confused").build();
  }

  /**
   * Obtains agv cooperating status.
   *
   * @return {@code Response}
   */
  @GET
  @Path("/cooperating")
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(produces = "text/plain", value = "Obtains agv cooperating status", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getAgvCooperatingStatus() {
    // AGV Motion, AGV Binding
    String responseString = "";
    Boolean cooperatingPosture0 = AgvTransientData.cooperatingMap.getOrDefault(("posture_" + 0 + "_AGV"), false);
    responseString = "AGV0 posture : " + cooperatingPosture0 + ", ";
    Boolean cooperatingGesture0 = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + 0 + "_AGV"), false);
    responseString += "AGV0 gesture : " + cooperatingGesture0 + ", ";
    Boolean cooperatingPosture1 = AgvTransientData.cooperatingMap.getOrDefault(("posture_" + 1 + "_AGV"), false);
    responseString += "AGV1 posture : " + cooperatingPosture1 + ", ";
    Boolean cooperatingGesture1 = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + 1 + "_AGV"), false);
    responseString += "AGV1 gesture : " + cooperatingGesture1;

    return Response.status(200).entity(responseString).build();
  }
}
