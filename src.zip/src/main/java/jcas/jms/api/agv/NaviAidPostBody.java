package jcas.jms.api.agv;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.sql.Timestamp;

/**
 * NaviAidPostBody is the class for NaviAidPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("NaviAidPostBody")
public class NaviAidPostBody {
  private String soAgvId;
  private String soAgvType;
  private String soTargetId;
  private String soTargetType;
  private Double agvTargetAngle;
  private Double agvTargetDistance;
  private Timestamp targetCreateTime;
  private Timestamp targetUpdateTime;

  @ApiModelProperty(value = "ID of AGV", required = true)
  public String getSoAgvId() {
    return soAgvId;
  }

  public void setSoAgvId(String soAgvId) {
    this.soAgvId = soAgvId;
  }

  @ApiModelProperty(value = "Type of AGV", required = true)
  public String getSoAgvType() {
    return soAgvType;
  }

  public void setSoAgvType(String soAgvType) {
    this.soAgvType = soAgvType;
  }

  @ApiModelProperty(value = "ID of Target", required = true)
  public String getSoTargetId() {
    return soTargetId;
  }

  public void setSoTargetId(String soTargetId) {
    this.soTargetId = soTargetId;
  }

  @ApiModelProperty(value = "Type of Target", required = true)
  public String getSoTargetType() {
    return soTargetType;
  }

  public void setSoTargetType(String soTargetType) {
    this.soTargetType = soTargetType;
  }

  @ApiModelProperty(value = "Angle between AGV and Target", required = true)
  public Double getAgvTargetAngle() {
    return agvTargetAngle;
  }

  public void setAgvTargetAngle(Double agvTargetAngle) {
    this.agvTargetAngle = agvTargetAngle;
  }

  @ApiModelProperty(value = "Distance between AGV and Target", required = true)
  public Double getAgvTargetDistance() {
    return agvTargetDistance;
  }

  public void setAgvTargetDistance(Double agvTargetDistance) {
    this.agvTargetDistance = agvTargetDistance;
  }

  @ApiModelProperty(value = "Create Time of Target", required = true)
  public Timestamp getTargetCreateTime() {
    return targetCreateTime;
  }

  public void setTargetCreateTime(Timestamp targetCreateTime) {
    this.targetCreateTime = targetCreateTime;
  }

  @ApiModelProperty(value = "Update Time of Target", required = true)
  public Timestamp getTargetUpdateTime() {
    return targetUpdateTime;
  }

  public void setTargetUpdateTime(Timestamp targetUpdateTime) {
    this.targetUpdateTime = targetUpdateTime;
  }

}
