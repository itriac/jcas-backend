package jcas.jms.api.agv;

import jcas.jms.mqtt.MqttAgent;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AgvMotionAgent is the class to control motion of AGV.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvMotionAgent {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvMotionAgent.class);
  private Boolean mqttEnable = Boolean.parseBoolean(System.getProperty("mqttEnable"));
  private Integer soAgvId;
  private String mqttTopicMotion;
  private String mqttTopicStop;
  private Double turnSpeed = 0.9;
  private Double turnRatio = 0.6; // 30 degree
  private Double turnLeftSpeedSlowly = 0.7;
  private Double turnRightSpeedSlowly = 0.7;
  private Double forwardSpeed = 1.0;
  private Double forwardSpeedSlowly = 0.6;
  private Double backwardSpeed = 1.0;
  private Double backwardSpeedSlowly = 0.5;

  /**
   * AgvMotionAgent constructor.
   *
   * @param soAgvId The agv sensing object id
   */
  public AgvMotionAgent(Integer soAgvId) {
    super();
    this.soAgvId = soAgvId;
    mqttTopicMotion = "k300_agv_" + soAgvId + "/motion";
    mqttTopicStop = "k300_agv_" + soAgvId + "/stop";
    if (soAgvId == 0) {
      turnSpeed = 0.8;
      turnRatio = 0.33;
      turnLeftSpeedSlowly = 0.7;
      turnRightSpeedSlowly = 0.7;
      forwardSpeed = 0.6;
      forwardSpeedSlowly = 0.65;
      backwardSpeed = 0.6;
      backwardSpeedSlowly = 0.65;
    } else if (soAgvId == 1) {
      turnSpeed = 0.8;
      turnRatio = 0.33;
      turnLeftSpeedSlowly = 0.6;
      turnRightSpeedSlowly = 0.6;
      forwardSpeed = 0.6;
      forwardSpeedSlowly = 0.5;
      backwardSpeed = 0.6;
      backwardSpeedSlowly = 0.5;
    }
  }

  public Integer getSoAgvId() {
    return soAgvId;
  }

  /**
   * soAgvId setter.
   *
   * @param soAgvId The agv sensing object id
   */
  public void setSoAgvId(Integer soAgvId) {
    this.soAgvId = soAgvId;
    mqttTopicMotion = "k300_agv_" + soAgvId + "/motion";
    mqttTopicStop = "k300_agv_" + soAgvId + "/stop";
  }

  /**
   * AGV Turn Left 30 Degrees.
   */
  @SuppressWarnings("unchecked")
  public void execTurnLeft30Degrees() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "left");
      agvJsonObject.put("agvSpeed", turnSpeed);
      agvJsonObject.put("agvInterval", 1 * turnRatio);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Turn Left 30 Degrees");
    }
  }

  /**
   * AGV Turn Left 180 Degrees.
   */
  @SuppressWarnings("unchecked")
  public void execTurnLeft180Degrees() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "left");
      agvJsonObject.put("agvSpeed", turnSpeed);
      agvJsonObject.put("agvInterval", 6 * turnRatio);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Turn Left 180 Degrees");
    }
  }

  /**
   * AGV Turn Left Slowly.
   */
  @SuppressWarnings("unchecked")
  public void execTurnLeftSlowly() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "left");
      agvJsonObject.put("agvSpeed", turnLeftSpeedSlowly);
      // agvJsonObject.put("agvInterval", 120);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Turn Left Slowly");
    }
  }

  /**
   * AGV Turn Right 30 Degrees.
   */
  @SuppressWarnings("unchecked")
  public void execTurnRight30Degrees() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "right");
      agvJsonObject.put("agvSpeed", turnSpeed);
      agvJsonObject.put("agvInterval", 1 * turnRatio);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Turn Right 30 Degrees");
    }
  }

  /**
   * AGV Turn Right Slowly.
   */
  @SuppressWarnings("unchecked")
  public void execTurnRightSlowly() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "right");
      agvJsonObject.put("agvSpeed", turnRightSpeedSlowly);
      // agvJsonObject.put("agvInterval", 120);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Turn Right Slowly");
    }
  }

  /**
   * AGV Forward 1 Second.
   */
  @SuppressWarnings("unchecked")
  public void execForward1Second() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "forward");
      agvJsonObject.put("agvSpeed", forwardSpeed);
      agvJsonObject.put("agvInterval", 1);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Forward 1 Second");
    }
  }

  /**
   * AGV Forward Slowly.
   */
  @SuppressWarnings("unchecked")
  public void execForwardSlowly() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "forward");
      agvJsonObject.put("agvSpeed", forwardSpeedSlowly);
      // agvJsonObject.put("agvInterval", 120);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Forward Slowly");
    }
  }

  /**
   * AGV Backward 1 Second.
   */
  @SuppressWarnings("unchecked")
  public void execBackward1Second() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "backward");
      agvJsonObject.put("agvSpeed", backwardSpeed);
      agvJsonObject.put("agvInterval", 1);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Backward 1 Second");
    }
  }

  /**
   * AGV Backward 0.5 Second.
   */
  @SuppressWarnings("unchecked")
  public void execBackwardHalfSecond() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "backward");
      agvJsonObject.put("agvSpeed", backwardSpeed);
      agvJsonObject.put("agvInterval", 0.5);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Backward 0.5 Second");
    }
  }

  /**
   * AGV Backward 0.5 Speed 0.5 Second.
   */
  @SuppressWarnings("unchecked")
  public void execRebound() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "backward");
      agvJsonObject.put("agvSpeed", 0.5);
      agvJsonObject.put("agvInterval", 0.5);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Backward 0.5 Speed 0.5 Second");
    }
  }

  /**
   * AGV Backward Slowly.
   */
  @SuppressWarnings("unchecked")
  public void execBackwardSlowly() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      agvJsonObject.put("agvControl", "backward");
      agvJsonObject.put("agvSpeed", backwardSpeedSlowly);
      // agvJsonObject.put("agvInterval", 120);
      MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      LOGGER.info("AGV" + soAgvId + " Backward Slowly");
    }
  }

  /**
   * AGV Confused.
   */
  @SuppressWarnings("unchecked")
  public void execAgvConfused() {
    if (mqttEnable) {
      JSONObject agvJsonObject = new JSONObject();
      for (int i = 0; i < 2; i++) {
        agvJsonObject.put("agvControl", "right");
        agvJsonObject.put("agvSpeed", turnSpeed);
        agvJsonObject.put("agvInterval", 1 * turnRatio);
        MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());

        agvJsonObject.put("agvControl", "left");
        agvJsonObject.put("agvSpeed", turnSpeed);
        agvJsonObject.put("agvInterval", 2 * turnRatio);
        MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());

        agvJsonObject.put("agvControl", "right");
        agvJsonObject.put("agvSpeed", turnSpeed);
        agvJsonObject.put("agvInterval", 1 * turnRatio);
        MqttAgent.getInstance().executeMqttPublish(mqttTopicMotion, agvJsonObject.toJSONString());
      }
      LOGGER.info("AGV" + soAgvId + " Confused");
    }
  }

  /**
   * AGV Stop.
   */
  public void execAgvStop() {
    if (mqttEnable) {
      MqttAgent.getInstance().executeMqttPublish(mqttTopicStop, "stop");
      LOGGER.info("AGV" + soAgvId + " Stop");
    }
  }
}
