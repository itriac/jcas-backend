package jcas.jms.api.agv;

import java.awt.Polygon;
import java.awt.geom.Line2D;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.vecmath.Point2d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvNaviAid;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.agv.NaviRoute;
import jcas.jms.model.agv.NaviTrajectory;
import jcas.jms.model.agv.RoutePoint;
import jcas.jms.model.region.Anchor;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.BlockageCluster;
import jcas.jms.model.sensing.BlockagePoint;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import jcas.jms.mqtt.MqttAgent;
import jcas.jms.util.SpaceUtil;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AgvNaviThread is the class to navi agv.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvNaviThread implements Runnable {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvNaviThread.class);

  private String regionSoTargetIdType;
  private Point3d positionTargetFixed;
  private String soAgvIdType;
  private String naviType;
  private Boolean naviContinue = true;
  private Boolean naviRoutePlanning = true;

  /**
   * AgvNaviThread constructor.
   *
   * @param regionSoTargetIdType The Target Key
   * @param positionTargetFixed  {@code Point3d}
   * @param soAgvIdType          The AGV Key
   * @param naviType             The navi type
   */
  public AgvNaviThread(String regionSoTargetIdType, Point3d positionTargetFixed, String soAgvIdType, String naviType) {
    super();
    this.regionSoTargetIdType = regionSoTargetIdType;
    this.positionTargetFixed = positionTargetFixed;
    this.soAgvIdType = soAgvIdType;
    this.naviType = naviType;
  }

  @SuppressWarnings("unchecked")
  @Override
  public void run() {
    String navigatingKey = "";
    AgvNavi an = AgvTransientData.agvNaviMap.get(soAgvIdType);
    // AGV
    Double pauseDistance = 50.0; // cm
    Double pauseAidDistance = 60.0;
    Double turnSpeed = 0.9;
    Double turnRatio = 0.6; // 30 degree
    Long turnDelay = 300L; // ms
    Double turnAroundSpeed = 1.0;
    Double turnAroundLeftInterval = 2.6; // s
    Double turnAroundRightInterval = 2.6; // s
    Long turnAroundDelay = 300L; // ms
    Double forwardSpeed = 1.0;
    Double forwardInterval = 1.0; // 50cm or 25cm
    Double forwardInitInterval = 1.0; // 50cm
    Long forwardDelay = 300L; // ms
    Double shakeSpeed = 0.8;
    Double shakeInterval = 0.2;

    if (naviType.equalsIgnoreCase("fixed")) {
      pauseDistance = 30.0;
      navigatingKey = soAgvIdType;
    } else {
      pauseDistance = 70.0;
      navigatingKey = regionSoTargetIdType + "_" + soAgvIdType;
    }

    LOGGER.info(navigatingKey + " Navi Start");
    LOGGER.info(
        navigatingKey + " Navi Pause Threshold Distance: " + pauseDistance + ", AidDistance: " + pauseAidDistance);

    String soAgvId = soAgvIdType.split("_")[0];

    // Boolean mqttEnable = Boolean.parseBoolean(System.getProperty("mqttEnable"));
    // String mqttTopic = System.getProperty("mqttTopic");

    // for unit testing
    Boolean mqttEnable = true;
    String mqttTopic = "k300_agv_" + soAgvId + "/motion";
    //
    if (soAgvId.equals("0")) {
      turnSpeed = 0.8;
      turnRatio = 0.33;
      turnAroundSpeed = 0.8;
      turnAroundLeftInterval = 2.1;
      turnAroundRightInterval = 1.9;
      forwardSpeed = 0.6;
      forwardInterval = 1.11;
      forwardInitInterval = 1.11;
      shakeSpeed = 0.6;
      shakeInterval = 0.1;
    } else if (soAgvId.equals("1")) {
      turnSpeed = 0.8;
      turnRatio = 0.4;
      turnAroundSpeed = 0.8;
      turnAroundLeftInterval = 2.3;
      turnAroundRightInterval = 2.1;
      forwardSpeed = 1.0;
      forwardInterval = 0.5;
      forwardInitInterval = 0.5;
      shakeSpeed = 0.6;
      shakeInterval = 0.1;
    }

    JSONObject agvMotionJsonObject = new JSONObject();
    SensingObject soAgv = null;
    Boolean naviInit = false;
    Point3d positionAgvOrigin = new Point3d();
    Integer agvInitNotFoundConsecutiveTimes = 0;
    Boolean agvOrigin = true;

    while (naviContinue && AgvTransientData.navigatingMap.get(navigatingKey) && soAgv == null) {
      // turn around
      if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable) {
        agvMotionJsonObject.put("agvControl", "left");
        agvMotionJsonObject.put("agvSpeed", turnAroundSpeed);
        agvMotionJsonObject.put("agvInterval", turnAroundLeftInterval);
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
        an.setAgvMotion("left");
        an.setNaviStatus("init");
        try {
          Thread.sleep(Double.valueOf(turnAroundLeftInterval * 1000).longValue() + turnAroundDelay);
        } catch (InterruptedException e) {
          LOGGER.error(e.getMessage());
        }
        LOGGER.info(navigatingKey + " AGV Init, Turn Around");
        naviInit = true;
      }
      if (SensingObjectTransientData.soMap.containsKey(soAgvIdType)) {
        List<SensingObject> soAgvList = SensingObjectTransientData.soMap.get(soAgvIdType);
        soAgv = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        for (SensingObject s : soAgvList) {
          soAgv.setSoId(s.getSoId());
          soAgv.setSoType(s.getSoType());
          soAgv.setCreateTime(s.getCreateTime());
          soAgv.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
          soAgv.setLocatingRegionId(s.getLocatingRegionId());
        }
        positionX = positionX / soAgvList.size();
        positionZ = positionZ / soAgvList.size();
        velocityX = velocityX / soAgvList.size();
        velocityY = velocityY / soAgvList.size();
        velocityZ = velocityZ / soAgvList.size();
        soAgv.setPositionX(positionX);
        soAgv.setPositionY(0.0);
        soAgv.setPositionZ(positionZ);
        soAgv.setVelocityX(velocityX);
        soAgv.setVelocityY(velocityY);
        soAgv.setVelocityZ(velocityZ);
        LOGGER.info(navigatingKey + " AGV Init, Position: (" + soAgv.getPositionX() + ", " + soAgv.getPositionY() + ", "
            + soAgv.getPositionZ() + "), Time: " + soAgv.getUpdateTime());
        positionAgvOrigin.x = soAgv.getPositionX();
        positionAgvOrigin.y = soAgv.getPositionY();
        positionAgvOrigin.z = soAgv.getPositionZ();

        NaviTrajectory nt = new NaviTrajectory();
        nt.setPositionX(soAgv.getPositionX());
        nt.setPositionY(soAgv.getPositionY());
        nt.setPositionZ(soAgv.getPositionZ());
        nt.setCreateTime(soAgv.getCreateTime());
        if (an.getHistoryTrajectorys().isEmpty()) {
          an.getHistoryTrajectorys().add(nt);
        } else {
          Integer historyTrajectorysSize = an.getHistoryTrajectorys().size();
          NaviTrajectory agvLastestPoint = an.getHistoryTrajectorys().get(historyTrajectorysSize - 1);
          if (agvLastestPoint.getPositionX() != soAgv.getPositionX()
              || agvLastestPoint.getPositionY() != soAgv.getPositionY()
              || agvLastestPoint.getPositionZ() != soAgv.getPositionZ()) {
            an.getHistoryTrajectorys().add(nt);
          }
        }

        agvInitNotFoundConsecutiveTimes = 0;
      } else {
        agvInitNotFoundConsecutiveTimes++;
        LOGGER.info(navigatingKey + " AGV Not Found #1, ConsecutiveTimes: " + agvInitNotFoundConsecutiveTimes);
        if (agvInitNotFoundConsecutiveTimes > 2) {
          AgvTransientData.navigatingMap.put(navigatingKey, false);
          LOGGER.info(navigatingKey + " Navi Force Interrupt, AGV Not Found #1");
          an.setAgvMotion("stop");
          an.setNaviStatus("interrupt");
          break;
        }
      }
    }

    SensingObject soAgvNext = soAgv;
    SensingObject soTargetNext = null;
    AgvNaviAid aid = new AgvNaviAid();
    Boolean naviPause = false;
    Boolean agvLost = false;
    Boolean agvShift = false;
    Integer shiftConsecutiveTimes = 0;
    Point3d positionAgvShift = null;
    Double shiftMaxAngle = Math.PI * 3 / 2; // Math.PI * 4 / 3
    Double shiftMinAngle = Math.PI * 1 / 2; // Math.PI * 2 / 3
    Double naviAidAngle = 0.0;
    Double naviAidDistance = 0.0;
    Boolean naviAid = false;
    Integer personNotFoundConsecutiveTimes = 0;
    Point3d positionAgv = new Point3d();
    Point3d positionAgvNext = new Point3d();
    Point3d positionTarget = new Point3d();
    Point3d positionTargetNext = new Point3d();
    Boolean targetMove = false;
    Boolean naviHandover = false;
    Boolean naviRouting = false;
    Boolean cooperatingGesture = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + soAgvId + "_AGV"), false);

    while (naviContinue && AgvTransientData.navigatingMap.get(navigatingKey) && soAgv != null) {
      LOGGER.info(navigatingKey + " Navigating");
      an.setAgvMotion("stop");
      an.setNaviStatus("running");

      cooperatingGesture = AgvTransientData.cooperatingMap.getOrDefault(("gesture_" + soAgvId + "_AGV"), false);
      LOGGER.info(navigatingKey + " cooperatingGesture: " + cooperatingGesture);
      if (cooperatingGesture) {
        an.setAgvMotion("hand");
        an.setNaviStatus("gesture");
      }

      if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !naviPause && !agvLost && !agvShift
          && !cooperatingGesture) {
        agvMotionJsonObject.put("agvControl", "forward");
        agvMotionJsonObject.put("agvSpeed", forwardSpeed);
        agvMotionJsonObject.put("agvInterval", forwardInterval);
        if (naviInit) {
          agvMotionJsonObject.put("agvInterval", forwardInitInterval);
        }
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
        an.setAgvMotion("forward");
        an.setNaviStatus("running");
        try {
          if (naviInit) {
            Thread.sleep(Double.valueOf(forwardInitInterval * 1000).longValue() + forwardDelay);
          } else {
            Thread.sleep(Double.valueOf(forwardInterval * 1000).longValue() + forwardDelay);
          }
        } catch (InterruptedException e) {
          LOGGER.error(e.getMessage());
        }
        LOGGER.info(navigatingKey + " AGV Forward: " + forwardInterval + "s");
      }

      if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !naviPause && naviInit
          && !cooperatingGesture) {
        agvMotionJsonObject.put("agvControl", "left");
        agvMotionJsonObject.put("agvSpeed", turnAroundSpeed);
        agvMotionJsonObject.put("agvInterval", turnAroundLeftInterval);
        MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
        an.setAgvMotion("left");
        an.setNaviStatus("locating");
        try {
          Thread.sleep(Double.valueOf(turnAroundLeftInterval * 1000).longValue() + turnAroundDelay);
        } catch (InterruptedException e) {
          LOGGER.error(e.getMessage());
        }
        LOGGER.info(navigatingKey + " AGV First Step, Turn Around");
      }

      if (SensingObjectTransientData.soMap.containsKey(soAgvIdType)) {
        List<SensingObject> soAgvList = SensingObjectTransientData.soMap.get(soAgvIdType);
        soAgvNext = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        for (SensingObject s : soAgvList) {
          soAgvNext.setSoId(s.getSoId());
          soAgvNext.setSoType(s.getSoType());
          soAgvNext.setCreateTime(s.getCreateTime());
          soAgvNext.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
          soAgvNext.setLocatingRegionId(s.getLocatingRegionId());
        }
        positionX = positionX / soAgvList.size();
        positionZ = positionZ / soAgvList.size();
        velocityX = velocityX / soAgvList.size();
        velocityY = velocityY / soAgvList.size();
        velocityZ = velocityZ / soAgvList.size();
        soAgvNext.setPositionX(positionX);
        soAgvNext.setPositionY(0.0);
        soAgvNext.setPositionZ(positionZ);
        soAgvNext.setVelocityX(velocityX);
        soAgvNext.setVelocityY(velocityY);
        soAgvNext.setVelocityZ(velocityZ);

        NaviTrajectory nt = new NaviTrajectory();
        nt.setPositionX(soAgvNext.getPositionX());
        nt.setPositionY(soAgvNext.getPositionY());
        nt.setPositionZ(soAgvNext.getPositionZ());
        nt.setCreateTime(soAgvNext.getCreateTime());
        if (an.getHistoryTrajectorys().isEmpty()) {
          an.getHistoryTrajectorys().add(nt);
        } else {
          Integer historyTrajectorysSize = an.getHistoryTrajectorys().size();
          NaviTrajectory agvLastestPoint = an.getHistoryTrajectorys().get(historyTrajectorysSize - 1);
          if (agvLastestPoint.getPositionX() != soAgvNext.getPositionX()
              || agvLastestPoint.getPositionY() != soAgvNext.getPositionY()
              || agvLastestPoint.getPositionZ() != soAgvNext.getPositionZ()) {
            an.getHistoryTrajectorys().add(nt);
          }
        }
      } else {
        LOGGER.info(navigatingKey + " AGV Not Found #2");
      }

      LOGGER.info(navigatingKey + " AGV Position: (" + soAgv.getPositionX() + ", " + soAgv.getPositionY() + ", "
          + soAgv.getPositionZ() + "), Time: " + soAgv.getUpdateTime());
      positionAgvNext = new Point3d();
      if (soAgvNext != null) {
        positionAgvNext.x = soAgvNext.getPositionX();
        positionAgvNext.y = soAgvNext.getPositionY();
        positionAgvNext.z = soAgvNext.getPositionZ();
        LOGGER.info(navigatingKey + " AGV Position Next: (" + positionAgvNext.x + ", " + positionAgvNext.y + ", "
            + positionAgvNext.z + "), Time: " + soAgvNext.getUpdateTime());
      }

      if (SensingObjectTransientData.soMap.containsKey(regionSoTargetIdType)) {
        List<SensingObject> soTargetList = SensingObjectTransientData.soMap.get(regionSoTargetIdType);
        soTargetNext = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        for (SensingObject s : soTargetList) {
          soTargetNext.setSoId(s.getSoId());
          soTargetNext.setSoType(s.getSoType());
          soTargetNext.setCreateTime(s.getCreateTime());
          soTargetNext.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
          soTargetNext.setLocatingRegionId(s.getLocatingRegionId());
        }
        positionX = positionX / soTargetList.size();
        positionZ = positionZ / soTargetList.size();
        velocityX = velocityX / soTargetList.size();
        velocityY = velocityY / soTargetList.size();
        velocityZ = velocityZ / soTargetList.size();
        soTargetNext.setPositionX(positionX);
        soTargetNext.setPositionY(0.0);
        soTargetNext.setPositionZ(positionZ);
        soTargetNext.setVelocityX(velocityX);
        soTargetNext.setVelocityY(velocityY);
        soTargetNext.setVelocityZ(velocityZ);
        personNotFoundConsecutiveTimes = 0;
        // Navi Aid
        naviAid = false;
        if (AgvTransientData.agvNaviAidMap.containsKey(soAgvIdType)) {
          aid = AgvTransientData.agvNaviAidMap.get(soAgvIdType);
          naviAidAngle = aid.getAgvTargetAngle();
          naviAidDistance = aid.getAgvTargetDistance();
          if (aid.getSoTargetId().equals(soTargetNext.getSoId())
              && (soTargetNext.getUpdateTime().getTime() - aid.getUpdateTime().getTime()) < 150) {
            naviAid = true;
          }
        }
      } else {
        if (!naviType.equalsIgnoreCase("fixed")) {
          personNotFoundConsecutiveTimes++;
          LOGGER.info(navigatingKey + " Target Not Found, ConsecutiveTimes: " + personNotFoundConsecutiveTimes);
        }
        if (personNotFoundConsecutiveTimes > 2) {
          AgvTransientData.navigatingMap.put(navigatingKey, false);
          LOGGER.info(navigatingKey + " Navi Force Interrupt, Target Not Found");
          an.setAgvMotion("stop");
          an.setNaviStatus("interrupt");
          break;
        }
      }

      positionTargetNext = new Point3d();
      if (naviType.equalsIgnoreCase("fixed")) {
        positionTargetNext = positionTargetFixed;
        targetMove = false;
        LOGGER.info(navigatingKey + " Target Position Fixed: (" + positionTargetNext.x + ", " + positionTargetNext.y
            + ", " + positionTargetNext.z + "), Moving: " + targetMove);
      } else {
        if (soTargetNext != null) {
          positionTargetNext.x = soTargetNext.getPositionX();
          positionTargetNext.y = soTargetNext.getPositionY();
          positionTargetNext.z = soTargetNext.getPositionZ();
          if (!soTargetNext.getLocatingRegionId().equals(soAgvNext.getLocatingRegionId())) {
            // Navi Handover
            Point3d positionAnchor = new Point3d();
            Region agvRegion = RegionTransientData.regionMap.get(soAgvNext.getLocatingRegionId());
            List<Anchor> agvRegionAnchors = agvRegion.getAnchors();
            for (Anchor a : agvRegionAnchors) {
              if (a.getSiblingRegionId().equals(soTargetNext.getLocatingRegionId())) {
                positionAnchor.x = a.getPositionX();
                positionAnchor.y = a.getPositionY();
                positionAnchor.z = a.getPositionZ();
                break;
              }
            }
            Point3d positionAnchorNext = new Point3d();
            Region targetRegion = RegionTransientData.regionMap.get(soTargetNext.getLocatingRegionId());
            List<Anchor> targetRegionAnchors = targetRegion.getAnchors();
            for (Anchor a : targetRegionAnchors) {
              if (a.getSiblingRegionId().equals(soAgvNext.getLocatingRegionId())) {
                positionAnchorNext.x = a.getPositionX();
                positionAnchorNext.y = a.getPositionY();
                positionAnchorNext.z = a.getPositionZ();
                break;
              }
            }
            if (positionAgvNext.distance(positionAnchor) < 45) {
              positionTargetNext.x = positionAnchorNext.x;
              positionTargetNext.y = positionAnchorNext.y;
              positionTargetNext.z = positionAnchorNext.z;
            } else {
              positionTargetNext.x = positionAnchor.x;
              positionTargetNext.y = positionAnchor.y;
              positionTargetNext.z = positionAnchor.z;
            }
            LOGGER.info(navigatingKey + " Navi Handover positionAnchor: " + positionAnchor + ", positionAnchorNext: "
                + positionAnchorNext + ", positionTargetNext: " + positionTargetNext + ", AGV and Anchor Distance: "
                + positionAgvNext.distance(positionAnchor));
            naviHandover = true;
          } else {
            naviHandover = false;
          }

          Double targetMovingDistance = 0.0;
          if (positionTarget.x != 0 && positionTarget.z != 0) {
            targetMovingDistance = positionTargetNext.distance(positionTarget);
            if (targetMovingDistance > 30) {
              targetMove = true;
            } else {
              targetMove = false;
            }
          } else {
            targetMove = false;
          }

          LOGGER.info(navigatingKey + " Target Position Next: (" + positionTargetNext.x + ", " + positionTargetNext.y
              + ", " + positionTargetNext.z + "), Time: " + soTargetNext.getUpdateTime() + " Target Position : ("
              + positionTarget.x + ", " + positionTarget.y + ", " + positionTarget.z + "), Moving: " + targetMove
              + ", MovingDistance:" + targetMovingDistance);
          // LOGGER.info(navigatingKey + " NaviAid Target Id: " + aid.getSoTargetId() + ", AidAngle: " + naviAidAngle
          // + ", AidDistance: " + naviAidDistance + ", Time: " + aid.getUpdateTime() + ", Aid: " + naviAid);
          positionTarget = positionTargetNext;
        }
      }

      // Route Planning
      List<SensingObject> soBlockageList = new ArrayList<SensingObject>();
      for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
        String regionId = regionSoIdType.split("_")[0];
        if (!regionId.equals(soAgvNext.getLocatingRegionId()) || regionSoIdType.equals(regionSoTargetIdType)
            || regionSoIdType.contains("AGV")) {
          continue;
        }
        SensingObject so = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
        for (SensingObject s : sesingList) {
          so.setSoId(s.getSoId());
          so.setSoType(s.getSoType());
          so.setLocatingRegionId(s.getLocatingRegionId());
          so.setCreateTime(s.getCreateTime());
          so.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
        }
        positionX = positionX / sesingList.size();
        positionZ = positionZ / sesingList.size();
        velocityX = velocityX / sesingList.size();
        velocityY = velocityY / sesingList.size();
        velocityZ = velocityZ / sesingList.size();
        so.setPositionX(positionX);
        so.setPositionY(0.0);
        so.setPositionZ(positionZ);
        so.setVelocityX(velocityX);
        so.setVelocityY(velocityY);
        so.setVelocityZ(velocityZ);
        soBlockageList.add(so);
      }

      // Blockage Cluster
      // First Level
      List<BlockageCluster> candidateBcList = new ArrayList<BlockageCluster>();
      for (SensingObject soBlockageSelf : soBlockageList) {
        Point3d positionBlockageSelf = new Point3d();
        positionBlockageSelf.x = soBlockageSelf.getPositionX();
        positionBlockageSelf.y = soBlockageSelf.getPositionY();
        positionBlockageSelf.z = soBlockageSelf.getPositionZ();
        List<String> soBlockageIds = new ArrayList<String>();
        soBlockageIds.add(soBlockageSelf.getSoId());
        BlockagePoint bpSelf = new BlockagePoint();
        bpSelf.setPositionX(positionBlockageSelf.x);
        bpSelf.setPositionY(positionBlockageSelf.y);
        bpSelf.setPositionZ(positionBlockageSelf.z);
        List<BlockagePoint> polygonalBlockagePoints = new ArrayList<BlockagePoint>();
        polygonalBlockagePoints.add(bpSelf);
        for (SensingObject soBlockageOther : soBlockageList) {
          if (!soBlockageOther.getSoId().equals(soBlockageSelf.getSoId())) {
            Point3d positionBlockageOther = new Point3d();
            positionBlockageOther.x = soBlockageOther.getPositionX();
            positionBlockageOther.y = soBlockageOther.getPositionY();
            positionBlockageOther.z = soBlockageOther.getPositionZ();
            if (positionBlockageSelf.distance(positionBlockageOther) < 80) {
              soBlockageIds.add(soBlockageOther.getSoId());
              BlockagePoint bpOther = new BlockagePoint();
              bpOther.setPositionX(positionBlockageOther.x);
              bpOther.setPositionY(positionBlockageOther.y);
              bpOther.setPositionZ(positionBlockageOther.z);
              polygonalBlockagePoints.add(bpOther);
            }
          }
        }
        BlockageCluster bc = new BlockageCluster();
        bc.setSoBlockageIds(soBlockageIds);
        bc.setPolygonalBlockagePoints(polygonalBlockagePoints);
        candidateBcList.add(bc);
      }
      // Second Level
      for (BlockageCluster bc1 : candidateBcList) {
        String soBlockageInitId1 = bc1.getSoBlockageIds().get(0);
        for (BlockageCluster bc2 : candidateBcList) {
          String soBlockageInitId2 = bc2.getSoBlockageIds().get(0);
          if (!soBlockageInitId2.equals(soBlockageInitId1)) {
            if (bc2.getSoBlockageIds().contains(soBlockageInitId1)) {
              for (int i = 1; i < bc2.getSoBlockageIds().size(); i++) {
                if (!bc1.getSoBlockageIds().contains(bc2.getSoBlockageIds().get(i))) {
                  bc1.getSoBlockageIds().add(bc2.getSoBlockageIds().get(i));
                  bc1.getPolygonalBlockagePoints().add(bc2.getPolygonalBlockagePoints().get(i));
                }
              }
            }
          }
        }
      }
      // Third Level
      Map<String, BlockageCluster> bcMap = new HashMap<String, BlockageCluster>();
      for (BlockageCluster bc : candidateBcList) {
        if (bc.getSoBlockageIds().size() > 2) {
          List<Integer> soBlockageIdList = new ArrayList<Integer>();
          for (String soBlockageId : bc.getSoBlockageIds()) {
            soBlockageIdList.add(Integer.parseInt(soBlockageId));
          }
          bc.setBcId(StringUtils.join(soBlockageIdList, "_"));
          Collections.sort(soBlockageIdList);
          String bcKey = StringUtils.join(soBlockageIdList, "_");
          bcMap.put(bcKey, bc);
        }
      }
      List<String> removedBcKeyList = new ArrayList<String>();
      for (String bcKey : bcMap.keySet()) {
        for (String bcKey2 : bcMap.keySet()) {
          if (bcKey2.contains(bcKey) && bcKey2.length() > bcKey.length()) {
            removedBcKeyList.add(bcKey);
          }
        }
      }
      for (String removedBcKey : removedBcKeyList) {
        bcMap.remove(removedBcKey);
      }
      // Forth Level
      Line2D agvTargetLine = new Line2D.Double(soAgvNext.getPositionX(), soAgvNext.getPositionZ(),
          soTargetNext.getPositionX(), soTargetNext.getPositionZ());
      Iterator<Map.Entry<String, BlockageCluster>> iter = bcMap.entrySet().iterator();
      while (iter.hasNext()) {
        Map.Entry<String, BlockageCluster> entry = iter.next();
        BlockageCluster bc = entry.getValue();
        Polygon bcPolygon = new Polygon();
        for (BlockagePoint bp : bc.getPolygonalBlockagePoints()) {
          int bpX = (int) Math.floor(bp.getPositionX());
          int bpZ = (int) Math.floor(bp.getPositionZ());
          bcPolygon.addPoint(bpX, bpZ);
        }
        Boolean intersectNaviLine = SpaceUtil.lineIntersectPolygon(agvTargetLine, bcPolygon);
        bc.setIntersectNaviLine(intersectNaviLine);
        bc.setAffectNaviPath(intersectNaviLine);
        if (!intersectNaviLine) {
          iter.remove();
        }
      }
      // Fifth Level
      Vector3d agvTargetVector = new Vector3d();
      agvTargetVector.x = positionTargetNext.x - positionAgvNext.x;
      agvTargetVector.y = positionTargetNext.y - positionAgvNext.y;
      agvTargetVector.z = positionTargetNext.z - positionAgvNext.z;
      Double agvTargetAngle = Math.atan2(agvTargetVector.z, agvTargetVector.x);
      for (BlockageCluster bc : bcMap.values()) {
        Integer blockageRelativeLeftNumber = 0;
        Integer blockageRelativeRightNumber = 0;
        String soBlockageRepresentIdLeft = "0";
        String soBlockageRepresentIdRight = "0";
        Double blockageVerticalDistanceMaxLeft = 0.0;
        Double blockageVerticalDistanceMaxRight = 0.0;
        for (int i = 0; i < bc.getPolygonalBlockagePoints().size(); i++) {
          BlockagePoint bp = bc.getPolygonalBlockagePoints().get(i);
          Vector3d agvBlockageVector = new Vector3d();
          agvBlockageVector.x = bp.getPositionX() - positionAgvNext.x;
          agvBlockageVector.y = bp.getPositionY() - positionAgvNext.y;
          agvBlockageVector.z = bp.getPositionZ() - positionAgvNext.z;
          Double agvBlockageAngle = Math.atan2(agvBlockageVector.z, agvBlockageVector.x);
          Double blockageAgvTargetAngle = agvBlockageVector.angle(agvTargetVector);
          Double agvBlockageLength = agvBlockageVector.length();
          if (blockageAgvTargetAngle < Math.PI / 12 * 5) {
            if ((agvBlockageAngle - agvTargetAngle) > 0) {
              blockageRelativeLeftNumber++;
              if (agvBlockageLength * Math.sin(blockageAgvTargetAngle) > blockageVerticalDistanceMaxLeft) {
                blockageVerticalDistanceMaxLeft = agvBlockageLength * Math.sin(blockageAgvTargetAngle);
                soBlockageRepresentIdLeft = bc.getSoBlockageIds().get(i);
              }
            } else if ((agvBlockageAngle - agvTargetAngle) < -Math.PI / 12 * 19) {
              blockageRelativeLeftNumber++;
              if (agvBlockageLength * Math.sin(blockageAgvTargetAngle) > blockageVerticalDistanceMaxLeft) {
                blockageVerticalDistanceMaxLeft = agvBlockageLength * Math.sin(blockageAgvTargetAngle);
                soBlockageRepresentIdLeft = bc.getSoBlockageIds().get(i);
              }
            } else {
              blockageRelativeRightNumber++;
              if (agvBlockageLength * Math.sin(blockageAgvTargetAngle) > blockageVerticalDistanceMaxRight) {
                blockageVerticalDistanceMaxRight = agvBlockageLength * Math.sin(blockageAgvTargetAngle);
                soBlockageRepresentIdRight = bc.getSoBlockageIds().get(i);
              }
            }
          }
        }
        if (blockageRelativeLeftNumber > blockageRelativeRightNumber) {
          bc.setSoRepresentId(soBlockageRepresentIdRight);
        } else {
          bc.setSoRepresentId(soBlockageRepresentIdLeft);
        }
      }

      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      NaviRoute nr = new NaviRoute();
      nr.setCreateTime(nowTime);
      RoutePoint startPoint = new RoutePoint();
      startPoint.setPositionX(soAgvNext.getPositionX());
      startPoint.setPositionY(soAgvNext.getPositionY());
      startPoint.setPositionZ(soAgvNext.getPositionZ());
      RoutePoint endPoint = new RoutePoint();
      endPoint.setPositionX(soTargetNext.getPositionX());
      endPoint.setPositionY(soTargetNext.getPositionY());
      endPoint.setPositionZ(soTargetNext.getPositionZ());
      List<RoutePoint> routePoints = new ArrayList<RoutePoint>();
      if (soBlockageList.isEmpty()) {
        routePoints.add(startPoint);
        if (naviHandover) {
          RoutePoint anchorPoint = new RoutePoint();
          anchorPoint.setPositionX(positionTargetNext.x);
          anchorPoint.setPositionY(positionTargetNext.y);
          anchorPoint.setPositionZ(positionTargetNext.z);
          routePoints.add(anchorPoint);
        }
        routePoints.add(endPoint);
      } else {
        routePoints.add(startPoint);
        for (SensingObject soBlockage : soBlockageList) {
          Boolean blockageNotInCluster = true;
          Boolean blockageClusterRepresent = false;
          // Blockage Cluster
          for (BlockageCluster bc : bcMap.values()) {
            if (bc.getSoBlockageIds().contains(soBlockage.getSoId())
                && bc.getSoRepresentId().equals(soBlockage.getSoId())) {
              blockageNotInCluster = false;
              blockageClusterRepresent = true;
              break;
            } else if (bc.getSoBlockageIds().contains(soBlockage.getSoId())
                && !bc.getSoRepresentId().equals(soBlockage.getSoId())) {
              blockageNotInCluster = false;
              blockageClusterRepresent = false;
              break;
            }
          }
          if (!blockageNotInCluster && !blockageClusterRepresent) {
            continue;
          }

          Vector3d agvBlockageVector = new Vector3d();
          agvBlockageVector.x = soBlockage.getPositionX() - positionAgvNext.x;
          agvBlockageVector.y = soBlockage.getPositionY() - positionAgvNext.y;
          agvBlockageVector.z = soBlockage.getPositionZ() - positionAgvNext.z;
          // Vector3d agvTargetVector = new Vector3d();
          // agvTargetVector.x = positionTargetNext.x - positionAgvNext.x;
          // agvTargetVector.y = positionTargetNext.y - positionAgvNext.y;
          // agvTargetVector.z = positionTargetNext.z - positionAgvNext.z;
          // Double agvTargetAngle = Math.atan2(agvTargetVector.z, agvTargetVector.x);
          Double agvBlockageAngle = Math.atan2(agvBlockageVector.z, agvBlockageVector.x);
          // Double blockageAgvTargetAngle = Math.abs(agvBlockageAngle - agvTargetAngle);
          Double blockageAgvTargetAngle = agvBlockageVector.angle(agvTargetVector);
          Double agvBlockageLength = agvBlockageVector.length();
          Double blockageRouteLength = 70.0;

          Double blockageVerticalDistance = 999.9;
          Boolean blockageOnTheWay = false;
          Boolean blockageRelativeLeft = true;
          if (blockageAgvTargetAngle < Math.PI / 12 * 5) {
            blockageOnTheWay = true;
            blockageVerticalDistance = agvBlockageLength * Math.sin(blockageAgvTargetAngle);
            if ((agvBlockageAngle - agvTargetAngle) > 0) {
              blockageRelativeLeft = true;
            } else if ((agvBlockageAngle - agvTargetAngle) < -Math.PI / 12 * 19) {
              blockageRelativeLeft = true;
            } else {
              blockageRelativeLeft = false;
            }
          }

          LOGGER.info(navigatingKey + " soBlockage id: " + soBlockage.getSoId() + ", Position: ("
              + soBlockage.getPositionX() + "," + soBlockage.getPositionY() + "," + soBlockage.getPositionZ()
              + "), blockageVerticalDistance: " + blockageVerticalDistance + ", blockageRelativeLeft: "
              + blockageRelativeLeft + ", blockageOnTheWay: " + blockageOnTheWay);
          if (blockageNotInCluster && !blockageClusterRepresent && blockageVerticalDistance < 50 && blockageOnTheWay) {
            RoutePoint routePoint = new RoutePoint();
            Double verticalDistanceRatio = (blockageRouteLength - blockageVerticalDistance) / blockageVerticalDistance;
            Double routeAgvTargetAngle = blockageAgvTargetAngle * verticalDistanceRatio;
            if (routeAgvTargetAngle > Math.PI / 12 * 3.5) {
              // Magic Number
              routeAgvTargetAngle = Math.PI / 12 * 3.5;
            }
            Double projectiveLength = agvBlockageLength * Math.cos(blockageAgvTargetAngle);
            Double routeAgvLength = projectiveLength / Math.cos(routeAgvTargetAngle);
            Point2d a = new Point2d();
            Point2d b = new Point2d();
            Point2d c = new Point2d();
            Double ca = 0.0;
            Double ab = 0.0;
            Double bc = 0.0;
            Boolean takeSubtract = true;
            if (blockageRelativeLeft) {
              if (positionAgvNext.x < positionTargetNext.x) {
                a.x = positionAgvNext.x;
                a.y = positionAgvNext.z;
                b.x = soBlockage.getPositionX();
                b.y = soBlockage.getPositionZ();
                ca = routeAgvLength;
                ab = agvBlockageLength;
                bc = blockageRouteLength;
                takeSubtract = blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              } else {
                a.x = soBlockage.getPositionX();
                a.y = soBlockage.getPositionZ();
                b.x = positionAgvNext.x;
                b.y = positionAgvNext.z;
                ca = blockageRouteLength;
                ab = agvBlockageLength;
                bc = routeAgvLength;
                takeSubtract = !blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              }
            } else {
              if (positionAgvNext.x <= positionTargetNext.x) {
                a.x = positionAgvNext.x;
                a.y = positionAgvNext.z;
                b.x = soBlockage.getPositionX();
                b.y = soBlockage.getPositionZ();
                ca = routeAgvLength;
                ab = agvBlockageLength;
                bc = blockageRouteLength;
                takeSubtract = blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              } else {
                a.x = soBlockage.getPositionX();
                a.y = soBlockage.getPositionZ();
                b.x = positionAgvNext.x;
                b.y = positionAgvNext.z;
                ca = blockageRouteLength;
                ab = agvBlockageLength;
                bc = routeAgvLength;
                takeSubtract = !blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              }
            }
            routePoint.setPositionX(c.x);
            routePoint.setPositionY(0.0);
            routePoint.setPositionZ(c.y);
            routePoints.add(routePoint);
            LOGGER.info(navigatingKey + " Basic Blockage routePoint Position: (" + routePoint.getPositionX() + ","
                + routePoint.getPositionY() + "," + routePoint.getPositionZ() + ")");
          } else if (!blockageNotInCluster && blockageClusterRepresent) {
            // Blockage Cluster Represent
            RoutePoint routePoint = new RoutePoint();
            Double verticalDistanceRatio = (blockageRouteLength + blockageVerticalDistance) / blockageVerticalDistance;
            Double routeAgvTargetAngle = blockageAgvTargetAngle * verticalDistanceRatio;
            if (routeAgvTargetAngle > Math.PI / 12 * 3.5) {
              // Magic Number
              routeAgvTargetAngle = Math.PI / 12 * 3.5;
            }
            Double projectiveLength = agvBlockageLength * Math.cos(blockageAgvTargetAngle);
            Double routeAgvLength = projectiveLength / Math.cos(routeAgvTargetAngle);
            Point2d a = new Point2d();
            Point2d b = new Point2d();
            Point2d c = new Point2d();
            Double ca = 0.0;
            Double ab = 0.0;
            Double bc = 0.0;
            Boolean takeSubtract = true;
            if (blockageRelativeLeft) {
              if (positionAgvNext.x < positionTargetNext.x) {
                a.x = positionAgvNext.x;
                a.y = positionAgvNext.z;
                b.x = soBlockage.getPositionX();
                b.y = soBlockage.getPositionZ();
                ca = routeAgvLength;
                ab = agvBlockageLength;
                bc = blockageRouteLength;
                takeSubtract = !blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              } else {
                a.x = soBlockage.getPositionX();
                a.y = soBlockage.getPositionZ();
                b.x = positionAgvNext.x;
                b.y = positionAgvNext.z;
                ca = blockageRouteLength;
                ab = agvBlockageLength;
                bc = routeAgvLength;
                takeSubtract = blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              }
            } else {
              if (positionAgvNext.x <= positionTargetNext.x) {
                a.x = positionAgvNext.x;
                a.y = positionAgvNext.z;
                b.x = soBlockage.getPositionX();
                b.y = soBlockage.getPositionZ();
                ca = routeAgvLength;
                ab = agvBlockageLength;
                bc = blockageRouteLength;
                takeSubtract = !blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              } else {
                a.x = soBlockage.getPositionX();
                a.y = soBlockage.getPositionZ();
                b.x = positionAgvNext.x;
                b.y = positionAgvNext.z;
                ca = blockageRouteLength;
                ab = agvBlockageLength;
                bc = routeAgvLength;
                takeSubtract = blockageRelativeLeft;
                c = getRoutePoint(a, b, ca, ab, bc, takeSubtract);
              }
            }
            routePoint.setPositionX(c.x);
            routePoint.setPositionY(0.0);
            routePoint.setPositionZ(c.y);
            routePoints.add(routePoint);
            LOGGER.info(navigatingKey + " Blockage Cluster Represent routePoint Position: (" + routePoint.getPositionX()
                + "," + routePoint.getPositionY() + "," + routePoint.getPositionZ() + ")");
          }
        }
        if (naviHandover) {
          RoutePoint anchorPoint = new RoutePoint();
          anchorPoint.setPositionX(positionTargetNext.x);
          anchorPoint.setPositionY(positionTargetNext.y);
          anchorPoint.setPositionZ(positionTargetNext.z);
          routePoints.add(anchorPoint);
        }
        routePoints.add(endPoint);
      }
      nr.setRoutePoints(routePoints);
      List<NaviRoute> planningRoutes = an.getPlanningRoutes();
      planningRoutes.add(nr);
      if (planningRoutes.size() > 3) {
        planningRoutes.remove(0);
      }

      if (naviRoutePlanning) {
        Point3d positionTargetNew = null;
        for (RoutePoint rp : routePoints) {
          Point3d positionRp = new Point3d();
          positionRp.x = rp.getPositionX();
          positionRp.y = rp.getPositionY();
          positionRp.z = rp.getPositionZ();
          if (positionRp.distance(positionAgvNext) > 30 && positionRp.distance(positionTargetNext) > 50) {
            if (positionTargetNew == null) {
              positionTargetNew = positionRp;
            } else {
              if (positionRp.distance(positionAgvNext) < positionTargetNew.distance(positionAgvNext)) {
                positionTargetNew = positionRp;
              }
            }
          }
        }
        if (positionTargetNew != null) {
          positionTargetNext = positionTargetNew;
          naviRouting = true;
        } else {
          naviRouting = false;
        }
        LOGGER.info(navigatingKey + " positionTargetNew: " + positionTargetNew + ", naviRouting:" + naviRouting);
      } else {
        naviRouting = false;
      }

      positionAgv = new Point3d();
      positionAgv.x = soAgv.getPositionX();
      positionAgv.y = soAgv.getPositionY();
      positionAgv.z = soAgv.getPositionZ();
      LOGGER.info(navigatingKey + " AGV and Target Distance: " + positionAgvNext.distance(positionTargetNext));

      naviPause = positionAgvNext.distance(positionTargetNext) < pauseDistance;
      if (naviHandover) {
        naviPause = false;
      } else if (naviRouting) {
        naviPause = false;
      }

      if (naviAid) {
        if (naviPause && naviAidDistance < pauseAidDistance) {
          naviPause = true;
          LOGGER.info(navigatingKey + " AGV Navi Pause Verified by Aid, Distance: "
              + positionAgvNext.distance(positionTargetNext) + ", AidDistance: " + naviAidDistance);
        } else if (!naviPause && naviAidDistance < pauseAidDistance) {
          naviPause = true;
          LOGGER.info(navigatingKey + " AGV Navi Pause Fixed by Aid, Distance: "
              + positionAgvNext.distance(positionTargetNext) + ", AidDistance: " + naviAidDistance);
        } else if (naviPause && naviAidDistance > pauseAidDistance) {
          naviPause = false;
          LOGGER.info(navigatingKey + " AGV Navi Pause Rejected by Aid, Distance: "
              + positionAgvNext.distance(positionTargetNext) + ", AidDistance: " + naviAidDistance);
        }
      } else {
        if (naviPause) {
          LOGGER.info(navigatingKey + " AGV Navi Pause, Distance: " + positionAgvNext.distance(positionTargetNext));
        }
      }

      if (positionAgvNext.distance(positionTargetNext) < pauseDistance * 2.5) {
        forwardInterval = forwardInitInterval / 2;
      } else {
        forwardInterval = forwardInitInterval;
      }

      if (!naviPause) {
        Vector3d targetVector = new Vector3d();
        targetVector.x = positionTargetNext.x - positionAgv.x;
        targetVector.y = positionTargetNext.y - positionAgv.y;
        targetVector.z = positionTargetNext.z - positionAgv.z;
        Vector3d agvVector = new Vector3d();
        agvVector.x = positionAgvNext.x - positionAgv.x;
        agvVector.y = positionAgvNext.y - positionAgv.y;
        agvVector.z = positionAgvNext.z - positionAgv.z;
        Double targetAngle = Math.atan2(targetVector.z, targetVector.x);
        Double agvAngle = Math.atan2(agvVector.z, agvVector.x);
        Double turnInterval = Math.floor(Math.abs(targetAngle - agvAngle) / 0.5); // 30 degree
        try {
          if (naviInit && positionAgvNext.distance(positionAgv) != 0) {
            LOGGER.info(navigatingKey + " AGV Start Orientation, Angle: " + (targetAngle - agvAngle) + ", AidAngle: "
                + naviAidAngle + ", Aid: " + naviAid);
            agvLost = false;
            agvShift = false;
            shiftConsecutiveTimes = 0;
            positionAgvShift = null;
            naviInit = false;
            an.setAgvMotion("stop");
            an.setNaviStatus("start");
          } else if (positionAgvNext.distance(positionAgv) == 0 || Math.abs(targetAngle - agvAngle) > 2 * Math.PI) {
            LOGGER.info(navigatingKey + " AGV Lost, O/N Distance: " + positionAgvNext.distance(positionAgv)
                + ", Angle: " + (targetAngle - agvAngle));
            agvLost = true;
            agvShift = false;
            shiftConsecutiveTimes = 0;
            positionAgvShift = null;
            // turn around
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "right");
              agvMotionJsonObject.put("agvSpeed", turnAroundSpeed);
              agvMotionJsonObject.put("agvInterval", turnAroundRightInterval);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("right");
              an.setNaviStatus("lost");
              try {
                Thread.sleep(Double.valueOf(turnAroundRightInterval * 1000).longValue() + turnAroundDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
            }
          } else if (Math.abs(targetAngle - agvAngle) > shiftMinAngle
              && Math.abs(targetAngle - agvAngle) < shiftMaxAngle && !targetMove) {
            agvLost = false;
            agvShift = true;
            if (positionAgvShift != null && positionAgvNext != null
                && positionAgvShift.distance(positionAgvNext) < 10) {
              shiftConsecutiveTimes++;
            }
            if (positionAgvShift != null) {
              LOGGER.info(navigatingKey + " AGV Shift, Shift Distance: " + positionAgvShift.distance(positionAgvNext)
                  + ", Angle: " + (targetAngle - agvAngle) + ", ConsecutiveTimes: " + shiftConsecutiveTimes);
            } else {
              LOGGER.info(navigatingKey + " AGV Shift, Shift Distance: N/A" + ", Angle: " + (targetAngle - agvAngle)
                  + ", ConsecutiveTimes: " + shiftConsecutiveTimes);
            }
            positionAgvShift = positionAgvNext;

            // shake
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "backward");
              agvMotionJsonObject.put("agvSpeed", shakeSpeed);
              agvMotionJsonObject.put("agvInterval", shakeInterval);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("shake");
              an.setNaviStatus("shift");
              try {
                Thread.sleep(400);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              agvMotionJsonObject.put("agvControl", "forward");
              agvMotionJsonObject.put("agvSpeed", shakeSpeed);
              agvMotionJsonObject.put("agvInterval", shakeInterval);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              try {
                Thread.sleep(400);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
            }
          } else {
            agvLost = false;
            agvShift = false;
            shiftConsecutiveTimes = 0;
            positionAgvShift = null;
            LOGGER.info(navigatingKey + " AGV OK, Angle: " + (targetAngle - agvAngle) + ", AidAngle: " + naviAidAngle
                + ", Aid: " + naviAid);
            an.setAgvMotion("stop");
            an.setNaviStatus("running");
          }
        } catch (Exception e) {
          LOGGER.error(e.getMessage());
        }

        if (naviAid) {
          if (naviAidAngle > 0 && (targetAngle - agvAngle) > 0.5 && (targetAngle - agvAngle) < Math.PI && !agvLost
              && !agvShift) {
            // turn left
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable) {
              agvMotionJsonObject.put("agvControl", "left");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("left");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Left Verified by Aid: " + turnInterval * turnRatio + "s, Angle: "
                  + (targetAngle - agvAngle) + ", AidAngle: " + naviAidAngle);
            }
          } else if (naviAidAngle < 0 && (targetAngle - agvAngle) > 0.5 && (targetAngle - agvAngle) < Math.PI
              && !agvLost && !agvShift) {
            LOGGER.info(navigatingKey + " AGV Turn Left Rejected by Aid: " + turnInterval * turnRatio + "s, Angle: "
                + (targetAngle - agvAngle) + ", AidAngle: " + naviAidAngle);
          } else if (naviAidAngle < 0 && (targetAngle - agvAngle) < -0.5 && (targetAngle - agvAngle) > -Math.PI
              && !agvLost && !agvShift) {
            // turn right
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable) {
              agvMotionJsonObject.put("agvControl", "right");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("right");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Right Verified by Aid: " + turnInterval * turnRatio + "s, Angle: "
                  + (targetAngle - agvAngle) + ", AidAngle: " + naviAidAngle);
            }
          } else if (naviAidAngle > 0 && (targetAngle - agvAngle) < -0.5 && (targetAngle - agvAngle) > -Math.PI
              && !agvLost && !agvShift) {
            LOGGER.info(navigatingKey + " AGV Turn Right Rejected by Aid: " + turnInterval * turnRatio + "s, Angle: "
                + (targetAngle - agvAngle) + ", AidAngle: " + naviAidAngle);
          } else if (naviAidAngle > 0 && (targetAngle - agvAngle) < -Math.PI && (targetAngle - agvAngle) > -2 * Math.PI
              && !agvLost && !agvShift) {
            turnInterval = Math.floor((2 * Math.PI + (targetAngle - agvAngle)) / 0.5);
            // turn left
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable) {
              agvMotionJsonObject.put("agvControl", "left");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("left");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Left Fix Verified by Aid: " + turnInterval * turnRatio
                  + "s, Angle: " + (2 * Math.PI + (targetAngle - agvAngle)) + ", AidAngle: " + naviAidAngle);
            }
          } else if (naviAidAngle < 0 && (targetAngle - agvAngle) < -Math.PI && (targetAngle - agvAngle) > -2 * Math.PI
              && !agvLost && !agvShift) {
            LOGGER.info(navigatingKey + " AGV Turn Left Fix Rejected by Aid: " + turnInterval * turnRatio + "s, Angle: "
                + (2 * Math.PI + (targetAngle - agvAngle)) + ", AidAngle: " + naviAidAngle);
          } else if (naviAidAngle < 0 && (targetAngle - agvAngle) > Math.PI && (targetAngle - agvAngle) < 2 * Math.PI
              && !agvLost && !agvShift) {
            turnInterval = Math.floor((2 * Math.PI - (targetAngle - agvAngle)) / 0.5);
            // turn right
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable) {
              agvMotionJsonObject.put("agvControl", "right");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("right");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Right Fix Verified by Aid: " + turnInterval * turnRatio
                  + "s, Angle: " + (2 * Math.PI - (targetAngle - agvAngle)) + ", AidAngle: " + naviAidAngle);
            } else if (naviAidAngle > 0 && (targetAngle - agvAngle) > Math.PI && (targetAngle - agvAngle) < 2 * Math.PI
                && !agvLost && !agvShift) {
              LOGGER.info(navigatingKey + " AGV Turn Right Fix Rejected by Aid: " + turnInterval * turnRatio
                  + "s, Angle: " + (2 * Math.PI - (targetAngle - agvAngle)) + ", AidAngle: " + naviAidAngle);
            }
          }
        } else {
          if ((targetAngle - agvAngle) > 0.5 && (targetAngle - agvAngle) < Math.PI && !agvLost && !agvShift) {
            // turn left
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "left");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("left");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Left: " + turnInterval * turnRatio + "s, Angle: "
                  + (targetAngle - agvAngle));
            }
          } else if ((targetAngle - agvAngle) < -0.5 && (targetAngle - agvAngle) > -Math.PI && !agvLost && !agvShift) {
            // turn right
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "right");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("right");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Right: " + turnInterval * turnRatio + "s, Angle: "
                  + (targetAngle - agvAngle));
            }
          } else if ((targetAngle - agvAngle) < -Math.PI && (targetAngle - agvAngle) > -2 * Math.PI && !agvLost
              && !agvShift) {
            turnInterval = Math.floor((2 * Math.PI + (targetAngle - agvAngle)) / 0.5);
            // turn left
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "left");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("left");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Left Fix: " + turnInterval * turnRatio + "s, Angle: "
                  + (2 * Math.PI + (targetAngle - agvAngle)));
            }
          } else if ((targetAngle - agvAngle) > Math.PI && (targetAngle - agvAngle) < 2 * Math.PI && !agvLost
              && !agvShift) {
            turnInterval = Math.floor((2 * Math.PI - (targetAngle - agvAngle)) / 0.5);
            // turn right
            if (AgvTransientData.navigatingMap.get(navigatingKey) && mqttEnable && !cooperatingGesture) {
              agvMotionJsonObject.put("agvControl", "right");
              agvMotionJsonObject.put("agvSpeed", turnSpeed);
              agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
              MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
              an.setAgvMotion("right");
              an.setNaviStatus("running");
              try {
                Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
              } catch (InterruptedException e) {
                LOGGER.error(e.getMessage());
              }
              LOGGER.info(navigatingKey + " AGV Turn Right Fix: " + turnInterval * turnRatio + "s, Angle: "
                  + (2 * Math.PI - (targetAngle - agvAngle)));
            }
          }
        }
      } else {
        an.setAgvMotion("stop");
        an.setNaviStatus("pause");
        if (AgvTransientData.navigatingMap.get(navigatingKey)) {
          try {
            Thread.sleep(2000);
          } catch (InterruptedException e) {
            LOGGER.error(e.getMessage());
          }
        }
      }

      if (!agvShift || shiftConsecutiveTimes > 2) {
        if (!naviPause) {
          soAgv = soAgvNext;
        }
        // agv restart
        if (shiftConsecutiveTimes > 2) {
          naviInit = true;
          agvShift = false;
          shiftConsecutiveTimes = 0;
        }
      }

    }

    // look towards the origin or half turn around
    if (agvOrigin) {
      if (positionAgvNext.distance(positionAgv) != 0 && positionAgvNext.distance(positionAgvOrigin) != 0
          && positionAgvOrigin.distance(positionAgv) != 0) {
        Vector3d originVector = new Vector3d();
        originVector.x = positionAgvOrigin.x - positionAgv.x;
        originVector.y = positionAgvOrigin.y - positionAgv.y;
        originVector.z = positionAgvOrigin.z - positionAgv.z;
        Vector3d agvVector = new Vector3d();
        agvVector.x = positionAgvNext.x - positionAgv.x;
        agvVector.y = positionAgvNext.y - positionAgv.y;
        agvVector.z = positionAgvNext.z - positionAgv.z;
        Double originAngle = Math.atan2(originVector.z, originVector.x);
        Double agvAngle = Math.atan2(agvVector.z, agvVector.x);
        Double turnInterval = Math.floor(Math.abs(originAngle - agvAngle) / 0.5); // 30 degree
        if ((originAngle - agvAngle) > 0.5 && (originAngle - agvAngle) < Math.PI) {
          // turn left
          if (mqttEnable) {
            agvMotionJsonObject.put("agvControl", "left");
            agvMotionJsonObject.put("agvSpeed", turnSpeed);
            agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
            MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
            an.setAgvMotion("left");
            an.setNaviStatus("origin");
            try {
              Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
            } catch (InterruptedException e) {
              LOGGER.error(e.getMessage());
            }
            LOGGER.info(navigatingKey + " Origin, AGV Turn Left: " + turnInterval * turnRatio + "s, Angle: "
                + (originAngle - agvAngle) + ", positionAgvOrigin: (" + positionAgvOrigin.x + "," + positionAgvOrigin.y
                + "," + positionAgvOrigin.z + "), positionAgvNext: (" + positionAgvNext.x + "," + positionAgvNext.y
                + "," + positionAgvNext.z + "), positionAgv: (" + positionAgv.x + "," + positionAgv.y + ","
                + positionAgv.z + ")");
          }
        } else if ((originAngle - agvAngle) < -0.5 && (originAngle - agvAngle) > -Math.PI) {
          // turn right
          if (mqttEnable) {
            agvMotionJsonObject.put("agvControl", "right");
            agvMotionJsonObject.put("agvSpeed", turnSpeed);
            agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
            MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
            an.setAgvMotion("right");
            an.setNaviStatus("origin");
            try {
              Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
            } catch (InterruptedException e) {
              LOGGER.error(e.getMessage());
            }
            LOGGER.info(navigatingKey + " Origin, AGV Turn Right: " + turnInterval * turnRatio + "s, Angle: "
                + (originAngle - agvAngle) + ", positionAgvOrigin: (" + positionAgvOrigin.x + "," + positionAgvOrigin.y
                + "," + positionAgvOrigin.z + "), positionAgvNext: (" + positionAgvNext.x + "," + positionAgvNext.y
                + "," + positionAgvNext.z + "), positionAgv: (" + positionAgv.x + "," + positionAgv.y + ","
                + positionAgv.z + ")");
          }
        } else if ((originAngle - agvAngle) < -Math.PI && (originAngle - agvAngle) > -2 * Math.PI) {
          turnInterval = Math.floor((2 * Math.PI + (originAngle - agvAngle)) / 0.5);
          // turn left
          if (mqttEnable) {
            agvMotionJsonObject.put("agvControl", "left");
            agvMotionJsonObject.put("agvSpeed", turnSpeed);
            agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
            MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
            an.setAgvMotion("left");
            an.setNaviStatus("origin");
            try {
              Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
            } catch (InterruptedException e) {
              LOGGER.error(e.getMessage());
            }
            LOGGER.info(navigatingKey + " Origin, AGV Turn Left Fix: " + turnInterval * turnRatio + "s, Angle: "
                + (2 * Math.PI + (originAngle - agvAngle)) + ", positionAgvOrigin: (" + positionAgvOrigin.x + ","
                + positionAgvOrigin.y + "," + positionAgvOrigin.z + "), positionAgvNext: (" + positionAgvNext.x + ","
                + positionAgvNext.y + "," + positionAgvNext.z + "), positionAgv: (" + positionAgv.x + ","
                + positionAgv.y + "," + positionAgv.z + ")");
          }
        } else if ((originAngle - agvAngle) > Math.PI && (originAngle - agvAngle) < 2 * Math.PI) {
          turnInterval = Math.floor((2 * Math.PI - (originAngle - agvAngle)) / 0.5);
          // turn right
          if (mqttEnable) {
            agvMotionJsonObject.put("agvControl", "right");
            agvMotionJsonObject.put("agvSpeed", turnSpeed);
            agvMotionJsonObject.put("agvInterval", turnInterval * turnRatio);
            MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
            an.setAgvMotion("right");
            an.setNaviStatus("origin");
            try {
              Thread.sleep(Double.valueOf(turnInterval * turnRatio * 1000).longValue() + turnDelay);
            } catch (InterruptedException e) {
              LOGGER.error(e.getMessage());
            }
            LOGGER.info(navigatingKey + " Origin, AGV Turn Right Fix: " + turnInterval * turnRatio + "s, Angle: "
                + (2 * Math.PI - (originAngle - agvAngle)) + ", positionAgvOrigin: (" + positionAgvOrigin.x + ","
                + positionAgvOrigin.y + "," + positionAgvOrigin.z + "), positionAgvNext: (" + positionAgvNext.x + ","
                + positionAgvNext.y + "," + positionAgvNext.z + "), positionAgv: (" + positionAgv.x + ","
                + positionAgv.y + "," + positionAgv.z + ")");
          }
        }
      } else {
        if (mqttEnable) {
          agvMotionJsonObject.put("agvControl", "left");
          agvMotionJsonObject.put("agvSpeed", turnAroundSpeed);
          agvMotionJsonObject.put("agvInterval", turnAroundLeftInterval / 2);
          MqttAgent.getInstance().executeMqttPublish(mqttTopic, agvMotionJsonObject.toJSONString());
          an.setAgvMotion("left");
          an.setNaviStatus("origin");
          try {
            Thread.sleep(Double.valueOf(turnAroundLeftInterval * 1000 / 2).longValue() + turnAroundDelay / 2);
          } catch (InterruptedException e) {
            LOGGER.error(e.getMessage());
          }
          LOGGER.info(navigatingKey + " Origin, AGV Half Turn Around, positionAgvOrigin: (" + positionAgvOrigin.x + ","
              + positionAgvOrigin.y + "," + positionAgvOrigin.z + "), positionAgvNext: (" + positionAgvNext.x + ","
              + positionAgvNext.y + "," + positionAgvNext.z + "), positionAgv: (" + positionAgv.x + "," + positionAgv.y
              + "," + positionAgv.z + ")");
        }
      }
    }

    LOGGER.info(navigatingKey + " Navi Finish");
    an.setAgvMotion("stop");
    an.setNaviStatus("finish");
    AgvTransientData.agvNaviThreadMap.remove(soAgvIdType);
  }

  public void stop() {
    naviContinue = false;
  }

  private Point2d getRoutePoint(Point2d a, Point2d b, Double ca, Double ab, Double bc, Boolean takeSubtract) {
    Double dy = b.y - a.y;
    Double dx = b.x - a.x;
    Double tmpValue = (ca * ca + ab * ab - bc * bc) / (2 * ca * ab);
    Double angAb = Math.atan(dy / dx);
    Double angBc = Math.acos(tmpValue);
    Double angAc = 0.0;
    if (takeSubtract) {
      angAc = angAb - angBc;
    } else {
      angAc = angAb + angBc;
    }
    Point2d c = new Point2d();
    c.y = a.y + ca * Math.sin(angAc);
    c.x = a.x + ca * Math.cos(angAc);
    return c;
  }
}
