package jcas.jms.api.resource;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.resource.ComputingNode;
import jcas.jms.model.resource.ComputingNodeConfig;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.model.resource.SensorInfo;
import jcas.jms.model.resource.SupportedSensor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ComputingNodeResource is the class for computing node resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/cn")
@Api(tags = { "Computing Node API (Resource Management)" })
public class ComputingNodeResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(ComputingNodeResource.class);

  /**
   * Obtains computing node list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains computing node list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getComputingNodeList() {
    List<ComputingNode> cnList = new ArrayList<ComputingNode>(ComputingNodeTransientData.cnMap.values());

    LOGGER.info("Fetching RM ComputingNode List");

    GenericEntity<List<ComputingNode>> entity = new GenericEntity<List<ComputingNode>>(cnList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates computing node.
   *
   * @param cnId    The computing node id
   * @param putBody {@code ComputingNodePutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{cnId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates "
      + "computing node", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putComputingNode(
      @ApiParam(value = "The Computing Node ID", required = true) @PathParam("cnId") String cnId,
      @ApiParam(value = "The Put Body", required = true) ComputingNodePutBody putBody) {
    // Verify cnId
    if (!ComputingNodeTransientData.cnMap.containsKey(cnId)) {
      return Response.status(404).entity("Invalid cnId").build();
    }

    // Verify sensor
    List<SensorInfo> sensorInfos = putBody.getSensorInfos();
    ComputingNodeConfig cnConfig = ComputingNodeTransientData.cnConfigMap.get(cnId);
    List<SupportedSensor> supportedSensors = cnConfig.getSupportedSensors();
    List<String> supportedSensorNames = new ArrayList<String>();
    for (SupportedSensor ss : supportedSensors) {
      supportedSensorNames.add(ss.getSensorName());
    }
    for (SensorInfo si : sensorInfos) {
      if (!supportedSensorNames.contains(si.getSensorName())) {
        return Response.status(404).entity("Invalid sensorName").build();
      }
    }

    ComputingNode updateCn = ComputingNodeTransientData.cnMap.get(cnId);
    updateCn.setCpuUsagePercent(putBody.getCpuUsagePercent());
    updateCn.setGpuUsagePercent(putBody.getGpuUsagePercent());
    updateCn.setMemoryUsagePercent(putBody.getMemoryUsagePercent());
    if (putBody.getPowerLeftPercent() != null) {
      updateCn.setPowerLeftPercent(putBody.getPowerLeftPercent());
    }
    if (putBody.getSystemPowerW() != null) {
      updateCn.setSystemPowerW(putBody.getSystemPowerW());
    }
    // updateCn.setNicSentBps(putBody.getNicSentBps());
    // updateCn.setNicRecvBps(putBody.getNicRecvBps());
    updateCn.setCpuTempC(putBody.getCpuTempC());
    updateCn.setGpuTempC(putBody.getGpuTempC());
    updateCn.setMemoryTempC(putBody.getMemoryTempC());
    updateCn.setNicTempC(putBody.getNicTempC());
    updateCn.setCnStatus(putBody.getCnStatus());
    updateCn.setSensorInfos(sensorInfos);
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    updateCn.setUpdateTime(nowTime);

    LOGGER.info("Putting RM ComputingNode");
    return Response.status(200).entity("ComputingNode Updated").build();
  }
}
