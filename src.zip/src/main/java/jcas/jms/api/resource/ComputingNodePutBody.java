package jcas.jms.api.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import jcas.jms.model.resource.SensorInfo;

/**
 * ComputingNodePutBody is the class for ComputingNodePutBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("ComputingNodePutBody")
public class ComputingNodePutBody {
  private Double cpuUsagePercent;
  private Double gpuUsagePercent;
  private Double memoryUsagePercent;
  private Double powerLeftPercent;
  private Double systemPowerW;
  // private Map<String, Double> nicSentBps;
  // private Map<String, Double> nicRecvBps;
  private Double cpuTempC;
  private Double gpuTempC;
  private Double memoryTempC;
  private Double nicTempC;
  private String cnStatus;
  private List<SensorInfo> sensorInfos;

  @ApiModelProperty(value = "CPU Usage Percent of Computing Node", required = true)
  public Double getCpuUsagePercent() {
    return cpuUsagePercent;
  }

  public void setCpuUsagePercent(Double cpuUsagePercent) {
    this.cpuUsagePercent = cpuUsagePercent;
  }

  @ApiModelProperty(value = "GPU Usage Percent of Computing Node", required = true)
  public Double getGpuUsagePercent() {
    return gpuUsagePercent;
  }

  public void setGpuUsagePercent(Double gpuUsagePercent) {
    this.gpuUsagePercent = gpuUsagePercent;
  }

  @ApiModelProperty(value = "Memory Usage Percent of Computing Node", required = true)
  public Double getMemoryUsagePercent() {
    return memoryUsagePercent;
  }

  public void setMemoryUsagePercent(Double memoryUsagePercent) {
    this.memoryUsagePercent = memoryUsagePercent;
  }

  @ApiModelProperty(value = "Power Left Percent of Computing Node", required = false)
  public Double getPowerLeftPercent() {
    return powerLeftPercent;
  }

  public void setPowerLeftPercent(Double powerLeftPercent) {
    this.powerLeftPercent = powerLeftPercent;
  }

  @ApiModelProperty(value = "System Power Watt of Computing Node", required = false)
  public Double getSystemPowerW() {
    return systemPowerW;
  }

  public void setSystemPowerW(Double systemPowerW) {
    this.systemPowerW = systemPowerW;
  }

  // @ApiModelProperty(value = "NIC Interface Sent Tput of Computing Node", required = true)
  // public Map<String, Double> getNicSentBps() {
  // return nicSentBps;
  // }

  // public void setNicSentBps(Map<String, Double> nicSentBps) {
  // this.nicSentBps = nicSentBps;
  // }

  // @ApiModelProperty(value = "NIC Interface Recieve Tput of Computing Node", required = true)
  // public Map<String, Double> getNicRecvBps() {
  // return nicRecvBps;
  // }

  // public void setNicRecvBps(Map<String, Double> nicRecvBps) {
  // this.nicRecvBps = nicRecvBps;
  // }

  @ApiModelProperty(value = "CPU Temperature of Computing Node", required = true)
  public Double getCpuTempC() {
    return cpuTempC;
  }

  public void setCpuTempC(Double cpuTempC) {
    this.cpuTempC = cpuTempC;
  }

  @ApiModelProperty(value = "GPU Temperature of Computing Node", required = true)
  public Double getGpuTempC() {
    return gpuTempC;
  }

  public void setGpuTempC(Double gpuTempC) {
    this.gpuTempC = gpuTempC;
  }

  @ApiModelProperty(value = "Memory Temperature of Computing Node", required = true)
  public Double getMemoryTempC() {
    return memoryTempC;
  }

  public void setMemoryTempC(Double memoryTempC) {
    this.memoryTempC = memoryTempC;
  }

  @ApiModelProperty(value = "NIC Temperature of Computing Node", required = true)
  public Double getNicTempC() {
    return nicTempC;
  }

  public void setNicTempC(Double nicTempC) {
    this.nicTempC = nicTempC;
  }

  @ApiModelProperty(value = "Status of Computing Node", required = true, example = "running/stop/unknown")
  public String getCnStatus() {
    return cnStatus;
  }

  public void setCnStatus(String cnStatus) {
    this.cnStatus = cnStatus;
  }

  @ApiModelProperty(value = "Status of Sensors", required = false)
  public List<SensorInfo> getSensorInfos() {
    return sensorInfos;
  }

  public void setSensorInfos(List<SensorInfo> sensorInfos) {
    this.sensorInfos = sensorInfos;
  }

}
