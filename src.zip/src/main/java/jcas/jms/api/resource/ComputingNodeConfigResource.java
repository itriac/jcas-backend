package jcas.jms.api.resource;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.resource.ComputingNodeConfig;
import jcas.jms.model.resource.ComputingNodeConfigService;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.util.Md5Util;
import jcas.jms.util.TransientDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * ComputingNodeConfigResource is the class for computing node config resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/cn/config")
@Api(tags = { "Computing Node Config API (Resource Management)" })
public class ComputingNodeConfigResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(ComputingNodeConfigResource.class);

  /**
   * Adds computing node config.
   *
   * @param postBody {@code ComputingNodeConfigPostBody}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds "
      + "computing node config", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postComputingNodeConfig(
      @ApiParam(value = "The Post Body", required = true) ComputingNodeConfigPostBody postBody) {

    // Verify cnName
    List<ComputingNodeConfig> cnConfigList = new ArrayList<ComputingNodeConfig>(
        ComputingNodeTransientData.cnConfigMap.values());
    for (ComputingNodeConfig cnConfig : cnConfigList) {
      if (cnConfig.getCnName().equals(postBody.getCnName())) {
        return Response.status(400).entity("Invalid cnName").build();
      }
    }

    ComputingNodeConfig newCnConfig = new ComputingNodeConfig();
    String cnId = Md5Util.getMd5(postBody.getCnName());
    newCnConfig.setCnId(cnId);
    newCnConfig.setCnName(postBody.getCnName());
    newCnConfig.setCnIp(postBody.getCnIp());
    newCnConfig.setCnType(postBody.getCnType());
    newCnConfig.setCpuTotalCore(postBody.getCpuTotalCore());
    newCnConfig.setCpuMaxPercent(postBody.getCpuMaxPercent());
    newCnConfig.setGpuTotalByte(postBody.getGpuTotalByte());
    newCnConfig.setGpuMaxPercent(postBody.getGpuMaxPercent());
    newCnConfig.setMemoryTotalByte(postBody.getMemoryTotalByte());
    newCnConfig.setMemoryMaxPercent(postBody.getMemoryMaxPercent());
    newCnConfig.setCnPowerPlugged(postBody.getCnPowerPlugged());
    newCnConfig.setSupportedSensors(postBody.getSupportedSensors());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    ComputingNodeConfigService computingNodeConfigService = ac
        .getBean(jcas.jms.model.resource.ComputingNodeConfigService.class);
    computingNodeConfigService.addComputingNodeConfig(newCnConfig);
    // Refresh Memory
    TransientDataUtil.refreshCnConfigMap();
    TransientDataUtil.refreshCnMap();

    LOGGER.info("Posting RM New ComputingNodeConfig");

    return Response.status(201).entity(cnId).build();
  }

  /**
   * Obtains computing node config list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains computing node config list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getComputingNodeConfigList() {
    List<ComputingNodeConfig> cnConfigList = new ArrayList<ComputingNodeConfig>(
        ComputingNodeTransientData.cnConfigMap.values());

    LOGGER.info("Fetching RM ComputingNodeConfig List");

    GenericEntity<List<ComputingNodeConfig>> entity = new GenericEntity<List<ComputingNodeConfig>>(cnConfigList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates computing node config.
   *
   * @param cnId    The computing node id
   * @param putBody {@code ComputingNodeConfigPutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{cnId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates "
      + "computing node config", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putComputingNodeConfig(
      @ApiParam(value = "The Computing Node ID", required = true) @PathParam("cnId") String cnId,
      @ApiParam(value = "The Put Body", required = true) ComputingNodeConfigPutBody putBody) {
    // Verify cnId
    if (!ComputingNodeTransientData.cnConfigMap.containsKey(cnId)) {
      return Response.status(404).entity("Invalid cnId").build();
    }

    ComputingNodeConfig updateCnConfig = ComputingNodeTransientData.cnConfigMap.get(cnId);
    updateCnConfig.setCnIp(putBody.getCnIp());
    updateCnConfig.setCnType(putBody.getCnType());
    updateCnConfig.setCpuTotalCore(putBody.getCpuTotalCore());
    updateCnConfig.setCpuMaxPercent(putBody.getCpuMaxPercent());
    updateCnConfig.setGpuTotalByte(putBody.getGpuTotalByte());
    updateCnConfig.setGpuMaxPercent(putBody.getGpuMaxPercent());
    updateCnConfig.setMemoryTotalByte(putBody.getMemoryTotalByte());
    updateCnConfig.setMemoryMaxPercent(putBody.getMemoryMaxPercent());
    updateCnConfig.setCnPowerPlugged(putBody.getCnPowerPlugged());
    updateCnConfig.setSupportedSensors(putBody.getSupportedSensors());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    ComputingNodeConfigService computingNodeConfigService = ac
        .getBean(jcas.jms.model.resource.ComputingNodeConfigService.class);
    computingNodeConfigService.updateComputingNodeConfig(updateCnConfig);
    // Refresh Memory
    TransientDataUtil.refreshCnConfigMap();

    LOGGER.info("Putting RM ComputingNodeConfig");
    return Response.status(200).entity("ComputingNodeConfig Updated").build();
  }

  /**
   * Deletes computing node config.
   *
   * @param cnId The computing node id
   * @return {@code Response}
   */
  @DELETE
  @Path("/{cnId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes "
      + "computing node config", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteComputingNodeConfig(
      @ApiParam(value = "The Computing Node ID", required = true) @PathParam("cnId") String cnId) {
    // Verify cnId
    if (!ComputingNodeTransientData.cnConfigMap.containsKey(cnId)) {
      return Response.status(404).entity("Invalid cnId").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    ComputingNodeConfigService computingNodeConfigService = ac
        .getBean(jcas.jms.model.resource.ComputingNodeConfigService.class);
    computingNodeConfigService.deleteComputingNodeConfig(cnId);
    // Refresh Memory
    TransientDataUtil.refreshCnConfigMap();
    TransientDataUtil.refreshCnMap();

    LOGGER.info("Deleting RM ComputingNodeConfig");
    return Response.status(204).entity("ComputingNodeConfig Deleted").build();
  }
}
