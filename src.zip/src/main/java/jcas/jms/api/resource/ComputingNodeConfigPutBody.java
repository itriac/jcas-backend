package jcas.jms.api.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import jcas.jms.model.resource.SupportedSensor;

/**
 * ComputingNodeConfigPutBody is the class for ComputingNodeConfigPutBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("ComputingNodeConfigPutBody")
public class ComputingNodeConfigPutBody {
  private String cnIp;
  private String cnType;
  private Integer cpuTotalCore;
  private Double cpuMaxPercent;
  private Long gpuTotalByte;
  private Double gpuMaxPercent;
  private Long memoryTotalByte;
  private Double memoryMaxPercent;
  private Boolean cnPowerPlugged;
  private List<SupportedSensor> supportedSensors;

  @ApiModelProperty(value = "IP of Computing Node", required = true)
  public String getCnIp() {
    return cnIp;
  }

  public void setCnIp(String cnIp) {
    this.cnIp = cnIp;
  }

  @ApiModelProperty(value = "Type of Computing Node", required = true)
  public String getCnType() {
    return cnType;
  }

  public void setCnType(String cnType) {
    this.cnType = cnType;
  }

  @ApiModelProperty(value = "CPU Total Core of Computing Node", required = true)
  public Integer getCpuTotalCore() {
    return cpuTotalCore;
  }

  public void setCpuTotalCore(Integer cpuTotalCore) {
    this.cpuTotalCore = cpuTotalCore;
  }

  @ApiModelProperty(value = "CPU Offload Policy of Computing Node", required = true)
  public Double getCpuMaxPercent() {
    return cpuMaxPercent;
  }

  public void setCpuMaxPercent(Double cpuMaxPercent) {
    this.cpuMaxPercent = cpuMaxPercent;
  }

  @ApiModelProperty(value = "GPU Total Byte of Computing Node", required = true)
  public Long getGpuTotalByte() {
    return gpuTotalByte;
  }

  public void setGpuTotalByte(Long gpuTotalByte) {
    this.gpuTotalByte = gpuTotalByte;
  }

  @ApiModelProperty(value = "GPU Offload Policy of Computing Node", required = true)
  public Double getGpuMaxPercent() {
    return gpuMaxPercent;
  }

  public void setGpuMaxPercent(Double gpuMaxPercent) {
    this.gpuMaxPercent = gpuMaxPercent;
  }

  @ApiModelProperty(value = "Memory Total Byte of Computing Node", required = true)
  public Long getMemoryTotalByte() {
    return memoryTotalByte;
  }

  public void setMemoryTotalByte(Long memoryTotalByte) {
    this.memoryTotalByte = memoryTotalByte;
  }

  @ApiModelProperty(value = "Memory Offload Policy of Computing Node", required = true)
  public Double getMemoryMaxPercent() {
    return memoryMaxPercent;
  }

  public void setMemoryMaxPercent(Double memoryMaxPercent) {
    this.memoryMaxPercent = memoryMaxPercent;
  }

  @ApiModelProperty(value = "Power Plugged of Computing Node", required = true)
  public Boolean getCnPowerPlugged() {
    return cnPowerPlugged;
  }

  public void setCnPowerPlugged(Boolean cnPowerPlugged) {
    this.cnPowerPlugged = cnPowerPlugged;
  }

  @ApiModelProperty(value = "Supported Sensors of Computing Node", required = false)
  public List<SupportedSensor> getSupportedSensors() {
    return supportedSensors;
  }

  public void setSupportedSensors(List<SupportedSensor> supportedSensors) {
    this.supportedSensors = supportedSensors;
  }
}
