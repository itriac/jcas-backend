package jcas.jms.api.region;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import jcas.jms.model.region.Anchor;
import jcas.jms.model.region.FencePoint;

/**
 * RegionPutBody is the class for RegionPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("RegionPutBody")
public class RegionPutBody {
  private String location;
  private List<String> cnOwnIds;
  private List<Anchor> anchors;
  private List<FencePoint> polygonalFencePoints;

  @ApiModelProperty(value = "Location of Region", example = "ITRI-78-307")
  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  @ApiModelProperty(value = "CNs in Region")
  public List<String> getCnOwnIds() {
    return cnOwnIds;
  }

  public void setCnOwnIds(List<String> cnOwnIds) {
    this.cnOwnIds = cnOwnIds;
  }

  @ApiModelProperty(value = "Anchors in Region")
  public List<Anchor> getAnchors() {
    return anchors;
  }

  public void setAnchors(List<Anchor> anchors) {
    this.anchors = anchors;
  }

  @ApiModelProperty(value = "PolygonalFencePoints in Region")
  public List<FencePoint> getPolygonalFencePoints() {
    return polygonalFencePoints;
  }

  public void setPolygonalFencePoints(List<FencePoint> polygonalFencePoints) {
    this.polygonalFencePoints = polygonalFencePoints;
  }
}
