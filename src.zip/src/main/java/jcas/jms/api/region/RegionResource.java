package jcas.jms.api.region;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionService;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.util.AlphaNumberRestrictedSymbolValidator;
import jcas.jms.util.Md5Util;
import jcas.jms.util.TransientDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * RegionResource is the class for region resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/region")
@Api(tags = { "Region API (Region Management)" })
public class RegionResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(RegionResource.class);

  /**
   * Adds region.
   *
   * @param postBody {@code RegionPostBody}
   * @return {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds " + "region", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postRegion(@ApiParam(value = "The Post Body", required = true) RegionPostBody postBody) {
    // Verify regionName
    List<Region> regionList = new ArrayList<Region>(RegionTransientData.regionMap.values());
    for (Region r : regionList) {
      if (r.getRegionName().equals(postBody.getRegionName())) {
        return Response.status(400).entity("Invalid regionName").build();
      }
    }

    // Verify regionName, location format
    AlphaNumberRestrictedSymbolValidator anrsv = new AlphaNumberRestrictedSymbolValidator();
    if (!anrsv.validate(postBody.getRegionName())) {
      return Response.status(400).entity("Invalid regionName").build();
    }
    if (!anrsv.validate(postBody.getLocation())) {
      return Response.status(400).entity("Invalid location").build();
    }

    // Verify cnId
    List<String> cnOwnIds = postBody.getCnOwnIds();
    for (String cnOwnId : cnOwnIds) {
      if (!ComputingNodeTransientData.cnMap.containsKey(cnOwnId)) {
        return Response.status(404).entity("Invalid cnId").build();
      }
    }

    Region newRegion = new Region();
    String regionId = Md5Util.getMd5(postBody.getRegionName());
    newRegion.setRegionId(regionId);
    newRegion.setRegionName(postBody.getRegionName());
    newRegion.setLocation(postBody.getLocation());
    newRegion.setCnOwnIds(cnOwnIds);
    newRegion.setAnchors(postBody.getAnchors());
    newRegion.setPolygonalFencePoints(postBody.getPolygonalFencePoints());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    RegionService regionService = ac.getBean(jcas.jms.model.region.RegionService.class);
    regionService.addRegion(newRegion);
    // Clear Memory
    TransientDataUtil.refreshRegionMap();

    LOGGER.info("Posting Region Management New Region");

    return Response.status(201).entity(regionId).build();
  }

  /**
   * Obtains region list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains region list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getRegionList() {
    List<Region> regionList = new ArrayList<Region>(RegionTransientData.regionMap.values());

    LOGGER.info("Fetching Region Management Region List");

    GenericEntity<List<Region>> entity = new GenericEntity<List<Region>>(regionList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Updates region.
   *
   * @param regionId The region id
   * @param putBody  {@code RegionPutBody}
   * @return {@code Response}
   */
  @PUT
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Updates "
      + "region", httpMethod = "PUT")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Bad Request"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response putRegion(@ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId,
      @ApiParam(value = "The Put Body", required = true) RegionPutBody putBody) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    // Verify location format
    AlphaNumberRestrictedSymbolValidator anrsv = new AlphaNumberRestrictedSymbolValidator();
    if (!anrsv.validate(putBody.getLocation())) {
      return Response.status(400).entity("Invalid location").build();
    }

    // Verify cnId
    List<String> cnOwnIds = putBody.getCnOwnIds();
    for (String cnOwnId : cnOwnIds) {
      if (!ComputingNodeTransientData.cnMap.containsKey(cnOwnId)) {
        return Response.status(404).entity("Invalid cnId").build();
      }
    }

    Region updateRegion = RegionTransientData.regionMap.get(regionId);
    updateRegion.setLocation(putBody.getLocation());
    updateRegion.setCnOwnIds(cnOwnIds);
    updateRegion.setAnchors(putBody.getAnchors());
    updateRegion.setPolygonalFencePoints(putBody.getPolygonalFencePoints());

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    RegionService regionService = ac.getBean(jcas.jms.model.region.RegionService.class);
    regionService.updateRegion(updateRegion);
    // Clear Memory
    TransientDataUtil.refreshRegionMap();

    LOGGER.info("Putting Region Management Region");

    return Response.status(200).entity("Region Updated").build();
  }

  /**
   * Deletes region.
   *
   * @param regionId The region id
   * @return {@code Response}
   */
  @DELETE
  @Path("/{regionId}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes "
      + "region", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteRegion(
      @ApiParam(value = "The Region ID", required = true) @PathParam("regionId") String regionId) {
    // Verify regionId
    if (!RegionTransientData.regionMap.containsKey(regionId)) {
      return Response.status(404).entity("Invalid regionId").build();
    }

    @SuppressWarnings("resource")
    ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
    RegionService regionService = ac.getBean(jcas.jms.model.region.RegionService.class);
    regionService.deleteRegion(regionId);
    // Clear Memory
    TransientDataUtil.refreshRegionMap();

    LOGGER.info("Deleting Region Management Region");
    return Response.status(204).entity("Region Deleted").build();
  }
}
