package jcas.jms.api.sensing;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * SensingObjectPostBody is the class for SensingObjectPostBody bean.
 *
 * @author Industrial Technology Research Institute
 */
@ApiModel("SensingObjectPostBody")
public class SensingObjectPostBody {
  private String soId;
  private String soType;
  private Double positionX;
  private Double positionY;
  private Double positionZ;
  private Double velocityX;
  private Double velocityY;
  private Double velocityZ;
  private String locatingRegionId;

  @ApiModelProperty(value = "ID of Sensing Object", required = true)
  public String getSoId() {
    return soId;
  }

  public void setSoId(String soId) {
    this.soId = soId;
  }

  @ApiModelProperty(value = "Type of Sensing Object", required = true)
  public String getSoType() {
    return soType;
  }

  public void setSoType(String soType) {
    this.soType = soType;
  }

  @ApiModelProperty(value = "X Position of Sensing Object", required = true)
  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  @ApiModelProperty(value = "Y Position of Sensing Object", required = true)
  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  @ApiModelProperty(value = "Z Position of Sensing Object", required = true)
  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }

  @ApiModelProperty(value = "X Velocity of Sensing Object", required = true)
  public Double getVelocityX() {
    return velocityX;
  }

  public void setVelocityX(Double velocityX) {
    this.velocityX = velocityX;
  }

  @ApiModelProperty(value = "Y Velocity of Sensing Object", required = true)
  public Double getVelocityY() {
    return velocityY;
  }

  public void setVelocityY(Double velocityY) {
    this.velocityY = velocityY;
  }

  @ApiModelProperty(value = "Z Velocity of Sensing Object", required = true)
  public Double getVelocityZ() {
    return velocityZ;
  }

  public void setVelocityZ(Double velocityZ) {
    this.velocityZ = velocityZ;
  }

  @ApiModelProperty(value = "ID of Region that Sensing Object Locates in", required = true)
  public String getLocatingRegionId() {
    return locatingRegionId;
  }

  public void setLocatingRegionId(String locatingRegionId) {
    this.locatingRegionId = locatingRegionId;
  }

}
