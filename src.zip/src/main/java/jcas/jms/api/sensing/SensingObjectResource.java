package jcas.jms.api.sensing;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.vecmath.Point3d;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SensingObjectResource is the class for sensing object resource.
 *
 * @author Industrial Technology Research Institute
 */
@Path("/v1/sensing")
@Api(tags = { "Sensing Object API (Sensing Management)" })
public class SensingObjectResource {
  private static final Logger LOGGER = LoggerFactory.getLogger(SensingObjectResource.class);

  /**
   * Adds sensing objects.
   *
   * @param  postBody {@code List<SensingObjectPostBody>}
   * @return          {@code Response}
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Adds "
      + "sensing objects", httpMethod = "POST")
  @ApiResponses(value = { @ApiResponse(code = 201, message = "Created"),
      @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response postSensingObject(
      @ApiParam(value = "The Post Body", required = true) List<SensingObjectPostBody> postBody) {
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    for (SensingObjectPostBody pb : postBody) {
      // Verify regionId
      if (!RegionTransientData.regionMap.containsKey(pb.getLocatingRegionId())) {
        return Response.status(404).entity("Invalid locatingRegionId").build();
      }

      SensingObject so = new SensingObject();
      so.setSoId(pb.getSoId());
      so.setSoType(pb.getSoType());
      so.setPositionX(pb.getPositionX());
      so.setPositionY(pb.getPositionY());
      so.setPositionZ(pb.getPositionZ());
      so.setVelocityX(pb.getVelocityX());
      so.setVelocityY(pb.getVelocityY());
      so.setVelocityZ(pb.getVelocityZ());
      so.setLocatingRegionId(pb.getLocatingRegionId());
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      // TODO
      String soKey = pb.getLocatingRegionId() + "_" + pb.getSoId() + "_" + pb.getSoType();
      if (pb.getSoType().equals("AGV")) {
        soKey = pb.getSoId() + "_" + pb.getSoType();
      }
      List<SensingObject> soList = new ArrayList<SensingObject>();
      if (SensingObjectTransientData.soMap.containsKey(soKey)) {
        soList = SensingObjectTransientData.soMap.get(soKey);
        if (soList.size() > 6) {
          soList.remove(0);
        }
      }

      // Filter AGV noise
      if (pb.getSoType().contains("AGV")) {
        int soAgvListSize = soList.size();
        if (soAgvListSize != 0) {
          SensingObject soAgvPrevious = soList.get(soAgvListSize - 1);
          Point3d positionAgvPrevious = new Point3d();
          positionAgvPrevious.x = soAgvPrevious.getPositionX();
          positionAgvPrevious.y = 0;
          positionAgvPrevious.z = soAgvPrevious.getPositionZ();
          Point3d positionAgv = new Point3d();
          positionAgv.x = so.getPositionX();
          positionAgv.y = 0;
          positionAgv.z = so.getPositionZ();
          if (positionAgv.distance(positionAgvPrevious) < 200 && so.getPositionY() < 50) {
            soList.add(so);
            // LOGGER.info( "Posting SM New SensingObject 1, AGV soId: " + pb.getSoId() + ", Position: (" +
            // pb.getPositionX() + ", " + pb.getPositionY() + ", " + pb.getPositionZ() + "), LocatingRegionId:" +
            // pb.getLocatingRegionId());
          }
          // else { LOGGER.info("Filtering AGV Noise, AGV soId: " + pb.getSoId() + ", Position: (" + pb.getPositionX() +
          // ", " + pb.getPositionY() + ", " + pb.getPositionZ() + "), LocatingRegionId:" + pb.getLocatingRegionId() +
          // ", Previous: " + positionAgvPrevious); }
        } else {
          soList.add(so);
          // LOGGER.info( "Posting SM First SensingObject 2, AGV soId: " + pb.getSoId() + ", Position: (" +
          // pb.getPositionX() + ", " + pb.getPositionY() + ", " + pb.getPositionZ() + "), LocatingRegionId:" +
          // pb.getLocatingRegionId());
        }

      } else if (pb.getSoType().contains("person")) {
        soList.add(so);
        // LOGGER.info("Posting SM SensingObject, Person soId: " + pb.getSoId() + ", Position: (" + pb.getPositionX() +
        // ", " + pb.getPositionY() + ", " + pb.getPositionZ() + "), LocatingRegionId:" + pb.getLocatingRegionId());
      }

      SensingObjectTransientData.soMap.put(soKey, soList);
    }

    // LOGGER.info("Posting SM New SensingObject");
    return Response.status(201).entity("All SensingObjects Added").build();
  }

  /**
   * Obtains sensing object list.
   *
   * @return {@code Response}
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @ApiOperation(produces = "application/json", value = "Obtains sensing object list", httpMethod = "GET")
  @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 401, message = "Unauthorized"),
      @ApiResponse(code = 404, message = "Not Found"), @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response getSensingObjectList() {
    List<SensingObject> soList = new ArrayList<SensingObject>();
    for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
      SensingObject so = new SensingObject();
      Double positionX = 0.0;
      Double positionY = 0.0;
      Double positionZ = 0.0;
      Double velocityX = 0.0;
      Double velocityY = 0.0;
      Double velocityZ = 0.0;
      List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
      for (SensingObject s : sesingList) {
        so.setSoId(s.getSoId());
        so.setSoType(s.getSoType());
        so.setLocatingRegionId(s.getLocatingRegionId());
        so.setCreateTime(s.getCreateTime());
        so.setUpdateTime(s.getUpdateTime());
        positionX += s.getPositionX();
        positionY += s.getPositionY();
        positionZ += s.getPositionZ();
        velocityX += s.getVelocityX();
        velocityY += s.getVelocityY();
        velocityZ += s.getVelocityZ();
      }
      positionX = positionX / sesingList.size();
      positionY = positionY / sesingList.size();
      positionZ = positionZ / sesingList.size();
      velocityX = velocityX / sesingList.size();
      velocityY = velocityY / sesingList.size();
      velocityZ = velocityZ / sesingList.size();
      so.setPositionX(positionX);
      so.setPositionY(positionY);
      so.setPositionZ(positionZ);
      so.setVelocityX(velocityX);
      so.setVelocityY(velocityY);
      so.setVelocityZ(velocityZ);
      soList.add(so);
    }

    // LOGGER.info("Fetching SM SensingObject List");

    GenericEntity<List<SensingObject>> entity = new GenericEntity<List<SensingObject>>(soList) {
    };
    return Response.status(200).entity(entity).build();
  }

  /**
   * Deletes all sensing objects.
   *
   * @return {@code Response}
   */
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @ApiOperation(consumes = "application/json", produces = "text/plain", value = "Deletes "
      + "all sensing objects", httpMethod = "DELETE")
  @ApiResponses(value = { @ApiResponse(code = 204, message = "No Content"),
      @ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 404, message = "Not Found"),
      @ApiResponse(code = 500, message = "Internal Server Error") })
  public Response deleteSensingObject() {
    SensingObjectTransientData.soMap.clear();

    LOGGER.info("Deleting SM SensingObject");
    return Response.status(204).entity("All SensingObjects Deleted").build();
  }
}
