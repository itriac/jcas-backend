package jcas.jms.test;

import javax.vecmath.Point2d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * RouteTest is the class to test route.
 *
 * @author Industrial Technology Research Institute
 */
public class RouteTest {

  /**
   * RouteTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Point3d agvPosition = new Point3d();
    agvPosition.x = 1.0;
    agvPosition.y = 0;
    agvPosition.z = -8.0;

    Point3d targetPosition = new Point3d();
    targetPosition.x = 8.0;
    targetPosition.y = 0;
    targetPosition.z = -1.0;

    Point3d blockagePosition = new Point3d();
    blockagePosition.x = 5.0;
    blockagePosition.y = 0;
    blockagePosition.z = -2.0;

    Vector3d targetVector = new Vector3d();
    targetVector.x = targetPosition.x - agvPosition.x;
    targetVector.y = targetPosition.y - agvPosition.y;
    targetVector.z = targetPosition.z - agvPosition.z;
    Double targetAngleRad = Math.atan2(targetVector.z, targetVector.x);
    System.out.println("targetAngleRad: " + targetAngleRad);

    Vector3d blockageVector = new Vector3d();
    blockageVector.x = blockagePosition.x - agvPosition.x;
    blockageVector.y = blockagePosition.y - agvPosition.y;
    blockageVector.z = blockagePosition.z - agvPosition.z;
    Double blockageAngleRad = Math.atan2(blockageVector.z, blockageVector.x);
    System.out.println("blockageAngleRad: " + blockageAngleRad);
    Double blockageVectorLength = blockageVector.length();
    System.out.println("blockageVectorLength: " + blockageVectorLength);

    Double angleRad = blockageAngleRad - targetAngleRad;
    System.out.println("angleRad: " + angleRad);
    Double angleDegree = Math.toDegrees(angleRad);
    System.out.println("angleDegree: " + angleDegree);
    Double verticalDistance = blockageVectorLength * Math.sin(angleRad);
    System.out.println("verticalDistance: " + verticalDistance);
    Double arcLength = blockageVectorLength * Math.asin(angleRad);
    System.out.println("arcLength: " + arcLength);
    Double projectiveLength = blockageVectorLength * Math.cos(angleRad);
    System.out.println("projectiveLength: " + projectiveLength);

    Double verticalDistanceRatio = (3 - verticalDistance) / verticalDistance;
    System.out.println("verticalDistanceRatio: " + verticalDistanceRatio);
    Double predictedAngleRad = angleRad * verticalDistanceRatio;
    System.out.println("predictedAngleRad: " + predictedAngleRad);

    Double routeLength = projectiveLength / Math.cos(predictedAngleRad);
    System.out.println("routeLength: " + routeLength);

    Double rotationAngleRad = angleRad + predictedAngleRad;
    System.out.println("rotationAngleRad: " + rotationAngleRad);
    Double rotationAngleDegree = Math.toDegrees(rotationAngleRad);
    System.out.println("rotationAngleDegree: " + rotationAngleDegree);

    Point3d projectivePosition = new Point3d();
    Double slope = (targetPosition.z - agvPosition.z) / (targetPosition.x - agvPosition.x);
    projectivePosition.x = (slope * agvPosition.x + blockagePosition.x / slope + blockagePosition.z - agvPosition.z)
        / (1 / slope + slope);
    projectivePosition.y = 0;
    projectivePosition.z = -1 / slope * (projectivePosition.x - blockagePosition.x) + blockagePosition.z;
    System.out.println("projectivePosition: " + projectivePosition);

    Point2d a = new Point2d();
    a.x = 0;
    a.y = -4;
    Point2d b = new Point2d();
    b.x = 2;
    b.y = -6;
    double dy = b.y - a.y;
    double dx = b.x - a.x;
    double ca = 2.8;
    double ab = 2.8;
    double bc = 3.9;
    double tmpValue = (ca * ca + ab * ab - bc * bc) / (2 * ca * ab);
    System.out.println("tmpValue: " + tmpValue);
    double angAb = Math.atan(dy / dx);
    System.out.println("angAb: " + angAb);
    double angBc = Math.acos(tmpValue);
    System.out.println("angBc: " + angBc);
    double angAc = angAb - angBc;
    System.out.println("angAc: " + angAc);
    Point2d c = new Point2d();
    c.y = a.y + ca * Math.sin(angAc);
    c.x = a.x + ca * Math.cos(angAc);
    System.out.println(" - c: " + c.x + "," + c.y);
    angAc = angAb + angBc;
    System.out.println("angAc: " + angAc);
    c.y = a.y + ca * Math.sin(angAc);
    c.x = a.x + ca * Math.cos(angAc);
    System.out.println(" + c: " + c.x + "," + c.y);

  }

}
