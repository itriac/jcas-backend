package jcas.jms.test;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.simple.JSONObject;

/**
 * AgvMotionTest is the class to test agv motion.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvMotionTest {

  /**
   * AgvMotionTest main.
   *
   * @param args For extension use
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    String mqttTopic = "k300_agv_0/motion";
    String mqttServer = "192.168.100.108";
    String mqttPort = "1883";
    String mqttAccount = "k300";
    String mqttPassword = "k300test";
    String mqttBroker = "tcp://" + mqttServer + ":" + mqttPort;
    MqttConnectOptions connectOptions = new MqttConnectOptions();
    connectOptions.setCleanSession(true);
    connectOptions.setKeepAliveInterval(60000);
    if (mqttAccount != null && !mqttAccount.isEmpty() && mqttPassword != null && !mqttPassword.isEmpty()) {
      connectOptions.setUserName(mqttAccount);
      connectOptions.setPassword(mqttPassword.toCharArray());
    }
    connectOptions.setAutomaticReconnect(true);
    try {
      MqttClient mqttClient = new MqttClient(mqttBroker, MqttClient.generateClientId(), new MemoryPersistence());
      if (!mqttClient.isConnected()) {
        mqttClient.connect(connectOptions);
      }
      JSONObject agvMotionJsonObject = new JSONObject();
      // Forward
      agvMotionJsonObject.put("agvControl", "forward");
      agvMotionJsonObject.put("agvSpeed", 1);
      agvMotionJsonObject.put("agvInterval", 3);
      MqttMessage message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(3300);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // turn around
      agvMotionJsonObject.put("agvControl", "right");
      agvMotionJsonObject.put("agvSpeed", 0.8);
      agvMotionJsonObject.put("agvInterval", 1.9);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(2200);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // Forward
      agvMotionJsonObject.put("agvControl", "forward");
      agvMotionJsonObject.put("agvSpeed", 1);
      agvMotionJsonObject.put("agvInterval", 3);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(3300);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // turn around
      agvMotionJsonObject.put("agvControl", "right");
      agvMotionJsonObject.put("agvSpeed", 0.8);
      agvMotionJsonObject.put("agvInterval", 1.9);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(2200);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // Forward
      agvMotionJsonObject.put("agvControl", "forward");
      agvMotionJsonObject.put("agvSpeed", 1);
      agvMotionJsonObject.put("agvInterval", 3);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(3300);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // turn around
      agvMotionJsonObject.put("agvControl", "right");
      agvMotionJsonObject.put("agvSpeed", 0.8);
      agvMotionJsonObject.put("agvInterval", 1.9);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(2200);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // Forward
      agvMotionJsonObject.put("agvControl", "forward");
      agvMotionJsonObject.put("agvSpeed", 1);
      agvMotionJsonObject.put("agvInterval", 3);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(3300);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      // turn around
      agvMotionJsonObject.put("agvControl", "right");
      agvMotionJsonObject.put("agvSpeed", 0.8);
      agvMotionJsonObject.put("agvInterval", 1.9);
      message = new MqttMessage(agvMotionJsonObject.toJSONString().getBytes("UTF-8"));
      mqttClient.publish(mqttTopic, message);
      try {
        Thread.sleep(2200);
      } catch (InterruptedException e) {
        System.out.println(e.toString());
      }
      mqttClient.disconnect();
      mqttClient.close();
    } catch (Exception me) {
      System.out.println(me.toString());
    }

  }

}
