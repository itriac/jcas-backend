package jcas.jms.test;

import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * Vector3dAngleExample is the class to test Vector3dAngle.
 *
 * @author Industrial Technology Research Institute
 */
public class Vector3dAngleExample {

  /**
   * Vector3dAngleExample main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    // from origin
    Vector3d vector0 = new Vector3d();
    vector0.x = 1.0;
    vector0.y = 0;
    vector0.z = 0;
    Vector3d vector45 = new Vector3d();
    vector45.x = 1.0;
    vector45.y = 0;
    vector45.z = 1.0;
    Double angle45 = vector45.angle(vector0);
    System.out.println("angle45: " + angle45 + " rad");
    Vector3d vector90 = new Vector3d();
    vector90.x = 0;
    vector90.y = 0;
    vector90.z = 1.0;
    Double angle90 = vector90.angle(vector0);
    System.out.println("angle90: " + angle90 + " rad");
    Vector3d vector135 = new Vector3d();
    vector135.x = -1.0;
    vector135.y = 0;
    vector135.z = 1.0;
    Double angle135 = vector135.angle(vector0);
    System.out.println("angle135: " + angle135 + " rad");

    Point3d agvPosition1 = new Point3d();
    agvPosition1.x = 2.0;
    agvPosition1.y = 0;
    agvPosition1.z = -2.0;
    Point3d agvPosition2 = new Point3d();
    agvPosition2.x = 2.0;
    agvPosition2.y = 0;
    agvPosition2.z = -1.0;
    Point3d targetPosition = new Point3d();
    targetPosition.x = 1.0;
    targetPosition.y = 0;
    targetPosition.z = 0;
    Vector3d targetVector = new Vector3d();
    targetVector.x = targetPosition.x - agvPosition1.x;
    targetVector.y = targetPosition.y - agvPosition1.y;
    targetVector.z = targetPosition.z - agvPosition1.z;
    Double targetAngle = Math.atan2(targetVector.z, targetVector.x);
    System.out.println(
        "targetAngle: " + targetAngle + ", (" + targetVector.x + "," + targetVector.y + "," + targetVector.z + ")");
    Vector3d agvVector = new Vector3d();
    agvVector.x = agvPosition2.x - agvPosition1.x;
    agvVector.y = agvPosition2.y - agvPosition1.y;
    agvVector.z = agvPosition2.z - agvPosition1.z;
    Double agvAngle = Math.atan2(agvVector.z, agvVector.x);
    System.out.println("agvAngle: " + agvAngle + ", (" + agvVector.x + "," + agvVector.y + "," + agvVector.z + ")");
    System.out.println("rotationAngle: " + (targetAngle - agvAngle) + " rad, " + targetVector.angle(agvVector));
  }

}
