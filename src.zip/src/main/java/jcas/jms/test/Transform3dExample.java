package jcas.jms.test;

import javax.media.j3d.Transform3D;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * Transform3dExample is the class to test Transform3d.
 *
 * @author Industrial Technology Research Institute
 */
public class Transform3dExample {

  /**
   * Transform3dExample main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Transform3D rotation = new Transform3D();
    rotation.rotY(-45);
    Point3d position = new Point3d();
    position.x = 1.0;
    position.y = 0;
    position.z = -2.0;
    System.out.println("position: " + position.x + ", " + position.y + ", " + position.z);
    Point3d rotatedPosition = new Point3d();
    rotation.transform(position, rotatedPosition);
    System.out.println("rotatedPosition: " + rotatedPosition.x + ", " + rotatedPosition.y + ", " + rotatedPosition.z);
    Vector3d shiftVector = new Vector3d();
    shiftVector.x = 0.1;
    shiftVector.y = 0;
    shiftVector.z = -0.1;
    Transform3D translation = new Transform3D();
    translation.setTranslation(shiftVector);
    Point3d translatedPosition = new Point3d();
    translation.transform(position, translatedPosition);
    System.out.println(
        "translatedPosition: " + translatedPosition.x + ", " + translatedPosition.y + ", " + translatedPosition.z);
    Point3d rotatedTranslatedPosition = new Point3d();
    translation.transform(rotatedPosition, rotatedTranslatedPosition);
    System.out.println("rotatedTranslatedPosition: " + rotatedTranslatedPosition.x + ", " + rotatedTranslatedPosition.y
        + ", " + rotatedTranslatedPosition.z);
    Point3d translatedRotatedPosition = new Point3d();
    rotation.transform(translatedPosition, translatedRotatedPosition);
    System.out.println("translatedRotatedPosition: " + translatedRotatedPosition.x + ", " + translatedRotatedPosition.y
        + ", " + translatedRotatedPosition.z);
    Transform3D rotatedTranslation = new Transform3D();
    rotatedTranslation.rotY(-45);
    rotatedTranslation.setTranslation(shiftVector);
    Point3d newPosition = new Point3d();
    rotatedTranslation.transform(position, newPosition);
    System.out.println("newPosition: " + newPosition.x + ", " + newPosition.y + ", " + newPosition.z);
  }

}
