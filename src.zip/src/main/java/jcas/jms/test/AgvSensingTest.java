package jcas.jms.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;

/**
 * AgvSensingTest is the class to test agv sensing.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvSensingTest {

  /**
   * AgvSensingTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Double agv0PositionX = 90.0;
    Double agv0PositionZ = -220.0;
    Double agv1PositionX = 90.0;
    Double agv1PositionZ = -250.0;
    while (true) {
      SensingObjectTransientData.soMap.clear();
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      // AGV0
      agv0PositionX += 10;
      if (agv0PositionX > 300) {
        agv0PositionX = 90.0;
      }
      List<SensingObject> soAgv0List = new ArrayList<SensingObject>();
      for (int i = 0; i < 7; i++) {
        SensingObject so = new SensingObject();
        so.setSoId("0");
        so.setSoType("AGV");
        so.setPositionX(agv0PositionX);
        so.setPositionY(0.0);
        so.setPositionZ(agv0PositionZ);
        so.setVelocityX(0.0);
        so.setVelocityY(0.0);
        so.setVelocityZ(0.0);
        so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
        so.setCreateTime(nowTime);
        so.setUpdateTime(nowTime);
        soAgv0List.add(so);
      }
      String soAgv0Key = "0_AGV";
      SensingObjectTransientData.soMap.put(soAgv0Key, soAgv0List);
      // AGV1
      agv1PositionX += 10;
      if (agv1PositionX > 300) {
        agv1PositionX = 90.0;
      }
      List<SensingObject> soAgv1List = new ArrayList<SensingObject>();
      for (int i = 0; i < 7; i++) {
        SensingObject so = new SensingObject();
        so.setSoId("1");
        so.setSoType("AGV");
        so.setPositionX(agv1PositionX);
        so.setPositionY(0.0);
        so.setPositionZ(agv1PositionZ);
        so.setVelocityX(0.0);
        so.setVelocityY(0.0);
        so.setVelocityZ(0.0);
        so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
        so.setCreateTime(nowTime);
        so.setUpdateTime(nowTime);
        soAgv1List.add(so);
      }
      String soAgv1Key = "1_AGV";
      SensingObjectTransientData.soMap.put(soAgv1Key, soAgv1List);

    }

  }

}
