package jcas.jms.test;

import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * Vector3dAngleExample2 is the class to test Vector3dAngle.
 *
 * @author Industrial Technology Research Institute
 */
public class Vector3dAngleExample2 {

  /**
   * Vector3dAngleExample main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Point3d agvPosition = new Point3d();
    agvPosition.x = 40.0;
    agvPosition.y = 0;
    agvPosition.z = -550.0;
    Point3d targetPosition = new Point3d();
    targetPosition.x = 310.0;
    targetPosition.y = 0;
    targetPosition.z = -550.0;
    Point3d blockagePosition = new Point3d();
    blockagePosition.x = 200.0;
    blockagePosition.y = 0;
    blockagePosition.z = -580.0;
    Vector3d targetVector = new Vector3d();
    targetVector.x = targetPosition.x - agvPosition.x;
    targetVector.y = targetPosition.y - agvPosition.y;
    targetVector.z = targetPosition.z - agvPosition.z;
    Double targetAngle = Math.atan2(targetVector.z, targetVector.x);
    System.out.println(
        "targetAngle: " + targetAngle + ", (" + targetVector.x + "," + targetVector.y + "," + targetVector.z + ")");
    Vector3d blockageVector = new Vector3d();
    blockageVector.x = blockagePosition.x - agvPosition.x;
    blockageVector.y = blockagePosition.y - agvPosition.y;
    blockageVector.z = blockagePosition.z - agvPosition.z;
    Double blockageAngle = Math.atan2(blockageVector.z, blockageVector.x);
    System.out.println("blockageAngle: " + blockageAngle + ", (" + blockageVector.x + "," + blockageVector.y + ","
        + blockageVector.z + ")");
    System.out.println("Angle: " + (blockageAngle - targetAngle) + " rad, " + blockageVector.angle(targetVector));
  }

}
