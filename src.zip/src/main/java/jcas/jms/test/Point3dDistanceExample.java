package jcas.jms.test;

import javax.vecmath.Point3d;

/**
 * Point3dDistanceExample is the class to test Point3dDistance.
 *
 * @author Industrial Technology Research Institute
 */
public class Point3dDistanceExample {

  /**
   * Point3dDistanceExample main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Point3d origin = new Point3d();
    origin.x = 138;
    origin.y = 0;
    origin.z = -299;
    Point3d position = new Point3d();
    position.x = 178;
    position.y = 0;
    position.z = -311;
    System.out.println("distance: " + position.distance(origin));
  }

}
