package jcas.jms.test;

import java.awt.Polygon;
import java.awt.geom.Line2D;

/**
 * PolygonTest is the class to test polygon.
 *
 * @author Industrial Technology Research Institute
 */
public class PolygonTest {

  /**
   * PolygonTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Polygon regionFence = new Polygon();
    regionFence.addPoint(0, 0);
    regionFence.addPoint(5, -1);
    regionFence.addPoint(4, -3);
    regionFence.addPoint(1, -2);
    System.out.println("(2,-2) inside: " + regionFence.contains(2, -2));
    System.out.println("(5,0) inside: " + regionFence.contains(5, 0));
    System.out.println("(3,-2) inside: " + regionFence.contains(3, -2));

    Polygon blockagePolygon = new Polygon();
    blockagePolygon.addPoint(0, 0);
    blockagePolygon.addPoint(5, -1);
    blockagePolygon.addPoint(4, -3);
    blockagePolygon.addPoint(1, -2);
    Line2D line = new Line2D.Double(7.0, -7.0, 8.0, -8.0);
    System.out.println("intersect: " + intersects(line, blockagePolygon));

  }

  private static boolean intersects(Line2D line, Polygon poly) {
    for (int i = 0; i < poly.npoints; i++) {
      int nextI = (i + 1) % poly.npoints;
      Line2D edge = new Line2D.Double(poly.xpoints[i], poly.ypoints[i], poly.xpoints[nextI], poly.ypoints[nextI]);
      if (line.intersectsLine(edge)) {
        return true;
      }
    }
    return false;
  }

}
