package jcas.jms.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.vecmath.Point3d;
import jcas.jms.api.agv.AgvNaviThread;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.agv.NaviRoute;
import jcas.jms.model.agv.NaviTrajectory;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;

/**
 * AgvNaviRoutePlanningTest is the class to test agv navi route planning.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvNaviRoutePlanningTest {

  /**
   * AgvNaviRoutePlanningTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    SensingObjectTransientData.soMap.clear();
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    // AGV
    String soAgvKey = "1_AGV";
    List<SensingObject> soAgvList = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("AGV");
      so.setPositionX(90.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("region1");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgvList.add(so);
    }
    SensingObjectTransientData.soMap.put(soAgvKey, soAgvList);
    // Target
    String soTargetKey = "region1_1_person";
    List<SensingObject> soTargetList = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("person");
      so.setPositionX(90.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("region1");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soTargetList.add(so);
    }
    SensingObjectTransientData.soMap.put(soTargetKey, soTargetList);
    // Blockage 1

    AgvNavi agvNavi = new AgvNavi();
    agvNavi.setSoAgvId("1");
    agvNavi.setSoAgvType("AGV");
    agvNavi.setSoTargetId("1");
    agvNavi.setSoTargetType("person");
    agvNavi.setTargetRegionId("region1");
    agvNavi.setNaviType("following");
    agvNavi.setAgvMotion("");
    agvNavi.setNaviStatus("init");
    agvNavi.setHistoryTrajectorys(new ArrayList<NaviTrajectory>());
    agvNavi.setPlanningRoutes(new ArrayList<NaviRoute>());
    String soAgvIdType = "1_AGV";
    AgvTransientData.agvNaviMap.put(soAgvIdType, agvNavi);
    Point3d positionTarget = new Point3d();
    String regionSoTargetIdType = "region1_1_person";
    AgvNaviThread agvNaviThread = new AgvNaviThread(regionSoTargetIdType, positionTarget, soAgvIdType, "following");
    AgvTransientData.agvNaviThreadMap.put(soAgvIdType, agvNaviThread);
    String navigatingKey = regionSoTargetIdType + "_1_AGV";
    AgvTransientData.navigatingMap.put(navigatingKey, true);
    AgvTransientData.executorService.submit(agvNaviThread);

    try {
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      System.out.println(e.toString());
    }

  }

}
