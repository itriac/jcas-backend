package jcas.jms.test;

/**
 * RuntimeTest is the class to test runtime.
 *
 * @author Industrial Technology Research Institute
 */
public class RuntimeTest {

  /**
   * RuntimeTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    System.out.println(Runtime.getRuntime().availableProcessors());

  }

}
