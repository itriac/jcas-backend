package jcas.jms.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.vecmath.Point3d;
import jcas.jms.api.agv.AgvNaviThread;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;

/**
 * AgvNaviStepByStepTest is the class to test agv navi.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvNaviStepByStepTest {
  /**
   * AgvNaviStepByStepTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Point3d positionTarget = new Point3d();
    positionTarget.x = 250;
    positionTarget.y = 0;
    positionTarget.z = -220;

    SensingObjectTransientData.soMap.clear();
    AgvTransientData.navigatingMap.put("0_AGV", true);

    AgvNaviThread agvNaviThread = new AgvNaviThread("", positionTarget, "0_AGV", "fixed");
    ExecutorService agv1ExecutorService = Executors.newFixedThreadPool(1);
    agv1ExecutorService.submit(agvNaviThread);

    String soIdType = "0_AGV";
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    List<SensingObject> soList = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(90.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(130.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(150.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(170.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(190.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(210.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(230.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    date = new Date();
    nowTime = new Timestamp(date.getTime());
    SensingObjectTransientData.soMap.clear();
    soList.clear();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(250.0);
      so.setPositionY(0.0);
      so.setPositionZ(-220.0);
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soList.add(so);
    }
    SensingObjectTransientData.soMap.put(soIdType, soList);

    AgvTransientData.navigatingMap.put("0_AGV", false);
  }
}
