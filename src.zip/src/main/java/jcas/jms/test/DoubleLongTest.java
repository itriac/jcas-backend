package jcas.jms.test;

/**
 * DoubleLongTest is the class to test Double to Long.
 *
 * @author Industrial Technology Research Institute
 */
public class DoubleLongTest {

  /**
   * DoubleLongTest main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    Double a = 4.1;
    System.out.println(a.longValue());
    System.out.println(a * 1000);
    System.out.println(Double.valueOf(a * 1000));
    System.out.println(Double.valueOf(a * 1000).longValue());

  }

}
