package jcas.jms.test;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.QueryApi;
import com.influxdb.query.FluxRecord;
import com.influxdb.query.FluxTable;
import java.util.List;

/**
 * InfluxDb2Example is the class to test influxdb client.
 *
 * @author Industrial Technology Research Institute
 */
public class InfluxDb2Example {
  private static char[] token = "my-super-secret-auth-token".toCharArray();
  private static String org = "ITRI";
  private static String bucket = "mmwave";

  /**
   * InfluxDB2Example main.
   *
   * @param args For extension use
   */
  public static void main(String[] args) {
    InfluxDBClient influxDbClient = InfluxDBClientFactory.create("http://192.168.100.105:8086", token, org, bucket);

    // Query data
    String flux = "from(bucket: \"mmwave\")\n" + "  |> range(start: 2023-03-30, stop: 2023-03-31)\n"
        + "  |> filter(fn: (r) => r[\"_measurement\"] == \"Point_Cloud\")\n"
        + "  |> filter(fn: (r) => r[\"_field\"] == \"doppler\")\n";

    QueryApi queryApi = influxDbClient.getQueryApi();

    List<FluxTable> tables = queryApi.query(flux);
    for (FluxTable fluxTable : tables) {
      List<FluxRecord> records = fluxTable.getRecords();
      for (FluxRecord fluxRecord : records) {
        System.out.println(fluxRecord.getTime() + " doppler:" + fluxRecord.getValueByKey("_value"));
      }
    }
    influxDbClient.close();

  }

}
