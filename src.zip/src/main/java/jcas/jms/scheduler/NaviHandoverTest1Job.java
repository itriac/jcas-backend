package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.api.agv.AgvNaviResource;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NaviHandoverTestJob is the class for navi handover test job.
 *
 * @author Industrial Technology Research Institute
 */
public class NaviHandoverTest1Job implements Job {
  private static final Logger LOGGER = LoggerFactory.getLogger(NaviHandoverTest1Job.class);

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());

    // AGV1
    Double agv1PositionX = 290.0;
    Double agv1PositionZ = -230.0;
    String soAgv1Key = "1_AGV";
    if (SensingObjectTransientData.soMap.containsKey(soAgv1Key)) {
      agv1PositionZ = SensingObjectTransientData.soMap.get(soAgv1Key).get(0).getPositionZ();
    }
    agv1PositionZ -= 5;
    if (agv1PositionZ < -530) {
      AgvNaviResource anr = new AgvNaviResource();
      anr.deleteAgvNavi("1", "person", "14e3634bcb9369f4f2dec462dbecd63c", "1", "AGV");
      agv1PositionZ = -230.0;
    }
    List<SensingObject> soAgv1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("AGV");
      so.setPositionX(agv1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(agv1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      if (agv1PositionZ > -400) {
        so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      } else {
        so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      }
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgv1List.add(so);
    }
    LOGGER.info("agv1PositionZ: " + agv1PositionZ + ", locatingRegionId: " + soAgv1List.get(0).getLocatingRegionId());
    SensingObjectTransientData.soMap.put(soAgv1Key, soAgv1List);

    Double person1PositionX = 290.0;
    Double person1PositionZ = -570.0;
    // person1
    List<SensingObject> soPerson1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("person");
      so.setPositionX(person1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson1List.add(so);
    }
    String soPerson1Key = "14e3634bcb9369f4f2dec462dbecd63c_1_person";
    SensingObjectTransientData.soMap.put(soPerson1Key, soPerson1List);
  }

}
