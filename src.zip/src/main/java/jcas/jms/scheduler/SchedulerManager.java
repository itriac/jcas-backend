package jcas.jms.scheduler;

import java.util.Calendar;
import java.util.Date;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SchedulerManager is the class to manager scheduler.
 *
 * @author Industrial Technology Research Institute
 */
public class SchedulerManager {
  private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerManager.class);

  /**
   * Initializes scheduler.
   */
  public void initScheduleJobs() {
    computingNodeTaskSyncJob();
    sensingObjectHeartbeatJob();
    // agvApproachingCheckJob(); personCrowdedCheckJob(); agvRegionFenceCheckJob(); sensingTestJob();
    // naviHandoverTestJob(); naviRoutePlanningTestJob();
    robotNaviJob();
  }

  private void computingNodeTaskSyncJob() {
    JobDetail jobDetail = JobBuilder.newJob(ComputingNodeTaskSyncJob.class).withIdentity("ComputingNodeTaskSyncJob")
        .build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("ComputingNodeTaskSyncTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(3).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("ComputingNodeTaskSyncJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  private void sensingObjectHeartbeatJob() {
    JobDetail jobDetail = JobBuilder.newJob(SensingObjectHeartbeatJob.class).withIdentity("SensingObjectHeartbeatJob")
        .build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("SensingObjectHeartbeatTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("SensingObjectHeartbeatJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void agvApproachingCheckJob() {
    JobDetail jobDetail = JobBuilder.newJob(AgvApproachingCheckJob.class).withIdentity("AgvApproachingCheckJob")
        .build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("AgvApproachingCheckTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMilliseconds(300).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("AgvApproachingCheckJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void personCrowdedCheckJob() {
    JobDetail jobDetail = JobBuilder.newJob(PersonCrowdedCheckJob.class).withIdentity("PersonCrowdedCheckJob").build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("PersonCrowdedCheckTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("PersonCrowdedCheckJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void agvRegionFenceCheckJob() {
    JobDetail jobDetail = JobBuilder.newJob(AgvRegionFenceCheckJob.class).withIdentity("AgvRegionFenceCheckJob")
        .build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("AgvRegionFenceCheckTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMilliseconds(300).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("AgvRegionFenceCheckJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void sensingTestJob() {
    JobDetail jobDetail = JobBuilder.newJob(SensingTestJob.class).withIdentity("SensingTestJob").build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("SensingTestTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(3).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("SensingTestJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void naviHandoverTestJob() {
    JobDetail jobDetail = JobBuilder.newJob(NaviHandoverTest2Job.class).withIdentity("NaviHandoverTestJob").build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("NaviHandoverTestTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMilliseconds(400).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("NaviHandoverTestJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  @SuppressWarnings("unused")
  private void naviRoutePlanningTestJob() {
    JobDetail jobDetail = JobBuilder.newJob(NaviRoutePlanningTest6Job.class).withIdentity("NaviRoutePlanningTestJob")
        .build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("NaviRoutePlanningTestTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(3).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("NaviRoutePlanningTestJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }

  private void robotNaviJob() {
    JobDetail jobDetail = JobBuilder.newJob(RobotNaviJob.class).withIdentity("RobotNaviJob").build();
    Calendar nowTime = Calendar.getInstance();
    Date startTime = nowTime.getTime();
    Trigger trigger = TriggerBuilder.newTrigger().withIdentity("RobotNaviTrigger").startAt(startTime)
        .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2).repeatForever()).build();
    SchedulerFactory sfact = new StdSchedulerFactory();
    Scheduler scheduler;
    try {
      scheduler = sfact.getScheduler();
      scheduler.scheduleJob(jobDetail, trigger);
      scheduler.start();
      LOGGER.info("RobotNaviJob Start");
    } catch (SchedulerException e) {
      LOGGER.error(e.getMessage());
    }
  }
}
