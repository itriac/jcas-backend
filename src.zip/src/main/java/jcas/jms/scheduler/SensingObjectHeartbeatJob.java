package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SensingObjectHeartbeatJob is the class for refresh sensing object job.
 *
 * @author Industrial Technology Research Institute
 */
public class SensingObjectHeartbeatJob implements Job {
  private static final Logger LOGGER = LoggerFactory.getLogger(SensingObjectHeartbeatJob.class);

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.SECOND, -2);
    Timestamp thresholdTime = new Timestamp(calendar.getTime().getTime());
    for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
      List<SensingObject> soList = SensingObjectTransientData.soMap.get(regionSoIdType);
      Iterator<SensingObject> iter = soList.iterator();
      while (iter.hasNext()) {
        SensingObject s = iter.next();
        if (s.getUpdateTime().before(thresholdTime)) {
          iter.remove();
        }
      }
      if (soList.isEmpty()) {
        // LOGGER.info("SO " + regionSoIdType + " Removed");
        SensingObjectTransientData.soMap.remove(regionSoIdType);
      }
    }
  }

}
