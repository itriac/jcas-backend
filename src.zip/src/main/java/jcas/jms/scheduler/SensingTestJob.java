package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * SensingTestJob is the class for sensing test job.
 *
 * @author Industrial Technology Research Institute
 */
public class SensingTestJob implements Job {

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    Double agv0PositionX = 90.0;
    Double agv0PositionZ = -200.0;
    Double agv1PositionX = 90.0;
    Double agv1PositionZ = -300.0;
    Double person0PositionX = 200.0;
    Double person0PositionZ = -170.0;
    Double person1PositionX = 200.0;
    Double person1PositionZ = -500.0;

    String soAgv0Key = "0_AGV";
    if (SensingObjectTransientData.soMap.containsKey(soAgv0Key)) {
      agv0PositionX = SensingObjectTransientData.soMap.get(soAgv0Key).get(0).getPositionX();
    }
    String soAgv1Key = "1_AGV";
    if (SensingObjectTransientData.soMap.containsKey(soAgv1Key)) {
      agv1PositionX = SensingObjectTransientData.soMap.get(soAgv1Key).get(0).getPositionX();
    }
    String soPerson0Key = "d5c6bbcfcbc0e0efb00ed68f8ca64e1a_0_person";
    if (SensingObjectTransientData.soMap.containsKey(soPerson0Key)) {
      person0PositionZ = SensingObjectTransientData.soMap.get(soPerson0Key).get(0).getPositionZ();
    }
    String soPerson1Key = "14e3634bcb9369f4f2dec462dbecd63c_1_person";
    if (SensingObjectTransientData.soMap.containsKey(soPerson1Key)) {
      person1PositionZ = SensingObjectTransientData.soMap.get(soPerson1Key).get(0).getPositionZ();
    }

    SensingObjectTransientData.soMap.clear();
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());
    // AGV0
    agv0PositionX += 10;
    if (agv0PositionX > 300) {
      agv0PositionX = 90.0;
    }
    List<SensingObject> soAgv0List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("AGV");
      so.setPositionX(agv0PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(agv0PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgv0List.add(so);
    }
    SensingObjectTransientData.soMap.put(soAgv0Key, soAgv0List);
    // AGV1
    agv1PositionX += 10;
    if (agv1PositionX > 300) {
      agv1PositionX = 90.0;
    }
    List<SensingObject> soAgv1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("AGV");
      so.setPositionX(agv1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(agv1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgv1List.add(so);
    }
    SensingObjectTransientData.soMap.put(soAgv1Key, soAgv1List);
    // person0
    person0PositionZ -= 10;
    if (person0PositionZ < -370) {
      person0PositionZ = -170.0;
    }
    List<SensingObject> soPerson0List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("0");
      so.setSoType("person");
      so.setPositionX(person0PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person0PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson0List.add(so);
    }
    SensingObjectTransientData.soMap.put(soPerson0Key, soPerson0List);
    // person1
    person1PositionZ -= 10;
    if (person1PositionZ < -680) {
      person1PositionZ = -500.0;
    }
    List<SensingObject> soPerson1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("person");
      so.setPositionX(person1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson1List.add(so);
    }
    SensingObjectTransientData.soMap.put(soPerson1Key, soPerson1List);

  }

}
