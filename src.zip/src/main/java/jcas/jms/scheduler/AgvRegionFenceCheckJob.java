package jcas.jms.scheduler;

import java.awt.Polygon;
import java.util.ArrayList;
import java.util.List;
import jcas.jms.api.agv.AgvMotionAgent;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.region.FencePoint;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * AgvRegionFenceCheckJob is the class for agv not out of fence job.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvRegionFenceCheckJob implements Job {
  @SuppressWarnings("unused")
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvRegionFenceCheckJob.class);
  ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    if (!RegionTransientData.regionMap.isEmpty() && !AgvTransientData.agvNaviMap.isEmpty()
        && !SensingObjectTransientData.soMap.isEmpty()) {

      List<AgvNavi> agvNaviList = new ArrayList<AgvNavi>(AgvTransientData.agvNaviMap.values());
      List<String> navigatingAgvIdList = new ArrayList<String>();
      for (AgvNavi an : agvNaviList) {
        if (!an.getNaviStatus().equals("finish")) {
          navigatingAgvIdList.add(an.getSoAgvId());
        }
      }

      List<SensingObject> soAgvList = new ArrayList<SensingObject>();
      for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
        SensingObject so = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
        for (SensingObject s : sesingList) {
          so.setSoId(s.getSoId());
          so.setSoType(s.getSoType());
          so.setLocatingRegionId(s.getLocatingRegionId());
          so.setCreateTime(s.getCreateTime());
          so.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
        }
        positionX = positionX / sesingList.size();
        positionZ = positionZ / sesingList.size();
        velocityX = velocityX / sesingList.size();
        velocityY = velocityY / sesingList.size();
        velocityZ = velocityZ / sesingList.size();
        so.setPositionX(positionX);
        so.setPositionY(0.0);
        so.setPositionZ(positionZ);
        so.setVelocityX(velocityX);
        so.setVelocityY(velocityY);
        so.setVelocityZ(velocityZ);
        if (so.getSoType().equals("AGV")) {
          soAgvList.add(so);
        }
      }

      List<Region> regionList = new ArrayList<Region>(RegionTransientData.regionMap.values());
      for (Region r : regionList) {
        List<FencePoint> polygonalFencePoints = r.getPolygonalFencePoints();
        Polygon regionPolygonalFence = new Polygon();
        for (FencePoint fp : polygonalFencePoints) {
          int fpX = (int) Math.floor(fp.getPositionX());
          int fpZ = (int) Math.floor(fp.getPositionZ());
          regionPolygonalFence.addPoint(fpX, fpZ);
        }

        for (SensingObject soAgv : soAgvList) {
          if (soAgv.getLocatingRegionId().equals(r.getRegionId()) && navigatingAgvIdList.contains(soAgv.getSoId())) {
            double positionAgvX = soAgv.getPositionX();
            double positionAgvZ = soAgv.getPositionZ();
            if (!regionPolygonalFence.contains(positionAgvX, positionAgvZ)) {
              // Out of fence
              @SuppressWarnings("unused")
              AgvMotionAgent agvMotionAgent = new AgvMotionAgent(Integer.parseInt(soAgv.getSoId()));
              // agvMotionAgent.execAgvStop();
              // agvMotionAgent.execRebound();
              // LOGGER.info("AGV" + soAgv.getSoId() + " run out of region fence: " + r.getRegionName() + ", ("
              // + positionAgvX + ", 0, " + positionAgvZ + "), LocatingRegionId: " + soAgv.getLocatingRegionId());
            }

          }
        }
      }
    }

  }

}
