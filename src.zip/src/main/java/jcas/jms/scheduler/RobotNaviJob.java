package jcas.jms.scheduler;

import java.util.ArrayList;
import java.util.List;
import jcas.jms.api.posture.RobotMotionAgent;
import jcas.jms.model.event.EventService;
import jcas.jms.model.mode.ModeTransientData;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * RobotNaviJob is the class for dog navigation job.
 *
 * @author Industrial Technology Research Institute
 */
public class RobotNaviJob implements Job {
  // private static final Logger LOGGER = LoggerFactory.getLogger(RobotNaviJob.class);
  ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
  EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    if (!RegionTransientData.regionMap.isEmpty() && !SensingObjectTransientData.soMap.isEmpty()) {
      List<SensingObject> soPersonList = new ArrayList<SensingObject>();
      for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
        SensingObject so = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
        for (SensingObject s : sesingList) {
          so.setSoId(s.getSoId());
          so.setSoType(s.getSoType());
          so.setLocatingRegionId(s.getLocatingRegionId());
          so.setCreateTime(s.getCreateTime());
          so.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
        }
        positionX = positionX / sesingList.size();
        positionZ = positionZ / sesingList.size();
        velocityX = velocityX / sesingList.size();
        velocityY = velocityY / sesingList.size();
        velocityZ = velocityZ / sesingList.size();
        so.setPositionX(positionX);
        so.setPositionY(0.0);
        so.setPositionZ(positionZ);
        so.setVelocityX(velocityX);
        so.setVelocityY(velocityY);
        so.setVelocityZ(velocityZ);
        if (so.getSoType().equals("person")) {
          soPersonList.add(so);
        }
      }
      // LOGGER.info("Person Number: " + soPersonList.size());

      if (soPersonList.size() == 1) {
        SensingObject so = soPersonList.get(0);
        Integer nineSquareIndex = 1;
        nineSquareIndex = getGridNumber(so.getPositionX(), Math.abs(so.getPositionZ()), 600, 500, 3, 3);
        for (String robotId : ModeTransientData.robotNaviMap.keySet()) {
          if (ModeTransientData.robotNaviMap.get(robotId) && nineSquareIndex <= 6) {
            // Enabled
            RobotMotionAgent motionAgent = new RobotMotionAgent(robotId);
            motionAgent.execRobotNavi(String.valueOf(nineSquareIndex));
            // LOGGER.info("Person Position: " + so.getPositionX() + ", " + so.getPositionY() + ", " +
            // so.getPositionZ());
          }
        }
      }

    }
  }

  private int getGridNumber(double x, double y, double width, double height, int rows, int cols) {
    // 計算每個格子的寬度和高度
    double cellWidth = width / cols;
    double cellHeight = height / rows;

    // 判斷人位於哪一列和哪一行
    int row = (int) (y / cellHeight);
    int col = (int) (x / cellWidth);

    // 檢查範圍以避免超出界限
    if (row >= rows || col >= cols || row < 0 || col < 0) {
      // System.out.println("Position out of bounds");
      return -1;
    }

    // 計算九宮格編號 (左上角為 1)
    return row * cols + col + 1;
  }
}
