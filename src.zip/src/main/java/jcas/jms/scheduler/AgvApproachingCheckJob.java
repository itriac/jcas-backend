package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.vecmath.Point3d;
import jcas.jms.api.agv.AgvMotionAgent;
import jcas.jms.model.agv.AgvNavi;
import jcas.jms.model.agv.AgvTransientData;
import jcas.jms.model.event.Event;
import jcas.jms.model.event.EventConfig;
import jcas.jms.model.event.EventService;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.event.OccurConditionConfig;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import jcas.jms.util.Md5Util;
import jcas.jms.util.TransientDataUtil;
import org.json.simple.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * AgvApproachingCheckJob is the class for agv collision alarm job.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvApproachingCheckJob implements Job {
  private static final Logger LOGGER = LoggerFactory.getLogger(AgvApproachingCheckJob.class);
  ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
  EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

  @SuppressWarnings("unchecked")
  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    if (!RegionTransientData.regionMap.isEmpty() && !EventTransientData.ecMap.isEmpty()
        && !AgvTransientData.agvNaviMap.isEmpty() && !SensingObjectTransientData.soMap.isEmpty()) {
      List<AgvNavi> agvNaviList = new ArrayList<AgvNavi>(AgvTransientData.agvNaviMap.values());
      List<String> navigatingAgvIdList = new ArrayList<String>();
      for (AgvNavi an : agvNaviList) {
        if (!an.getNaviStatus().equals("finish")) {
          navigatingAgvIdList.add(an.getSoAgvId());
        }
      }

      List<SensingObject> soPersonList = new ArrayList<SensingObject>();
      List<SensingObject> soAgvList = new ArrayList<SensingObject>();
      for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
        SensingObject so = new SensingObject();
        Double positionX = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
        for (SensingObject s : sesingList) {
          so.setSoId(s.getSoId());
          so.setSoType(s.getSoType());
          so.setLocatingRegionId(s.getLocatingRegionId());
          so.setCreateTime(s.getCreateTime());
          so.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
        }
        positionX = positionX / sesingList.size();
        positionZ = positionZ / sesingList.size();
        velocityX = velocityX / sesingList.size();
        velocityY = velocityY / sesingList.size();
        velocityZ = velocityZ / sesingList.size();
        so.setPositionX(positionX);
        so.setPositionY(0.0);
        so.setPositionZ(positionZ);
        so.setVelocityX(velocityX);
        so.setVelocityY(velocityY);
        so.setVelocityZ(velocityZ);
        if (so.getSoType().equals("AGV")) {
          soAgvList.add(so);
        } else if (so.getSoType().equals("person")) {
          soPersonList.add(so);
        }
      }

      List<Region> regionList = new ArrayList<Region>(RegionTransientData.regionMap.values());
      List<EventConfig> ecList = new ArrayList<EventConfig>(EventTransientData.ecMap.values());
      for (Region r : regionList) {
        for (EventConfig ec : ecList) {
          // AGV Approaching
          if (ec.getBindingRegionId().equals(r.getRegionId()) && ec.getExecEnable()
              && ec.getMessage().equals("AGV_APPROACHING")) {
            for (SensingObject soAgv : soAgvList) {
              if (soAgv.getLocatingRegionId().equals(r.getRegionId())
                  && navigatingAgvIdList.contains(soAgv.getSoId())) {
                Point3d positionAgv = new Point3d();
                positionAgv.x = soAgv.getPositionX();
                positionAgv.y = soAgv.getPositionY();
                positionAgv.z = soAgv.getPositionZ();
                for (SensingObject soPerson : soPersonList) {
                  if (soPerson.getLocatingRegionId().equals(r.getRegionId())) {
                    Point3d positionPerson = new Point3d();
                    positionPerson.x = soPerson.getPositionX();
                    positionPerson.y = soPerson.getPositionY();
                    positionPerson.z = soPerson.getPositionZ();
                    String unfinishedEventKey = Md5Util
                        .getMd5(ec.getEventConfigId() + "_" + soPerson.getSoId() + "_" + soAgv.getSoId());
                    Double thresholdDistance = positionPerson.distance(positionAgv);
                    OccurConditionConfig ocConfig = ec.getOccurConditionConfig();
                    Date date = new Date();
                    Timestamp nowTime = new Timestamp(date.getTime());

                    if (ocConfig.getLessThreshold()) {
                      if (thresholdDistance < ocConfig.getThresholdValue() * 3) {
                        // Occur
                        if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
                          // NEW!! Insert DB and memory
                          Event newAlarm = new Event();
                          newAlarm.setEventConfig(ec);
                          newAlarm.setCreateTime(nowTime);
                          newAlarm.setOccurTime(nowTime);
                          JSONObject eventInfoJsonObject = new JSONObject();
                          eventInfoJsonObject.put("unfinishedEventKey", unfinishedEventKey);
                          String extraInfo = "soPersonId: " + soPerson.getSoId() + ", soAgvId: " + soAgv.getSoId();
                          eventInfoJsonObject.put("extraInfo", extraInfo);
                          newAlarm.setEventInfo(eventInfoJsonObject.toJSONString());
                          eventService.addEvent(newAlarm);
                          // Refresh memory
                          TransientDataUtil.refreshUnfinishedEventMap();
                          LOGGER.info(
                              "AgvApproachingCheckJob NEW Person soId: " + soPerson.getSoId() + ", " + positionPerson
                                  + ", unfinishedEventKey: " + unfinishedEventKey + ", Distance: " + thresholdDistance);
                        } else {
                          // AGAIN!! Update occur time in memory
                          EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setOccurTime(nowTime);
                          // LOGGER.info(
                          // "AgvApproachingCheckJob AGAIN Person soId: " + soPerson.getSoId() + ", " + positionPerson
                          // + ", unfinishedEventKey: " + unfinishedEventKey + ", Distance: " + thresholdDistance);
                        }
                        if (thresholdDistance < ocConfig.getThresholdValue() * 1.5) {
                          AgvMotionAgent agvMotionAgent = new AgvMotionAgent(Integer.parseInt(soAgv.getSoId()));
                          agvMotionAgent.execAgvStop();
                        }
                      } else {
                        // Solved
                        if (EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
                          // Update DB and remove from memory
                          Event solvedAlarm = EventTransientData.unfinishedEventMap.get(unfinishedEventKey);
                          solvedAlarm.setFinished(true);
                          solvedAlarm.setFinishTime(nowTime);
                          eventService.updateEvent(solvedAlarm);
                          EventTransientData.unfinishedEventMap.remove(unfinishedEventKey);
                          LOGGER.info(
                              "AgvApproachingCheckJob Solved Person soId: " + soPerson.getSoId() + ", " + positionPerson
                                  + ", unfinishedEventKey: " + unfinishedEventKey + ", Distance: " + thresholdDistance);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
