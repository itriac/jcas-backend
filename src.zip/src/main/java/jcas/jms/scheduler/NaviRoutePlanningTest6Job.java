package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.api.agv.AgvNaviResource;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * NaviRoutePlanningTest6Job is the class for navi route planning test job.
 *
 * @author Industrial Technology Research Institute
 */
public class NaviRoutePlanningTest6Job implements Job {
  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());

    // AGV1
    List<Double> agv1PositionXs = new ArrayList<Double>();
    agv1PositionXs.add(40.0);
    agv1PositionXs.add(55.0);
    agv1PositionXs.add(70.0);
    agv1PositionXs.add(85.0);
    agv1PositionXs.add(100.0);
    agv1PositionXs.add(110.0);
    agv1PositionXs.add(120.0);
    agv1PositionXs.add(138.0);
    agv1PositionXs.add(155.0);
    agv1PositionXs.add(170.0);
    agv1PositionXs.add(190.0);
    agv1PositionXs.add(215.0);
    agv1PositionXs.add(240.0);
    List<Double> agv1PositionZs = new ArrayList<Double>();
    agv1PositionZs.add(-550.0);
    agv1PositionZs.add(-565.0);
    agv1PositionZs.add(-580.0);
    agv1PositionZs.add(-595.0);
    agv1PositionZs.add(-610.0);
    agv1PositionZs.add(-630.0);
    agv1PositionZs.add(-650.0);
    agv1PositionZs.add(-640.0);
    agv1PositionZs.add(-630.0);
    agv1PositionZs.add(-620.0);
    agv1PositionZs.add(-610.0);
    agv1PositionZs.add(-595.0);
    agv1PositionZs.add(-580.0);

    String soAgv1Key = "1_AGV";
    Integer agv1PositionIndex = 0;
    if (SensingObjectTransientData.soMap.containsKey(soAgv1Key)) {
      Double tmpAgv1PositionX = SensingObjectTransientData.soMap.get(soAgv1Key).get(0).getPositionX();
      Integer tmpAgv1PositionIndex = agv1PositionXs.indexOf(tmpAgv1PositionX);
      agv1PositionIndex = tmpAgv1PositionIndex + 1;
    }

    if (agv1PositionIndex > 12) {
      AgvNaviResource anr = new AgvNaviResource();
      anr.deleteAgvNavi("1", "person", "14e3634bcb9369f4f2dec462dbecd63c", "1", "AGV");
      agv1PositionIndex = 0;
    }

    Double agv1PositionX = agv1PositionXs.get(agv1PositionIndex);
    Double agv1PositionZ = agv1PositionZs.get(agv1PositionIndex);

    List<SensingObject> soAgv1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("AGV");
      so.setPositionX(agv1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(agv1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      if (agv1PositionZ > -400) {
        so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      } else {
        so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      }
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgv1List.add(so);
    }
    // LOGGER.info("agv1PositionZ: " + agv1PositionZ + ", locatingRegionId: " +
    // soAgv1List.get(0).getLocatingRegionId());
    SensingObjectTransientData.soMap.put(soAgv1Key, soAgv1List);

    // person1
    Double person1PositionX = 300.0;
    Double person1PositionZ = -550.0;
    List<SensingObject> soPerson1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("person");
      so.setPositionX(person1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson1List.add(so);
    }
    String soPerson1Key = "14e3634bcb9369f4f2dec462dbecd63c_1_person";
    SensingObjectTransientData.soMap.put(soPerson1Key, soPerson1List);

    // person2
    Double person2PositionX = 120.0;
    Double person2PositionZ = -520.0;
    List<SensingObject> soPerson2List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("2");
      so.setSoType("person");
      so.setPositionX(person2PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person2PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson2List.add(so);
    }
    String soPerson2Key = "14e3634bcb9369f4f2dec462dbecd63c_2_person";
    SensingObjectTransientData.soMap.put(soPerson2Key, soPerson2List);

    // person3
    Double person3PositionX = 180.0;
    Double person3PositionZ = -520.0;
    List<SensingObject> soPerson3List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("3");
      so.setSoType("person");
      so.setPositionX(person3PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person3PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson3List.add(so);
    }
    String soPerson3Key = "14e3634bcb9369f4f2dec462dbecd63c_3_person";
    SensingObjectTransientData.soMap.put(soPerson3Key, soPerson3List);

    // person4
    Double person4PositionX = 120.0;
    Double person4PositionZ = -580.0;
    List<SensingObject> soPerson4List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("4");
      so.setSoType("person");
      so.setPositionX(person4PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person4PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson4List.add(so);
    }
    String soPerson4Key = "14e3634bcb9369f4f2dec462dbecd63c_4_person";
    SensingObjectTransientData.soMap.put(soPerson4Key, soPerson4List);

    // person5
    Double person5PositionX = 210.0;
    Double person5PositionZ = -530.0;
    List<SensingObject> soPerson5List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("5");
      so.setSoType("person");
      so.setPositionX(person5PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person5PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson5List.add(so);
    }
    String soPerson5Key = "14e3634bcb9369f4f2dec462dbecd63c_5_person";
    SensingObjectTransientData.soMap.put(soPerson5Key, soPerson5List);

  }

}
