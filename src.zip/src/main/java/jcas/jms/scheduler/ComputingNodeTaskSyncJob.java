package jcas.jms.scheduler;

import java.util.ArrayList;
import java.util.List;
import jcas.jms.model.resource.ComputingNode;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.model.task.TaskTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ComputingNodeTaskSyncJob is the class for sync task in computing node job.
 *
 * @author Industrial Technology Research Institute
 */
public class ComputingNodeTaskSyncJob implements Job {
  private static final Logger LOGGER = LoggerFactory.getLogger(ComputingNodeTaskSyncJob.class);

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    List<ComputingNode> cnList = new ArrayList<ComputingNode>(ComputingNodeTransientData.cnMap.values());
    for (ComputingNode cn : cnList) {
      List<String> taskIdList = cn.getTaskIds();
      List<String> removedTaskIdList = new ArrayList<String>();
      Boolean allTaskFinish = true;
      if (taskIdList != null && !taskIdList.isEmpty() && taskIdList.size() > 1) {
        for (int i = 0; i < taskIdList.size(); i++) {
          String taskId = taskIdList.get(i);
          String taskStatus = TaskTransientData.taskMap.get(taskId).getTaskStatus();
          if (!taskStatus.equals("finish")) {
            allTaskFinish = false;
          }
        }
        if (allTaskFinish) {
          // Leave the last finish task
          for (int i = 0; i < taskIdList.size() - 1; i++) {
            removedTaskIdList.add(taskIdList.get(i));
          }
        } else {
          // Directly remove all finished tasks
          for (int i = 0; i < taskIdList.size(); i++) {
            String taskId = taskIdList.get(i);
            String taskStatus = TaskTransientData.taskMap.get(taskId).getTaskStatus();
            if (taskStatus.equals("finish")) {
              removedTaskIdList.add(taskIdList.get(i));
            }
          }
        }
      }
      for (String removedTaskId : removedTaskIdList) {
        TaskTransientData.taskMap.remove(removedTaskId);
        ComputingNodeTransientData.cnMap.get(cn.getCnId()).getTaskIds().remove(removedTaskId);
        LOGGER.info("Task: " + removedTaskId + " was removed from Node: " + cn.getCnId());
      }
    }
  }
}
