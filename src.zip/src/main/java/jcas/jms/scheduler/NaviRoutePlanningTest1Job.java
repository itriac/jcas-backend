package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.api.agv.AgvNaviResource;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * NaviRoutePlanningTestJob is the class for navi route planning test job.
 *
 * @author Industrial Technology Research Institute
 */
public class NaviRoutePlanningTest1Job implements Job {

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    Date date = new Date();
    Timestamp nowTime = new Timestamp(date.getTime());

    // AGV1
    Double agv1PositionX = 290.0;
    Double agv1PositionZ = -600.0;
    String soAgv1Key = "1_AGV";
    if (SensingObjectTransientData.soMap.containsKey(soAgv1Key)) {
      agv1PositionZ = SensingObjectTransientData.soMap.get(soAgv1Key).get(0).getPositionZ();
    }
    agv1PositionZ += 5;
    if (agv1PositionZ > -240) {
      AgvNaviResource anr = new AgvNaviResource();
      anr.deleteAgvNavi("1", "person", "d5c6bbcfcbc0e0efb00ed68f8ca64e1a", "1", "AGV");
      agv1PositionZ = -600.0;
    }
    List<SensingObject> soAgv1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("AGV");
      so.setPositionX(agv1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(agv1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      if (agv1PositionZ > -400) {
        so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      } else {
        so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      }
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soAgv1List.add(so);
    }
    // LOGGER.info("agv1PositionZ: " + agv1PositionZ + ", locatingRegionId: " +
    // soAgv1List.get(0).getLocatingRegionId());
    SensingObjectTransientData.soMap.put(soAgv1Key, soAgv1List);

    // person1
    Double person1PositionX = 290.0;
    Double person1PositionZ = -200.0;
    List<SensingObject> soPerson1List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("1");
      so.setSoType("person");
      so.setPositionX(person1PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person1PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("d5c6bbcfcbc0e0efb00ed68f8ca64e1a");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson1List.add(so);
    }
    String soPerson1Key = "d5c6bbcfcbc0e0efb00ed68f8ca64e1a_1_person";
    SensingObjectTransientData.soMap.put(soPerson1Key, soPerson1List);

    // person2
    Double person2PositionX = 260.0;
    Double person2PositionZ = -450.0;
    List<SensingObject> soPerson2List = new ArrayList<SensingObject>();
    for (int i = 0; i < 7; i++) {
      SensingObject so = new SensingObject();
      so.setSoId("2");
      so.setSoType("person");
      so.setPositionX(person2PositionX);
      so.setPositionY(0.0);
      so.setPositionZ(person2PositionZ);
      so.setVelocityX(0.0);
      so.setVelocityY(0.0);
      so.setVelocityZ(0.0);
      so.setLocatingRegionId("14e3634bcb9369f4f2dec462dbecd63c");
      so.setCreateTime(nowTime);
      so.setUpdateTime(nowTime);
      soPerson2List.add(so);
    }
    String soPerson2Key = "14e3634bcb9369f4f2dec462dbecd63c_2_person";
    SensingObjectTransientData.soMap.put(soPerson2Key, soPerson2List);

  }

}
