package jcas.jms.scheduler;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.model.event.Event;
import jcas.jms.model.event.EventConfig;
import jcas.jms.model.event.EventService;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.event.OccurConditionConfig;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.sensing.SensingObject;
import jcas.jms.model.sensing.SensingObjectTransientData;
import jcas.jms.util.Md5Util;
import jcas.jms.util.TransientDataUtil;
import org.json.simple.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * PersonCrowdedCheckJob is the class for person crowded alarm job.
 *
 * @author Industrial Technology Research Institute
 */
public class PersonCrowdedCheckJob implements Job {
  ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);
  EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

  @SuppressWarnings("unchecked")
  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    if (!RegionTransientData.regionMap.isEmpty() && !EventTransientData.ecMap.isEmpty()
        && !SensingObjectTransientData.soMap.isEmpty()) {
      List<Region> regionList = new ArrayList<Region>(RegionTransientData.regionMap.values());
      List<EventConfig> ecList = new ArrayList<EventConfig>(EventTransientData.ecMap.values());
      List<SensingObject> soPersonList = new ArrayList<SensingObject>();
      for (String regionSoIdType : SensingObjectTransientData.soMap.keySet()) {
        SensingObject so = new SensingObject();
        Double positionX = 0.0;
        Double positionY = 0.0;
        Double positionZ = 0.0;
        Double velocityX = 0.0;
        Double velocityY = 0.0;
        Double velocityZ = 0.0;
        List<SensingObject> sesingList = SensingObjectTransientData.soMap.get(regionSoIdType);
        for (SensingObject s : sesingList) {
          so.setSoId(s.getSoId());
          so.setSoType(s.getSoType());
          so.setLocatingRegionId(s.getLocatingRegionId());
          so.setCreateTime(s.getCreateTime());
          so.setUpdateTime(s.getUpdateTime());
          positionX += s.getPositionX();
          positionY += s.getPositionY();
          positionZ += s.getPositionZ();
          velocityX += s.getVelocityX();
          velocityY += s.getVelocityY();
          velocityZ += s.getVelocityZ();
        }
        positionX = positionX / sesingList.size();
        positionY = positionY / sesingList.size();
        positionZ = positionZ / sesingList.size();
        velocityX = velocityX / sesingList.size();
        velocityY = velocityY / sesingList.size();
        velocityZ = velocityZ / sesingList.size();
        so.setPositionX(positionX);
        so.setPositionY(positionY);
        so.setPositionZ(positionZ);
        so.setVelocityX(velocityX);
        so.setVelocityY(velocityY);
        so.setVelocityZ(velocityZ);
        if (!so.getSoType().equals("AGV")) {
          soPersonList.add(so);
        }
      }

      for (Region r : regionList) {
        for (EventConfig ec : ecList) {
          // PERSON_CROWDED
          if (ec.getBindingRegionId().equals(r.getRegionId()) && ec.getExecEnable()
              && ec.getMessage().equals("PERSON_CROWDED")) {
            Integer personThresholdNumber = 0;
            for (SensingObject soPerson : soPersonList) {
              if (soPerson.getLocatingRegionId().equals(r.getRegionId())) {
                personThresholdNumber++;
                String unfinishedEventKey = Md5Util.getMd5(String.valueOf(ec.getEventConfigId()));
                OccurConditionConfig ocConfig = ec.getOccurConditionConfig();
                Date date = new Date();
                Timestamp nowTime = new Timestamp(date.getTime());
                if (ocConfig.getGreaterThreshold()) {
                  if (personThresholdNumber > ocConfig.getThresholdValue()) {
                    // Occur
                    if (!EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
                      // NEW!! Insert DB and memory
                      Event newAlarm = new Event();
                      newAlarm.setEventConfig(ec);
                      newAlarm.setCreateTime(nowTime);
                      newAlarm.setOccurTime(nowTime);
                      JSONObject eventInfoJsonObject = new JSONObject();
                      eventInfoJsonObject.put("unfinishedEventKey", unfinishedEventKey);
                      String extraInfo = "";
                      eventInfoJsonObject.put("extraInfo", extraInfo);
                      newAlarm.setEventInfo(eventInfoJsonObject.toJSONString());
                      eventService.addEvent(newAlarm);
                      // Refresh memory
                      TransientDataUtil.refreshUnfinishedEventMap();
                    } else {
                      // AGAIN!! Update occur time in memory
                      EventTransientData.unfinishedEventMap.get(unfinishedEventKey).setOccurTime(nowTime);
                    }
                  } else {
                    // Solved
                    if (EventTransientData.unfinishedEventMap.containsKey(unfinishedEventKey)) {
                      // Update DB and remove from memory
                      Event solvedAlarm = EventTransientData.unfinishedEventMap.get(unfinishedEventKey);
                      solvedAlarm.setFinished(true);
                      solvedAlarm.setFinishTime(nowTime);
                      eventService.updateEvent(solvedAlarm);
                      EventTransientData.unfinishedEventMap.remove(unfinishedEventKey);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
