package jcas.jms.util;

import java.awt.Polygon;
import java.awt.geom.Line2D;

/**
 * SpaceUtil is the class to compute spcae.
 *
 * @author Industrial Technology Research Institute
 */
public class SpaceUtil {

  private SpaceUtil() {

  }

  /**
   * Gets intersect result.
   */
  public static boolean lineIntersectPolygon(Line2D line, Polygon poly) {
    for (int i = 0; i < poly.npoints; i++) {
      int nextI = (i + 1) % poly.npoints;
      Line2D edge = new Line2D.Double(poly.xpoints[i], poly.ypoints[i], poly.xpoints[nextI], poly.ypoints[nextI]);
      if (line.intersectsLine(edge)) {
        return true;
      }
    }
    return false;
  }

}
