package jcas.jms.util;

import java.security.MessageDigest;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MD5Util is the class to generate md5.
 *
 * @author Industrial Technology Research Institute
 */
public class Md5Util {
  private static final Logger LOGGER = LoggerFactory.getLogger(Md5Util.class);
  private static MessageDigest digest = null;

  private Md5Util() {
  }

  /**
   * Gets md5 string.
   */
  public static synchronized String getMd5(String input) {
    try {
      digest = MessageDigest.getInstance("MD5");
    } catch (Exception ex) {
      LOGGER.error("Cannot get MessageDigest.", ex);
    }

    if (digest == null) {
      return input;
    }

    try {
      digest.update(input.getBytes("UTF-8"));
    } catch (java.io.UnsupportedEncodingException ex) {
      LOGGER.error("Assertion: This should never occur.");
    }
    byte[] rawData = digest.digest();
    String retValue = Hex.encodeHexString(rawData);
    return retValue;
  }

}
