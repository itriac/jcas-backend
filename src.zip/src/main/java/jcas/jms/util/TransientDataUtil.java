package jcas.jms.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jcas.jms.model.event.Event;
import jcas.jms.model.event.EventConfig;
import jcas.jms.model.event.EventConfigService;
import jcas.jms.model.event.EventService;
import jcas.jms.model.event.EventTransientData;
import jcas.jms.model.event.SupportedEvent;
import jcas.jms.model.event.SupportedEventService;
import jcas.jms.model.mode.ModeTransientData;
import jcas.jms.model.region.Region;
import jcas.jms.model.region.RegionService;
import jcas.jms.model.region.RegionTransientData;
import jcas.jms.model.resource.ComputingNode;
import jcas.jms.model.resource.ComputingNodeConfig;
import jcas.jms.model.resource.ComputingNodeConfigService;
import jcas.jms.model.resource.ComputingNodeTransientData;
import jcas.jms.model.task.TaskConfig;
import jcas.jms.model.task.TaskConfigService;
import jcas.jms.model.task.TaskTransientData;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * TransientDataUtil is the class to manage transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class TransientDataUtil {
  private static final Logger LOGGER = LoggerFactory.getLogger(TransientDataUtil.class);
  private static ApplicationContext ac = new AnnotationConfigApplicationContext(jcas.jms.config.WebConfig.class);

  private TransientDataUtil() {

  }

  /**
   * Refreshs computing node config transient data.
   */
  public static void refreshCnConfigMap() {
    ComputingNodeTransientData.cnConfigMap.clear();
    ComputingNodeConfigService cnConfigService = ac.getBean(jcas.jms.model.resource.ComputingNodeConfigService.class);
    for (ComputingNodeConfig cnConfig : cnConfigService.getComputingNodeConfigList()) {
      ComputingNodeTransientData.cnConfigMap.put(cnConfig.getCnId(), cnConfig);
    }
    LOGGER.info("Refresh cnConfigMap");
  }

  /**
   * Refreshs computing node transient data.
   */
  public static void refreshCnMap() {
    ComputingNodeTransientData.cnMap.clear();
    List<ComputingNodeConfig> cnConfigList = new ArrayList<ComputingNodeConfig>(
        ComputingNodeTransientData.cnConfigMap.values());
    for (ComputingNodeConfig cnConfig : cnConfigList) {
      ComputingNode cn = new ComputingNode();
      cn.setCnId(cnConfig.getCnId());
      cn.setCnName(cnConfig.getCnName());
      List<String> taskIdList = new ArrayList<String>();
      cn.setTaskIds(taskIdList);
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      cn.setCreateTime(nowTime);
      cn.setUpdateTime(nowTime);
      ComputingNodeTransientData.cnMap.put(cnConfig.getCnId(), cn);
    }
    LOGGER.info("Refresh cnMap");
  }

  /**
   * Refreshs task config transient data.
   */
  public static void refreshTaskConfigMap() {
    TaskTransientData.taskConfigMap.clear();
    TaskConfigService taskConfigService = ac.getBean(jcas.jms.model.task.TaskConfigService.class);
    for (TaskConfig taskConfig : taskConfigService.getTaskConfigList()) {
      TaskTransientData.taskConfigMap.put(taskConfig.getTaskName(), taskConfig);
    }
    LOGGER.info("Refresh taskConfigMap");
  }

  /**
   * Refreshs region transient data.
   */
  public static void refreshRegionMap() {
    RegionTransientData.regionMap.clear();
    RegionService regionService = ac.getBean(jcas.jms.model.region.RegionService.class);
    for (Region r : regionService.getRegionList()) {
      RegionTransientData.regionMap.put(r.getRegionId(), r);
      RegionTransientData.regionAnchorMap.put(r.getRegionId(), r.getAnchors());
    }
    LOGGER.info("Refresh RegionMap");
  }

  /**
   * Refreshs supported event transient data.
   */
  public static void refreshSupportedEventMap() {
    EventTransientData.sem.clear();
    SupportedEventService supportedEventService = ac.getBean(jcas.jms.model.event.SupportedEventService.class);
    for (SupportedEvent se : supportedEventService.getSupportedEventList()) {
      EventTransientData.sem.put(se.getSupportedEventCode(), se);
    }
    LOGGER.info("Refresh SupportedEventMap");
  }

  /**
   * Refreshs event config transient data.
   */
  public static void refreshEventConfigMap() {
    EventTransientData.ecMap.clear();
    EventConfigService eventConfigService = ac.getBean(jcas.jms.model.event.EventConfigService.class);
    for (EventConfig ec : eventConfigService.getEventConfigList()) {
      if (ec.getExecEnable()) {
        EventTransientData.ecMap.put(ec.getEventConfigId(), ec);
      }
    }
    LOGGER.info("Refresh EventConfigMap");
  }

  /**
   * Refreshs event transient data.
   */
  public static void refreshUnfinishedEventMap() {
    EventService eventService = ac.getBean(jcas.jms.model.event.EventService.class);

    // Update Status
    if (!EventTransientData.unfinishedEventMap.isEmpty()) {
      for (String unfinishedEventKey : EventTransientData.unfinishedEventMap.keySet()) {
        Event unfinishedEvent = EventTransientData.unfinishedEventMap.get(unfinishedEventKey);
        eventService.updateEvent(unfinishedEvent);
      }
    }

    EventTransientData.unfinishedEventMap.clear();
    try {
      JSONParser parser = new JSONParser();
      for (Event e : eventService.getEventList()) {
        if (!e.getFinished()) {
          JSONObject eventInfoJsonObject = (JSONObject) parser.parse(e.getEventInfo());
          String unfinishedEventKey = (String) eventInfoJsonObject.get("unfinishedEventKey");
          if (unfinishedEventKey != null && !unfinishedEventKey.isEmpty()) {
            EventTransientData.unfinishedEventMap.put(unfinishedEventKey, e);
          }
        }
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    }
    LOGGER.info("Refresh UnfinishedEventMap");
  }

  /**
   * Refreshs mode transient data.
   */
  public static void refreshModeMap() {

    ModeTransientData.mmWPostureMap.clear();
    ModeTransientData.csiPostureMap.clear();
    ModeTransientData.robotNaviMap.clear();
    ModeTransientData.lotteryMap.clear();
    ModeTransientData.mmWPostureMap.put("DOG1", false);
    ModeTransientData.mmWPostureMap.put("DOG2", false);
    ModeTransientData.mmWPostureMap.put("AMR1", false);
    ModeTransientData.csiPostureMap.put("DOG1", false);
    ModeTransientData.csiPostureMap.put("DOG2", false);
    ModeTransientData.csiPostureMap.put("AMR1", false);
    ModeTransientData.robotNaviMap.put("DOG1", false);
    ModeTransientData.robotNaviMap.put("DOG2", false);
    ModeTransientData.robotNaviMap.put("AMR1", false);
    ModeTransientData.lotteryMap.put("LOTTERY1", false);
    LOGGER.info("Refresh ModeMap");
  }
}
