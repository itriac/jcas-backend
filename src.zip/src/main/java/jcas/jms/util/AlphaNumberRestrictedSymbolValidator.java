package jcas.jms.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * AlphaNumberRestrictedSymbolValidator is the class to validate.
 *
 * @author Industrial Technology Research Institute
 */
public class AlphaNumberRestrictedSymbolValidator {
  private Pattern pattern;
  private Matcher matcher;

  private static final String PATTERN = "^[\\w./-]+$";

  public AlphaNumberRestrictedSymbolValidator() {
    pattern = Pattern.compile(PATTERN);
  }

  public boolean validate(String input) {
    matcher = pattern.matcher(input);
    return matcher.matches();
  }
}
