package jcas.jms.model.event;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import jcas.jms.db.DbManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * SupportedEventService is the class for SupportedEvent DB management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class SupportedEventService {
  private static final Logger LOGGER = LoggerFactory.getLogger(SupportedEventService.class);
  private DbManager dbm;

  public SupportedEventService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets SupportedEvent list from DB.
   *
   * @return {@code List<SupportedEvent>}
   */
  public List<SupportedEvent> getSupportedEventList() {
    List<SupportedEvent> supportedEventList = new ArrayList<SupportedEvent>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM supported_event";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      while (rs.next()) {
        SupportedEvent supportedEvent = new SupportedEvent(rs.getInt("supported_event_code"),
            rs.getString("supported_event_name"), rs.getString("supported_event_type"),
            rs.getString("supported_message"), rs.getBoolean("built_in"), rs.getString("supported_event_info"));
        supportedEventList.add(supportedEvent);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return supportedEventList;
  }

  /**
   * Adds SupportedEvent into DB.
   *
   * @param supportedEvent {@code SupportedEvent}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addSupportedEvent(SupportedEvent supportedEvent) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO supported_event (`supported_event_code`, "
          + "`supported_event_name`, `supported_event_type`, `supported_message`, "
          + "`built_in`, `supported_event_info`) VALUES (?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(supportedEvent.getSupportedEventCode());
      data.add(supportedEvent.getSupportedEventName());
      data.add(supportedEvent.getSupportedEventType());
      data.add(supportedEvent.getSupportedMessage());
      if (supportedEvent.getBuiltIn()) {
        data.add(1);
      } else {
        data.add(0);
      }
      data.add(supportedEvent.getSupportedEventInfo());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add SupportedEvent Success: " + supportedEvent.getSupportedMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates SupportedEvent into DB.
   *
   * @param supportedEvent {@code SupportedEvent}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateSupportedEvent(SupportedEvent supportedEvent) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "UPDATE supported_event SET supported_event_name=?, "
          + "supported_event_type=?, supported_message=?, built_in=?, "
          + "supported_event_info=? WHERE supported_event_code=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(supportedEvent.getSupportedEventName());
      data.add(supportedEvent.getSupportedEventType());
      data.add(supportedEvent.getSupportedMessage());
      if (supportedEvent.getBuiltIn()) {
        data.add(1);
      } else {
        data.add(0);
      }
      data.add(supportedEvent.getSupportedEventInfo());
      data.add(supportedEvent.getSupportedEventCode());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update SupportedEvent Success: " + supportedEvent.getSupportedMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes SupportedEvent from DB.
   *
   * @param supportedEventCode The supported event code
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean deleteSupportedEvent(Integer supportedEventCode) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "DELETE FROM supported_event WHERE supported_event_code=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(supportedEventCode);
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Delete SupportedEvent Success: " + supportedEventCode);
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}
