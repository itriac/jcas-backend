package jcas.jms.model.event;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import jcas.jms.db.DbManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * EventService is the class for Event DB management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class EventService {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventService.class);
  private DbManager dbm;

  public EventService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets Event list from DB.
   *
   * @return {@code List<Event>}
   */
  public List<Event> getEventList() {
    List<Event> eventList = new ArrayList<Event>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM event AS e INNER JOIN event_conf AS ec " + "ON(e.event_conf_id=ec.event_conf_id)";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      ObjectMapper objectMapper = new ObjectMapper();
      while (rs.next()) {
        String occurCondition = rs.getString("occur_condition");
        OccurConditionConfig ocConfig = new OccurConditionConfig();
        if (!occurCondition.isEmpty()) {
          ocConfig = objectMapper.readValue(occurCondition, OccurConditionConfig.class);
        }
        String notifyMethod = rs.getString("notify_method");
        NotifyMethodConfig nmConfig = new NotifyMethodConfig();
        if (!notifyMethod.isEmpty()) {
          nmConfig = objectMapper.readValue(notifyMethod, NotifyMethodConfig.class);
        }
        EventConfig eventConfig = new EventConfig(rs.getInt("event_conf_id"), rs.getString("event_name"),
            rs.getInt("event_code"), rs.getString("event_type"), rs.getString("severity"), rs.getString("message"),
            ocConfig, rs.getBoolean("exec_enable"), nmConfig, rs.getInt("notify_interval"), rs.getString("sop"),
            rs.getString("binding_region_id"), rs.getString("event_conf_info"));
        Event event = new Event(rs.getInt("event_id"), eventConfig, rs.getTimestamp("create_time"),
            rs.getTimestamp("occur_time"), rs.getBoolean("notified"), rs.getTimestamp("notify_time"),
            rs.getBoolean("finished"), rs.getTimestamp("finish_time"), rs.getString("event_info"));
        eventList.add(event);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return eventList;
  }

  /**
   * Adds Event into DB.
   *
   * @param event {@code Event}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addEvent(Event event) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO event (`event_conf_id`, `create_time`, "
          + "`occur_time`, `notified`, `notify_time`, `finished`, "
          + "`finish_time`, `event_info`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(event.getEventConfig().getEventConfigId());
      data.add(event.getCreateTime());
      data.add(event.getOccurTime());
      data.add(0);
      data.add(null);
      data.add(0);
      data.add(null);
      data.add(event.getEventInfo());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add Event Success: " + event.getEventConfig().getMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates Event into DB.
   *
   * @param event {@code Event}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateEvent(Event event) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "UPDATE event SET occur_time=?, notified=?, notify_time=?, finished=?, "
          + "finish_time=?, event_info=? WHERE event_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(event.getOccurTime());
      if (event.getNotified()) {
        data.add(1);
      } else {
        data.add(0);
      }
      data.add(event.getNotifyTime());
      if (event.getFinished()) {
        data.add(1);
      } else {
        data.add(0);
      }
      data.add(event.getFinishTime());
      data.add(event.getEventInfo());
      data.add(event.getEventId());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update Event Success: " + event.getEventConfig().getMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes Event from DB.
   *
   * @param eventIds The event ids
   * @return {@code true} succeed; {@code false} fail
   */
  public Boolean deleteEvent(String eventIds) {
    Boolean result = false;
    PreparedStatement ps;
    List<String> eventIdList = Arrays.asList(eventIds.split(","));
    Connection con = null;
    try {
      con = dbm.getConnection();
      for (String eventId : eventIdList) {
        String sql = "DELETE FROM event WHERE event_id=?";
        ps = dbm.createPreparedStatement(sql, con);
        ArrayList<String> data = new ArrayList<String>();
        data.add(eventId);
        dbm.update(ps, data);
        dbm.closePreparedStatement(ps);
        LOGGER.info("Delete Event Success: " + eventId);
        result = true;
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}