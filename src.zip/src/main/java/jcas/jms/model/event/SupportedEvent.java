package jcas.jms.model.event;

/**
 * SupportedEvent is the class for SupportedEvent bean.
 *
 * @author Industrial Technology Research Institute
 */
public class SupportedEvent {
  private Integer supportedEventCode;
  private String supportedEventName;
  private String supportedEventType;
  private String supportedMessage;
  private Boolean builtIn;
  private String supportedEventInfo;

  public SupportedEvent() {
    super();
  }

  /**
   * SupportedEvent constructor.
   *
   * @param supportedEventCode The supported event code
   * @param supportedEventName The supported event name
   * @param supportedEventType The supported event type
   * @param supportedMessage   The supported event message
   * @param builtIn            The supported event built in
   * @param supportedEventInfo For extension use
   */
  public SupportedEvent(Integer supportedEventCode, String supportedEventName, String supportedEventType,
      String supportedMessage, Boolean builtIn, String supportedEventInfo) {
    super();
    this.supportedEventCode = supportedEventCode;
    this.supportedEventName = supportedEventName;
    this.supportedEventType = supportedEventType;
    this.supportedMessage = supportedMessage;
    this.builtIn = builtIn;
    this.supportedEventInfo = supportedEventInfo;
  }

  public String getSupportedEventName() {
    return supportedEventName;
  }

  public void setSupportedEventName(String supportedEventName) {
    this.supportedEventName = supportedEventName;
  }

  public Integer getSupportedEventCode() {
    return supportedEventCode;
  }

  public void setSupportedEventCode(Integer supportedEventCode) {
    this.supportedEventCode = supportedEventCode;
  }

  public String getSupportedEventType() {
    return supportedEventType;
  }

  public void setSupportedEventType(String supportedEventType) {
    this.supportedEventType = supportedEventType;
  }

  public String getSupportedMessage() {
    return supportedMessage;
  }

  public void setSupportedMessage(String supportedMessage) {
    this.supportedMessage = supportedMessage;
  }

  public Boolean getBuiltIn() {
    return builtIn;
  }

  public void setBuiltIn(Boolean builtIn) {
    this.builtIn = builtIn;
  }

  public String getSupportedEventInfo() {
    return supportedEventInfo;
  }

  public void setSupportedEventInfo(String supportedEventInfo) {
    this.supportedEventInfo = supportedEventInfo;
  }

}
