package jcas.jms.model.event;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import jcas.jms.db.DbManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * EventConfigService is the class for EventConfig DB management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class EventConfigService {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventConfigService.class);
  private DbManager dbm;

  public EventConfigService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets EventConfig list from DB.
   *
   * @return {@code List<EventConfig>}
   */
  public List<EventConfig> getEventConfigList() {
    List<EventConfig> eventConfigList = new ArrayList<EventConfig>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM event_conf";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      ObjectMapper objectMapper = new ObjectMapper();
      while (rs.next()) {
        String occurCondition = rs.getString("occur_condition");
        OccurConditionConfig ocConfig = new OccurConditionConfig();
        if (!occurCondition.isEmpty()) {
          ocConfig = objectMapper.readValue(occurCondition, OccurConditionConfig.class);
        }
        String notifyMethod = rs.getString("notify_method");
        NotifyMethodConfig nmConfig = new NotifyMethodConfig();
        if (!notifyMethod.isEmpty()) {
          nmConfig = objectMapper.readValue(notifyMethod, NotifyMethodConfig.class);
        }
        EventConfig eventConfig = new EventConfig(rs.getInt("event_conf_id"), rs.getString("event_name"),
            rs.getInt("event_code"), rs.getString("event_type"), rs.getString("severity"), rs.getString("message"),
            ocConfig, rs.getBoolean("exec_enable"), nmConfig, rs.getInt("notify_interval"), rs.getString("sop"),
            rs.getString("binding_region_id"), rs.getString("event_conf_info"));
        eventConfigList.add(eventConfig);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return eventConfigList;
  }

  /**
   * Adds EventConfig into DB.
   *
   * @param eventConfig {@code EventConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addEventConfig(EventConfig eventConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO event_conf (`event_name`, `event_code`, "
          + "`event_type`, `severity`, `message`, `occur_condition`, `exec_enable`, "
          + "`notify_method`, `notify_interval`, `sop`, `binding_region_id`, `event_conf_info`) " + "VALUES "
          + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(eventConfig.getEventName());
      data.add(eventConfig.getEventCode());
      data.add(eventConfig.getEventType());
      data.add(eventConfig.getSeverity());
      data.add(eventConfig.getMessage());
      OccurConditionConfig ocConfig = eventConfig.getOccurConditionConfig();
      String occurCondition = objectMapper.writeValueAsString(ocConfig);
      data.add(occurCondition);
      if (eventConfig.getExecEnable()) {
        data.add(1);
      } else {
        data.add(0);
      }
      NotifyMethodConfig nmConfig = eventConfig.getNotifyMethodConfig();
      String notifyMethod = objectMapper.writeValueAsString(nmConfig);
      data.add(notifyMethod);
      data.add(eventConfig.getNotifyInterval());
      data.add(eventConfig.getSop());
      data.add(eventConfig.getBindingRegionId());
      data.add(eventConfig.getEventConfigInfo());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add EventConfig Success: " + eventConfig.getMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates EventConfig into DB.
   *
   * @param eventConfig {@code EventConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateEventConfig(EventConfig eventConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      con = dbm.getConnection();
      String sql = "UPDATE event_conf SET event_name=?, event_code=?, "
          + "event_type=?, severity=?, message=?, occur_condition=?, "
          + "exec_enable=?, notify_method=?, notify_interval=?, sop=?, "
          + "binding_region_id=?, event_conf_info=? WHERE event_conf_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(eventConfig.getEventName());
      data.add(eventConfig.getEventCode());
      data.add(eventConfig.getEventType());
      data.add(eventConfig.getSeverity());
      data.add(eventConfig.getMessage());
      OccurConditionConfig ocConfig = eventConfig.getOccurConditionConfig();
      String occurCondition = objectMapper.writeValueAsString(ocConfig);
      data.add(occurCondition);
      if (eventConfig.getExecEnable()) {
        data.add(1);
      } else {
        data.add(0);
      }
      NotifyMethodConfig nmConfig = eventConfig.getNotifyMethodConfig();
      String notifyMethod = objectMapper.writeValueAsString(nmConfig);
      data.add(notifyMethod);
      data.add(eventConfig.getNotifyInterval());
      data.add(eventConfig.getSop());
      data.add(eventConfig.getBindingRegionId());
      data.add(eventConfig.getEventConfigInfo());
      data.add(eventConfig.getEventConfigId());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update EventConfig Success: " + eventConfig.getMessage());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes EventConfig from DB.
   *
   * @param eventConfigId The event config id
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean deleteEventConfig(Integer eventConfigId) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "DELETE FROM event_conf WHERE event_conf_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(eventConfigId);
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Delete EventConfig Success: " + eventConfigId);
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}
