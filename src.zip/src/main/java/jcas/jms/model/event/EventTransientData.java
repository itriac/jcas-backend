package jcas.jms.model.event;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * EventTransientData is the class for event transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class EventTransientData {
  public static Map<Integer, SupportedEvent> sem = new ConcurrentHashMap<Integer, SupportedEvent>();
  public static Map<Integer, EventConfig> ecMap = new ConcurrentHashMap<Integer, EventConfig>();
  // md5 hash of eventConfigId and eventInfo as Key
  public static Map<String, Event> unfinishedEventMap = new ConcurrentHashMap<String, Event>();
}