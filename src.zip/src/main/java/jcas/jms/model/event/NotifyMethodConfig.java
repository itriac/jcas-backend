package jcas.jms.model.event;

import io.swagger.annotations.ApiModelProperty;

/**
 * NotifyMethodConfig is the class for NotifyMethodConfig bean.
 *
 * @author Industrial Technology Research Institute
 */
public class NotifyMethodConfig {
  private Boolean gui;
  private Boolean email;
  private Boolean sms;
  private Boolean line;

  @ApiModelProperty(value = "", required = true, example = "true")
  public Boolean getGui() {
    return gui;
  }

  public void setGui(Boolean gui) {
    this.gui = gui;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getEmail() {
    return email;
  }

  public void setEmail(Boolean email) {
    this.email = email;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getSms() {
    return sms;
  }

  public void setSms(Boolean sms) {
    this.sms = sms;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getLine() {
    return line;
  }

  public void setLine(Boolean line) {
    this.line = line;
  }
}
