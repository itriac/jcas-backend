package jcas.jms.model.event;

import io.swagger.annotations.ApiModelProperty;

/**
 * OccurConditionConfig is the class for OccurConditionConfig bean.
 *
 * @author Industrial Technology Research Institute
 */
public class OccurConditionConfig {
  private Boolean greaterThreshold;
  private Boolean lessThreshold;
  private Boolean equalThreshold;
  private Integer thresholdValue;
  private Boolean occurEvent;

  @ApiModelProperty(value = "", required = true, example = "true")
  public Boolean getGreaterThreshold() {
    return greaterThreshold;
  }

  public void setGreaterThreshold(Boolean greaterThreshold) {
    this.greaterThreshold = greaterThreshold;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getLessThreshold() {
    return lessThreshold;
  }

  public void setLessThreshold(Boolean lessThreshold) {
    this.lessThreshold = lessThreshold;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getEqualThreshold() {
    return equalThreshold;
  }

  public void setEqualThreshold(Boolean equalThreshold) {
    this.equalThreshold = equalThreshold;
  }

  @ApiModelProperty(value = "", required = true, example = "80")
  public Integer getThresholdValue() {
    return thresholdValue;
  }

  public void setThresholdValue(Integer thresholdValue) {
    this.thresholdValue = thresholdValue;
  }

  @ApiModelProperty(value = "", required = true, example = "false")
  public Boolean getOccurEvent() {
    return occurEvent;
  }

  public void setOccurEvent(Boolean occurEvent) {
    this.occurEvent = occurEvent;
  }

}