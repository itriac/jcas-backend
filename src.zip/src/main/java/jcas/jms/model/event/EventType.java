package jcas.jms.model.event;

/**
 * EventType is the enum for event type list.
 *
 * @author Industrial Technology Research Institute
 */
public enum EventType {
  CN_FAULT, MMWAVE_FAULT, CAMERA_FAULT, CPU_ALARM, MEMORY_ALARM, GPU_ALARM, POWER_ALARM, SENSING_ALARM, SENSING_EVENT,
  NAVI_EVENT, CN_EVENT
}
