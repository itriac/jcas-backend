package jcas.jms.model.event;

/**
 * EventConfig is the class for EventConfig bean.
 *
 * @author Industrial Technology Research Institute
 */
public class EventConfig {
  private Integer eventConfigId;
  private String eventName;
  private Integer eventCode;
  private String eventType;
  private String severity;
  private String message;
  private OccurConditionConfig occurConditionConfig;
  private Boolean execEnable;
  private NotifyMethodConfig notifyMethodConfig;
  private Integer notifyInterval;
  private String sop;
  private String bindingRegionId;
  private String eventConfigInfo;

  public EventConfig() {
    super();
  }

  /**
   * EventConfig constructor.
   *
   * @param eventConfigId        The event config id
   * @param eventName            The event name
   * @param eventCode            The event code
   * @param eventType            The event type
   * @param severity             The event severity
   * @param message              The event message
   * @param occurConditionConfig {@code OccurConditionConfig}
   * @param execEnable           The event exec enable
   * @param notifyMethodConfig   {@code NotifyMethodConfig}
   * @param notifyInterval       The notify interval
   * @param sop                  The sop
   * @param bindingRegionId      The binding regionId
   * @param eventConfigInfo      For extension use
   */
  public EventConfig(Integer eventConfigId, String eventName, Integer eventCode, String eventType, String severity,
      String message, OccurConditionConfig occurConditionConfig, Boolean execEnable,
      NotifyMethodConfig notifyMethodConfig, Integer notifyInterval, String sop, String bindingRegionId,
      String eventConfigInfo) {
    super();
    this.eventConfigId = eventConfigId;
    this.eventName = eventName;
    this.eventCode = eventCode;
    this.eventType = eventType;
    this.severity = severity;
    this.message = message;
    this.occurConditionConfig = occurConditionConfig;
    this.execEnable = execEnable;
    this.notifyMethodConfig = notifyMethodConfig;
    this.notifyInterval = notifyInterval;
    this.sop = sop;
    this.bindingRegionId = bindingRegionId;
    this.eventConfigInfo = eventConfigInfo;
  }

  public Integer getEventConfigId() {
    return eventConfigId;
  }

  public void setEventConfigId(Integer eventConfigId) {
    this.eventConfigId = eventConfigId;
  }

  public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  public Integer getEventCode() {
    return eventCode;
  }

  public void setEventCode(Integer eventCode) {
    this.eventCode = eventCode;
  }

  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  public String getSeverity() {
    return severity;
  }

  public void setSeverity(String severity) {
    this.severity = severity;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public OccurConditionConfig getOccurConditionConfig() {
    return occurConditionConfig;
  }

  public void setOccurConditionConfig(OccurConditionConfig occurConditionConfig) {
    this.occurConditionConfig = occurConditionConfig;
  }

  public Boolean getExecEnable() {
    return execEnable;
  }

  public void setExecEnable(Boolean execEnable) {
    this.execEnable = execEnable;
  }

  public NotifyMethodConfig getNotifyMethodConfig() {
    return notifyMethodConfig;
  }

  public void setNotifyMethodConfig(NotifyMethodConfig notifyMethodConfig) {
    this.notifyMethodConfig = notifyMethodConfig;
  }

  public Integer getNotifyInterval() {
    return notifyInterval;
  }

  public void setNotifyInterval(Integer notifyInterval) {
    this.notifyInterval = notifyInterval;
  }

  public String getSop() {
    return sop;
  }

  public void setSop(String sop) {
    this.sop = sop;
  }

  public String getBindingRegionId() {
    return bindingRegionId;
  }

  public void setBindingRegionId(String bindingRegionId) {
    this.bindingRegionId = bindingRegionId;
  }

  public String getEventConfigInfo() {
    return eventConfigInfo;
  }

  public void setEventConfigInfo(String eventConfigInfo) {
    this.eventConfigInfo = eventConfigInfo;
  }

}
