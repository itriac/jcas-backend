package jcas.jms.model.event;

import java.sql.Timestamp;

/**
 * Event is the class for Event bean.
 *
 * @author Industrial Technology Research Institute
 */
public class Event {
  private Integer eventId;
  private EventConfig eventConfig;
  private Timestamp createTime;
  private Timestamp occurTime;
  private Boolean notified;
  private Timestamp notifyTime;
  private Boolean finished;
  private Timestamp finishTime;
  private String eventInfo;

  public Event() {
    super();
  }

  /**
   * Event constructor.
   *
   * @param eventId     The event id
   * @param eventConfig {@code EventConfig}
   * @param createTime  The event create time
   * @param occurTime   The event occur time
   * @param notified    The event is notified
   * @param notifyTime  The event notify time
   * @param finished    The event is finished
   * @param finishTime  The event finish time
   * @param eventInfo   For extension use
   */
  public Event(Integer eventId, EventConfig eventConfig, Timestamp createTime, Timestamp occurTime, Boolean notified,
      Timestamp notifyTime, Boolean finished, Timestamp finishTime, String eventInfo) {
    super();
    this.eventId = eventId;
    this.eventConfig = eventConfig;
    this.createTime = createTime;
    this.occurTime = occurTime;
    this.notified = notified;
    this.notifyTime = notifyTime;
    this.finished = finished;
    this.finishTime = finishTime;
    this.eventInfo = eventInfo;
  }

  public Integer getEventId() {
    return eventId;
  }

  public void setEventId(Integer eventId) {
    this.eventId = eventId;
  }

  public EventConfig getEventConfig() {
    return eventConfig;
  }

  public void setEventConfig(EventConfig eventConfig) {
    this.eventConfig = eventConfig;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getOccurTime() {
    return occurTime;
  }

  public void setOccurTime(Timestamp occurTime) {
    this.occurTime = occurTime;
  }

  public Boolean getNotified() {
    return notified;
  }

  public void setNotified(Boolean notified) {
    this.notified = notified;
  }

  public Timestamp getNotifyTime() {
    return notifyTime;
  }

  public void setNotifyTime(Timestamp notifyTime) {
    this.notifyTime = notifyTime;
  }

  public Boolean getFinished() {
    return finished;
  }

  public void setFinished(Boolean finished) {
    this.finished = finished;
  }

  public Timestamp getFinishTime() {
    return finishTime;
  }

  public void setFinishTime(Timestamp finishTime) {
    this.finishTime = finishTime;
  }

  public String getEventInfo() {
    return eventInfo;
  }

  public void setEventInfo(String eventInfo) {
    this.eventInfo = eventInfo;
  }

}
