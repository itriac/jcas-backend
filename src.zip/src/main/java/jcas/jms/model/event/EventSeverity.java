package jcas.jms.model.event;

/**
 * EventSeverity is the enum for event severity list.
 *
 * @author Industrial Technology Research Institute
 */
public enum EventSeverity {
  CRITICAL, MAJOR, MINOR, WARNING, NORMAL
}
