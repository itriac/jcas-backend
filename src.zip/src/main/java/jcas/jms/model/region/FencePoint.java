package jcas.jms.model.region;

/**
 * FencePoint is the class for FencePoint bean.
 *
 * @author Industrial Technology Research Institute
 */
public class FencePoint {
  private Double positionX;
  private Double positionY;
  private Double positionZ;

  public FencePoint() {
    super();
  }

  /**
   * FencePoint constructor.
   *
   * @param positionX The x position of fence point
   * @param positionY The y position of fence point
   * @param positionZ The z position of fence point
   */
  public FencePoint(Double positionX, Double positionY, Double positionZ) {
    super();
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }
}
