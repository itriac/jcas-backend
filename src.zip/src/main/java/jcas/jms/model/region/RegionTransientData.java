package jcas.jms.model.region;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RegionTransientData is the class for region transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class RegionTransientData {
  public static Map<String, Region> regionMap = new ConcurrentHashMap<String, Region>();
  public static Map<String, List<Anchor>> regionAnchorMap = new ConcurrentHashMap<String, List<Anchor>>();
}
