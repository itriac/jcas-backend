package jcas.jms.model.region;

import java.sql.Timestamp;
import java.util.List;

/**
 * Region is the class for Region bean.
 *
 * @author Industrial Technology Research Institute
 */
public class Region {
  private String regionId;
  private String regionName;
  private String location;
  private List<String> cnOwnIds;
  private Timestamp createTime;
  private Timestamp updateTime;
  private List<Anchor> anchors; // regionInfo
  private List<FencePoint> polygonalFencePoints; // regionInfo

  public Region() {
    super();
  }

  /**
   * Region constructor.
   *
   * @param regionId             The region id
   * @param regionName           The region name
   * @param location             The region location
   * @param cnOwnIds             The region owns computing nodes
   * @param createTime           The region create time
   * @param updateTime           The region update time
   * @param anchors              {@code List<Anchor>}
   * @param polygonalFencePoints {@code List<FencePoint>}
   */
  public Region(String regionId, String regionName, String location, List<String> cnOwnIds, Timestamp createTime,
      Timestamp updateTime, List<Anchor> anchors, List<FencePoint> polygonalFencePoints) {
    super();
    this.regionId = regionId;
    this.regionName = regionName;
    this.location = location;
    this.cnOwnIds = cnOwnIds;
    this.createTime = createTime;
    this.updateTime = updateTime;
    this.anchors = anchors;
    this.polygonalFencePoints = polygonalFencePoints;
  }

  public String getRegionId() {
    return regionId;
  }

  public void setRegionId(String regionId) {
    this.regionId = regionId;
  }

  public String getRegionName() {
    return regionName;
  }

  public void setRegionName(String regionName) {
    this.regionName = regionName;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public List<String> getCnOwnIds() {
    return cnOwnIds;
  }

  public void setCnOwnIds(List<String> cnOwnIds) {
    this.cnOwnIds = cnOwnIds;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  public List<Anchor> getAnchors() {
    return anchors;
  }

  public void setAnchors(List<Anchor> anchors) {
    this.anchors = anchors;
  }

  public List<FencePoint> getPolygonalFencePoints() {
    return polygonalFencePoints;
  }

  public void setPolygonalFencePoints(List<FencePoint> polygonalFencePoints) {
    this.polygonalFencePoints = polygonalFencePoints;
  }

}
