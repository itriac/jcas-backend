package jcas.jms.model.region;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import jcas.jms.db.DbManager;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * RegionService is the class for Region DB management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class RegionService {
  private static final Logger LOGGER = LoggerFactory.getLogger(RegionService.class);
  private DbManager dbm;

  public RegionService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets Region list from DB.
   *
   * @return {@code List<Region>}
   */
  public List<Region> getRegionList() {
    List<Region> regionList = new ArrayList<Region>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM region";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      ObjectMapper objectMapper = new ObjectMapper();
      JSONParser parser = new JSONParser();
      while (rs.next()) {
        List<String> cnOwnIds = new ArrayList<String>();
        String cnOwnIdsContext = rs.getString("cn_own_ids");
        if (!cnOwnIdsContext.isEmpty()) {
          cnOwnIds = new ArrayList<String>(Arrays.asList(cnOwnIdsContext.split(",")));
        }
        List<Anchor> anchors = new ArrayList<Anchor>();
        List<FencePoint> polygonalFencePoints = new ArrayList<FencePoint>();
        String regionInfo = rs.getString("region_info");
        if (regionInfo != null && !regionInfo.isEmpty()) {
          JSONObject regionInfoJsonObject = (JSONObject) parser.parse(regionInfo);
          if (regionInfoJsonObject.containsKey("anchors")) {
            String anchorsContext = (String) regionInfoJsonObject.get("anchors");
            anchors = objectMapper.readValue(anchorsContext, new TypeReference<List<Anchor>>() {
            });
          }
          if (regionInfoJsonObject.containsKey("polygonalFencePoints")) {
            String polygonalFencePointsContext = (String) regionInfoJsonObject.get("polygonalFencePoints");
            polygonalFencePoints = objectMapper.readValue(polygonalFencePointsContext,
                new TypeReference<List<FencePoint>>() {
                });
          }
        }

        Region region = new Region(rs.getString("region_id"), rs.getString("region_name"), rs.getString("location"),
            cnOwnIds, rs.getTimestamp("create_time"), rs.getTimestamp("update_time"), anchors, polygonalFencePoints);
        regionList.add(region);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return regionList;
  }

  /**
   * Adds Region into DB.
   *
   * @param region {@code Region}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addRegion(Region region) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO region (`region_id`, `region_name`, `location`, "
          + "`cn_own_ids`, `create_time`, `update_time`, `region_info`) " + "VALUES (?, ?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(region.getRegionId());
      data.add(region.getRegionName());
      data.add(region.getLocation());
      String cnOwnIdsContext = "";
      if (!region.getCnOwnIds().isEmpty()) {
        cnOwnIdsContext = String.join(",", region.getCnOwnIds());
      }
      data.add(cnOwnIdsContext);
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      data.add(nowTime);
      JSONObject regionInfoJsonObject = new JSONObject();
      List<Anchor> anchors = region.getAnchors();
      regionInfoJsonObject.put("anchors", objectMapper.writeValueAsString(anchors));
      List<FencePoint> polygonalFencePoints = region.getPolygonalFencePoints();
      regionInfoJsonObject.put("polygonalFencePoints", objectMapper.writeValueAsString(polygonalFencePoints));
      String regionInfo = regionInfoJsonObject.toJSONString();
      data.add(regionInfo);
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add Region Success: " + region.getRegionName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates Region into DB.
   *
   * @param region {@code Region}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateRegion(Region region) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      con = dbm.getConnection();
      String sql = "UPDATE region SET location=?, cn_own_ids=?, update_time=?, region_info=? WHERE region_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(region.getLocation());
      String cnOwnIdsContext = "";
      if (!region.getCnOwnIds().isEmpty()) {
        cnOwnIdsContext = String.join(",", region.getCnOwnIds());
      }
      data.add(cnOwnIdsContext);
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      JSONObject regionInfoJsonObject = new JSONObject();
      List<Anchor> anchors = region.getAnchors();
      regionInfoJsonObject.put("anchors", objectMapper.writeValueAsString(anchors));
      List<FencePoint> polygonalFencePoints = region.getPolygonalFencePoints();
      regionInfoJsonObject.put("polygonalFencePoints", objectMapper.writeValueAsString(polygonalFencePoints));
      String regionInfo = regionInfoJsonObject.toJSONString();
      data.add(regionInfo);
      data.add(region.getRegionId());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update Region Success: " + region.getRegionName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes Region from DB.
   *
   * @param regionIds The region ids
   * @return {@code true} succeed; {@code false} fail
   */
  public Boolean deleteRegion(String regionIds) {
    Boolean result = false;
    PreparedStatement ps;
    List<String> regionIdList = Arrays.asList(regionIds.split(","));
    Connection con = null;
    try {
      con = dbm.getConnection();
      for (String regionId : regionIdList) {
        String sql = "DELETE FROM region WHERE region_id=?";
        ps = dbm.createPreparedStatement(sql, con);
        ArrayList<String> data = new ArrayList<String>();
        data.add(regionId);
        dbm.update(ps, data);
        dbm.closePreparedStatement(ps);
        LOGGER.info("Delete Region Success: " + regionId);
        result = true;
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}
