package jcas.jms.model.region;

/**
 * Anchor is the class for Anchor bean.
 *
 * @author Industrial Technology Research Institute
 */
public class Anchor {
  private String siblingRegionId;
  private String anchorType;
  private Double positionX;
  private Double positionY;
  private Double positionZ;

  public Anchor() {
    super();
  }

  /**
   * Anchor constructor.
   *
   * @param siblingRegionId The region id of other
   * @param anchorType      The anchor type
   * @param positionX       The x position of anchor
   * @param positionY       The y position of anchor
   * @param positionZ       The z position of anchor
   */
  public Anchor(String siblingRegionId, String anchorType, Double positionX, Double positionY, Double positionZ) {
    super();
    this.siblingRegionId = siblingRegionId;
    this.anchorType = anchorType;
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
  }

  public String getSiblingRegionId() {
    return siblingRegionId;
  }

  public void setSiblingRegionId(String siblingRegionId) {
    this.siblingRegionId = siblingRegionId;
  }

  public String getAnchorType() {
    return anchorType;
  }

  public void setAnchorType(String anchorType) {
    this.anchorType = anchorType;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }

}
