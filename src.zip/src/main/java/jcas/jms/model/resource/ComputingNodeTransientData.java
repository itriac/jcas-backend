package jcas.jms.model.resource;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ComputingNodeTransientData is the class for computing node transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class ComputingNodeTransientData {
  public static Map<String, ComputingNodeConfig> cnConfigMap = new ConcurrentHashMap<String, ComputingNodeConfig>();
  public static Map<String, ComputingNode> cnMap = new ConcurrentHashMap<String, ComputingNode>();
}
