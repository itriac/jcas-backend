package jcas.jms.model.resource;

/**
 * SensorInfo is the class for SensorInfo bean.
 *
 * @author Industrial Technology Research Institute
 */
public class SensorInfo {
  private String sensorName;
  private String sensorStatus;

  public SensorInfo() {
    super();
  }

  /**
   * SensorInfo constructor.
   *
   * @param sensorName   The sensor name
   * @param sensorStatus The sensor status
   */
  public SensorInfo(String sensorName, String sensorStatus) {
    super();
    this.sensorName = sensorName;
    this.sensorStatus = sensorStatus;
  }

  public String getSensorName() {
    return sensorName;
  }

  public void setSensorName(String sensorName) {
    this.sensorName = sensorName;
  }

  public String getSensorStatus() {
    return sensorStatus;
  }

  public void setSensorStatus(String sensorStatus) {
    this.sensorStatus = sensorStatus;
  }

}
