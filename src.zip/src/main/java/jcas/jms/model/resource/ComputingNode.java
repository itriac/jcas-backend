package jcas.jms.model.resource;

import java.sql.Timestamp;
import java.util.List;

/**
 * ComputingNode is the class for ComputingNode bean.
 *
 * @author Industrial Technology Research Institute
 */
public class ComputingNode {
  private String cnId;
  private String cnName;
  private Double cpuUsagePercent;
  private Double gpuUsagePercent;
  private Double memoryUsagePercent;
  private Double powerLeftPercent;
  private Double systemPowerW;
  // private Map<String, Double> nicSentBps;
  // private Map<String, Double> nicRecvBps;
  private Double cpuTempC;
  private Double gpuTempC;
  private Double memoryTempC;
  private Double nicTempC;
  private List<String> taskIds;
  private String cnStatus;
  private List<SensorInfo> sensorInfos;
  private Timestamp createTime;
  private Timestamp updateTime;

  public ComputingNode() {
    super();
  }

  /**
   * ComputingNode constructor.
   *
   * @param cnId               The computing node id
   * @param cnName             The computing node name
   * @param cpuUsagePercent    The cpu usage percent
   * @param gpuUsagePercent    The gpu usage percent
   * @param memoryUsagePercent The memory usage percent
   * @param powerLeftPercent   The power left percent
   * @param systemPowerW       The system power watt
   * @param cpuTempC           The cpu temperature
   * @param gpuTempC           The gpu temperature
   * @param memoryTempC        The memory temperature
   * @param nicTempC           The nic temperature
   * @param taskIds            The task id list
   * @param cnStatus           The computing node status
   * @param sensorInfos        The sensors status
   * @param createTime         The computing node create time
   * @param updateTime         The computing node update time
   */
  public ComputingNode(String cnId, String cnName, Double cpuUsagePercent, Double gpuUsagePercent,
      Double memoryUsagePercent, Double powerLeftPercent, Double systemPowerW, Double cpuTempC, Double gpuTempC,
      Double memoryTempC, Double nicTempC, List<String> taskIds, String cnStatus, List<SensorInfo> sensorInfos,
      Timestamp createTime, Timestamp updateTime) {
    super();
    this.cnId = cnId;
    this.cnName = cnName;
    this.cpuUsagePercent = cpuUsagePercent;
    this.gpuUsagePercent = gpuUsagePercent;
    this.memoryUsagePercent = memoryUsagePercent;
    this.powerLeftPercent = powerLeftPercent;
    this.systemPowerW = systemPowerW;
    this.cpuTempC = cpuTempC;
    this.gpuTempC = gpuTempC;
    this.memoryTempC = memoryTempC;
    this.nicTempC = nicTempC;
    this.taskIds = taskIds;
    this.cnStatus = cnStatus;
    this.sensorInfos = sensorInfos;
    this.createTime = createTime;
    this.updateTime = updateTime;
  }

  public String getCnId() {
    return cnId;
  }

  public void setCnId(String cnId) {
    this.cnId = cnId;
  }

  public String getCnName() {
    return cnName;
  }

  public void setCnName(String cnName) {
    this.cnName = cnName;
  }

  public Double getCpuUsagePercent() {
    return cpuUsagePercent;
  }

  public void setCpuUsagePercent(Double cpuUsagePercent) {
    this.cpuUsagePercent = cpuUsagePercent;
  }

  public Double getGpuUsagePercent() {
    return gpuUsagePercent;
  }

  public void setGpuUsagePercent(Double gpuUsagePercent) {
    this.gpuUsagePercent = gpuUsagePercent;
  }

  public Double getMemoryUsagePercent() {
    return memoryUsagePercent;
  }

  public void setMemoryUsagePercent(Double memoryUsagePercent) {
    this.memoryUsagePercent = memoryUsagePercent;
  }

  public Double getPowerLeftPercent() {
    return powerLeftPercent;
  }

  public void setPowerLeftPercent(Double powerLeftPercent) {
    this.powerLeftPercent = powerLeftPercent;
  }

  public Double getSystemPowerW() {
    return systemPowerW;
  }

  public void setSystemPowerW(Double systemPowerW) {
    this.systemPowerW = systemPowerW;
  }

  // public Map<String, Double> getNicSentBps() {
  // return nicSentBps;
  // }

  // public void setNicSentBps(Map<String, Double> nicSentBps) {
  // this.nicSentBps = nicSentBps;
  // }

  // public Map<String, Double> getNicRecvBps() {
  // return nicRecvBps;
  // }

  // public void setNicRecvBps(Map<String, Double> nicRecvBps) {
  // this.nicRecvBps = nicRecvBps;
  // }

  public Double getCpuTempC() {
    return cpuTempC;
  }

  public void setCpuTempC(Double cpuTempC) {
    this.cpuTempC = cpuTempC;
  }

  public Double getGpuTempC() {
    return gpuTempC;
  }

  public void setGpuTempC(Double gpuTempC) {
    this.gpuTempC = gpuTempC;
  }

  public Double getMemoryTempC() {
    return memoryTempC;
  }

  public void setMemoryTempC(Double memoryTempC) {
    this.memoryTempC = memoryTempC;
  }

  public Double getNicTempC() {
    return nicTempC;
  }

  public void setNicTempC(Double nicTempC) {
    this.nicTempC = nicTempC;
  }

  public List<String> getTaskIds() {
    return taskIds;
  }

  public void setTaskIds(List<String> taskIds) {
    this.taskIds = taskIds;
  }

  public String getCnStatus() {
    return cnStatus;
  }

  public void setCnStatus(String cnStatus) {
    this.cnStatus = cnStatus;
  }

  public List<SensorInfo> getSensorInfos() {
    return sensorInfos;
  }

  public void setSensorInfos(List<SensorInfo> sensorInfos) {
    this.sensorInfos = sensorInfos;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

}
