package jcas.jms.model.resource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import jcas.jms.db.DbManager;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ComputingNodeConfigService is the class for computing node db management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class ComputingNodeConfigService {
  private static final Logger LOGGER = LoggerFactory.getLogger(ComputingNodeConfigService.class);
  private DbManager dbm;

  public ComputingNodeConfigService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets ComputingNodeConfig list from db.
   *
   * @return {@code List<ComputingNodeConfig>}
   */
  public List<ComputingNodeConfig> getComputingNodeConfigList() {
    List<ComputingNodeConfig> cnConfigList = new ArrayList<ComputingNodeConfig>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM computing_node_conf";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      JSONParser parser = new JSONParser();
      while (rs.next()) {
        String ssJsonContext = rs.getString("supported_sensors");
        List<SupportedSensor> supportedSensors = new ArrayList<SupportedSensor>();
        if (!ssJsonContext.isEmpty()) {
          try {
            JSONArray ssJsonArray = (JSONArray) parser.parse(ssJsonContext);
            for (int i = 0; i < ssJsonArray.size(); i++) {
              JSONObject ssJsonObject = (JSONObject) ssJsonArray.get(i);
              SupportedSensor supportedSensor = new SupportedSensor();
              if (ssJsonObject.containsKey("ioName") && ssJsonObject.containsKey("sensorName")
                  && ssJsonObject.containsKey("manufacturerName")) {
                supportedSensor.setIoName((String) ssJsonObject.get("ioName"));
                supportedSensor.setSensorName((String) ssJsonObject.get("sensorName"));
                supportedSensor.setManufacturerName((String) ssJsonObject.get("manufacturerName"));
                supportedSensors.add(supportedSensor);
              }
            }
          } catch (Exception e) {
            LOGGER.error(e.getMessage());
          }
        }
        ComputingNodeConfig cnConfig = new ComputingNodeConfig(rs.getString("cn_id"), rs.getString("cn_name"),
            rs.getString("cn_ip"), rs.getString("cn_type"), rs.getInt("cpu_total_core"),
            rs.getDouble("cpu_max_percent"), rs.getLong("gpu_total_byte"), rs.getDouble("gpu_max_percent"),
            rs.getLong("memory_total_byte"), rs.getDouble("memory_max_percent"), rs.getBoolean("cn_power_plugged"),
            supportedSensors, rs.getTimestamp("create_time"), rs.getTimestamp("update_time"), rs.getString("cn_info"));
        cnConfigList.add(cnConfig);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return cnConfigList;
  }

  /**
   * Adds ComputingNodeConfig into db.
   *
   * @param cnConfig {@code ComputingNodeConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addComputingNodeConfig(ComputingNodeConfig cnConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO computing_node_conf (`cn_id`, `cn_name`, `cn_ip`, "
          + "`cn_type`, `cpu_total_core`, `cpu_max_percent`, `gpu_total_byte`, "
          + "`gpu_max_percent`, `memory_total_byte`, `memory_max_percent`, `cn_power_plugged`, "
          + "`supported_sensors`, `create_time`, `update_time`, `cn_info`) VALUES "
          + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(cnConfig.getCnId());
      data.add(cnConfig.getCnName());
      data.add(cnConfig.getCnIp());
      data.add(cnConfig.getCnType());
      data.add(cnConfig.getCpuTotalCore());
      data.add(cnConfig.getCpuMaxPercent());
      data.add(cnConfig.getGpuTotalByte());
      data.add(cnConfig.getGpuMaxPercent());
      data.add(cnConfig.getMemoryTotalByte());
      data.add(cnConfig.getMemoryMaxPercent());
      if (cnConfig.getCnPowerPlugged()) {
        data.add(1);
      } else {
        data.add(0);
      }
      List<SupportedSensor> supportedSensors = cnConfig.getSupportedSensors();
      JSONArray ssJsonArray = new JSONArray();
      for (SupportedSensor ss : supportedSensors) {
        JSONObject ssJsonObject = new JSONObject();
        if (!ss.getIoName().isEmpty() && !ss.getSensorName().isEmpty() && !ss.getManufacturerName().isEmpty()) {
          ssJsonObject.put("ioName", ss.getIoName());
          ssJsonObject.put("sensorName", ss.getSensorName());
          ssJsonObject.put("manufacturerName", ss.getManufacturerName());
          ssJsonArray.add(ssJsonObject);
        }
      }
      data.add(ssJsonArray.toJSONString());
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      data.add(nowTime);
      data.add(cnConfig.getCnInfo());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add ComputingNodeConfig Success: " + cnConfig.getCnName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates ComputingNodeConfig into db.
   *
   * @param cnConfig {@code ComputingNodeConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateComputingNodeConfig(ComputingNodeConfig cnConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "UPDATE computing_node_conf SET cn_ip=?, cn_type=?, cpu_total_core=?, cpu_max_percent=?, "
          + "gpu_total_byte=?, gpu_max_percent=?, memory_total_byte=?, memory_max_percent=?, cn_power_plugged=?, "
          + "supported_sensors=?, update_time=?, cn_info=? WHERE cn_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(cnConfig.getCnIp());
      data.add(cnConfig.getCnType());
      data.add(cnConfig.getCpuTotalCore());
      data.add(cnConfig.getCpuMaxPercent());
      data.add(cnConfig.getGpuTotalByte());
      data.add(cnConfig.getGpuMaxPercent());
      data.add(cnConfig.getMemoryTotalByte());
      data.add(cnConfig.getMemoryMaxPercent());
      if (cnConfig.getCnPowerPlugged()) {
        data.add(1);
      } else {
        data.add(0);
      }
      List<SupportedSensor> supportedSensors = cnConfig.getSupportedSensors();
      JSONArray ssJsonArray = new JSONArray();
      for (SupportedSensor ss : supportedSensors) {
        JSONObject ssJsonObject = new JSONObject();
        if (!ss.getIoName().isEmpty() && !ss.getSensorName().isEmpty() && !ss.getManufacturerName().isEmpty()) {
          ssJsonObject.put("ioName", ss.getIoName());
          ssJsonObject.put("sensorName", ss.getSensorName());
          ssJsonObject.put("manufacturerName", ss.getManufacturerName());
          ssJsonArray.add(ssJsonObject);
        }
      }
      data.add(ssJsonArray.toJSONString());
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      data.add(cnConfig.getCnInfo());
      data.add(cnConfig.getCnId());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update ComputingNodeConfig Success: " + cnConfig.getCnName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes ComputingNodeConfig from db.
   *
   * @param cnIds The computing node ids
   * @return {@code true} succeed; {@code false} fail
   */
  public Boolean deleteComputingNodeConfig(String cnIds) {
    Boolean result = false;
    PreparedStatement ps;
    List<String> cnIdList = Arrays.asList(cnIds.split(","));
    Connection con = null;
    try {
      con = dbm.getConnection();
      for (String cnId : cnIdList) {
        String sql = "DELETE FROM computing_node_conf WHERE cn_id=?";
        ps = dbm.createPreparedStatement(sql, con);
        ArrayList<String> data = new ArrayList<String>();
        data.add(cnId);
        dbm.update(ps, data);
        dbm.closePreparedStatement(ps);
        LOGGER.info("Delete ComputingNodeConfig Success: " + cnId);
        result = true;
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}
