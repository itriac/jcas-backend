package jcas.jms.model.resource;

/**
 * SupportedSensor is the class for SupportedSensor bean.
 *
 * @author Industrial Technology Research Institute
 */
public class SupportedSensor {
  private String ioName;
  private String sensorName;
  private String manufacturerName;

  public SupportedSensor() {
    super();
  }

  /**
   * SupportedSensor constructor.
   *
   * @param ioName           The io name
   * @param sensorName       The sensor name
   * @param manufacturerName The manufacturer name
   */
  public SupportedSensor(String ioName, String sensorName, String manufacturerName) {
    super();
    this.ioName = ioName;
    this.sensorName = sensorName;
    this.manufacturerName = manufacturerName;
  }

  public String getIoName() {
    return ioName;
  }

  public void setIoName(String ioName) {
    this.ioName = ioName;
  }

  public String getSensorName() {
    return sensorName;
  }

  public void setSensorName(String sensorName) {
    this.sensorName = sensorName;
  }

  public String getManufacturerName() {
    return manufacturerName;
  }

  public void setManufacturerName(String manufacturerName) {
    this.manufacturerName = manufacturerName;
  }

}
