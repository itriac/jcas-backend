package jcas.jms.model.resource;

import java.sql.Timestamp;
import java.util.List;

/**
 * ComputingNodeConfig is the class for ComputingNodeConfig bean.
 *
 * @author Industrial Technology Research Institute
 */
public class ComputingNodeConfig {
  private String cnId;
  private String cnName;
  private String cnIp;
  private String cnType;
  private Integer cpuTotalCore;
  private Double cpuMaxPercent;
  private Long gpuTotalByte;
  private Double gpuMaxPercent;
  private Long memoryTotalByte;
  private Double memoryMaxPercent;
  private Boolean cnPowerPlugged;
  private List<SupportedSensor> supportedSensors;
  private Timestamp createTime;
  private Timestamp updateTime;
  private String cnInfo;

  public ComputingNodeConfig() {
    super();
  }

  /**
   * ComputingNodeConfig constructor.
   *
   * @param cnId             The computing node id
   * @param cnName           The computing node name
   * @param cnIp             The computing node ip
   * @param cnType           The computing node type
   * @param cpuTotalCore     The cpu total core
   * @param cpuMaxPercent    The cpu offload policy
   * @param gpuTotalByte     The gpu total byte
   * @param gpuMaxPercent    The gpu offload policy
   * @param memoryTotalByte  The memory total byte
   * @param memoryMaxPercent The memory offload policy
   * @param cnPowerPlugged   The computing node power plugged
   * @param supportedSensors The computing node supported sensors
   * @param createTime       The computing node create time
   * @param updateTime       The computing node update time
   * @param cnInfo           For extension use
   */
  public ComputingNodeConfig(String cnId, String cnName, String cnIp, String cnType, Integer cpuTotalCore,
      Double cpuMaxPercent, Long gpuTotalByte, Double gpuMaxPercent, Long memoryTotalByte, Double memoryMaxPercent,
      Boolean cnPowerPlugged, List<SupportedSensor> supportedSensors, Timestamp createTime, Timestamp updateTime,
      String cnInfo) {
    super();
    this.cnId = cnId;
    this.cnName = cnName;
    this.cnIp = cnIp;
    this.cnType = cnType;
    this.cpuTotalCore = cpuTotalCore;
    this.cpuMaxPercent = cpuMaxPercent;
    this.gpuTotalByte = gpuTotalByte;
    this.gpuMaxPercent = gpuMaxPercent;
    this.memoryTotalByte = memoryTotalByte;
    this.memoryMaxPercent = memoryMaxPercent;
    this.cnPowerPlugged = cnPowerPlugged;
    this.supportedSensors = supportedSensors;
    this.createTime = createTime;
    this.updateTime = updateTime;
    this.cnInfo = cnInfo;
  }

  public String getCnId() {
    return cnId;
  }

  public void setCnId(String cnId) {
    this.cnId = cnId;
  }

  public String getCnName() {
    return cnName;
  }

  public void setCnName(String cnName) {
    this.cnName = cnName;
  }

  public String getCnIp() {
    return cnIp;
  }

  public void setCnIp(String cnIp) {
    this.cnIp = cnIp;
  }

  public String getCnType() {
    return cnType;
  }

  public void setCnType(String cnType) {
    this.cnType = cnType;
  }

  public Integer getCpuTotalCore() {
    return cpuTotalCore;
  }

  public void setCpuTotalCore(Integer cpuTotalCore) {
    this.cpuTotalCore = cpuTotalCore;
  }

  public Double getCpuMaxPercent() {
    return cpuMaxPercent;
  }

  public void setCpuMaxPercent(Double cpuMaxPercent) {
    this.cpuMaxPercent = cpuMaxPercent;
  }

  public Long getGpuTotalByte() {
    return gpuTotalByte;
  }

  public void setGpuTotalByte(Long gpuTotalByte) {
    this.gpuTotalByte = gpuTotalByte;
  }

  public Double getGpuMaxPercent() {
    return gpuMaxPercent;
  }

  public void setGpuMaxPercent(Double gpuMaxPercent) {
    this.gpuMaxPercent = gpuMaxPercent;
  }

  public Long getMemoryTotalByte() {
    return memoryTotalByte;
  }

  public void setMemoryTotalByte(Long memoryTotalByte) {
    this.memoryTotalByte = memoryTotalByte;
  }

  public Double getMemoryMaxPercent() {
    return memoryMaxPercent;
  }

  public void setMemoryMaxPercent(Double memoryMaxPercent) {
    this.memoryMaxPercent = memoryMaxPercent;
  }

  public Boolean getCnPowerPlugged() {
    return cnPowerPlugged;
  }

  public void setCnPowerPlugged(Boolean cnPowerPlugged) {
    this.cnPowerPlugged = cnPowerPlugged;
  }

  public List<SupportedSensor> getSupportedSensors() {
    return supportedSensors;
  }

  public void setSupportedSensors(List<SupportedSensor> supportedSensors) {
    this.supportedSensors = supportedSensors;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  public String getCnInfo() {
    return cnInfo;
  }

  public void setCnInfo(String cnInfo) {
    this.cnInfo = cnInfo;
  }

}
