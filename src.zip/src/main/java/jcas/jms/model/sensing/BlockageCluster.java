package jcas.jms.model.sensing;

import java.util.List;

/**
 * BlockageCluster is the class for BlockageCluster bean.
 *
 * @author Industrial Technology Research Institute
 */
public class BlockageCluster {
  private String bcId;
  private Boolean intersectNaviLine;
  private Boolean affectNaviPath;
  private String soRepresentId;
  private List<String> soBlockageIds;
  private List<BlockagePoint> polygonalBlockagePoints;

  public BlockageCluster() {
    super();
  }

  /**
   * BlockageCluster constructor.
   *
   * @param bcId                    The blockage cluster id
   * @param intersectNaviLine       intersect with navigation line
   * @param affectNaviPath          affect navigation path
   * @param soRepresentId           The represent point id
   * @param soBlockageIds           {@code List<String>}
   * @param polygonalBlockagePoints {@code List<BlockagePoint>}
   */
  public BlockageCluster(String bcId, Boolean intersectNaviLine, Boolean affectNaviPath, String soRepresentId,
      List<String> soBlockageIds, List<BlockagePoint> polygonalBlockagePoints) {
    super();
    this.bcId = bcId;
    this.intersectNaviLine = intersectNaviLine;
    this.affectNaviPath = affectNaviPath;
    this.soRepresentId = soRepresentId;
    this.soBlockageIds = soBlockageIds;
    this.polygonalBlockagePoints = polygonalBlockagePoints;
  }

  public String getBcId() {
    return bcId;
  }

  public void setBcId(String bcId) {
    this.bcId = bcId;
  }

  public Boolean getIntersectNaviLine() {
    return intersectNaviLine;
  }

  public void setIntersectNaviLine(Boolean intersectNaviLine) {
    this.intersectNaviLine = intersectNaviLine;
  }

  public Boolean getAffectNaviPath() {
    return affectNaviPath;
  }

  public void setAffectNaviPath(Boolean affectNaviPath) {
    this.affectNaviPath = affectNaviPath;
  }

  public String getSoRepresentId() {
    return soRepresentId;
  }

  public void setSoRepresentId(String soRepresentId) {
    this.soRepresentId = soRepresentId;
  }

  public List<String> getSoBlockageIds() {
    return soBlockageIds;
  }

  public void setSoBlockageIds(List<String> soBlockageIds) {
    this.soBlockageIds = soBlockageIds;
  }

  public List<BlockagePoint> getPolygonalBlockagePoints() {
    return polygonalBlockagePoints;
  }

  public void setPolygonalBlockagePoints(List<BlockagePoint> polygonalBlockagePoints) {
    this.polygonalBlockagePoints = polygonalBlockagePoints;
  }

}
