package jcas.jms.model.sensing;

import java.sql.Timestamp;

/**
 * SensingObject is the class for SensingObject bean.
 *
 * @author Industrial Technology Research Institute
 */
public class SensingObject {
  private String soId;
  private String soType;
  private Double positionX;
  private Double positionY;
  private Double positionZ;
  private Double velocityX;
  private Double velocityY;
  private Double velocityZ;
  private String locatingRegionId;
  private Timestamp createTime;
  private Timestamp updateTime;

  public SensingObject() {
    super();
  }

  /**
   * SensingObject constructor.
   *
   * @param soId             The sensing object id
   * @param soType           The sensing object type
   * @param positionX        The x position of sensing object
   * @param positionY        The y position of sensing object
   * @param positionZ        The z position of sensing object
   * @param velocityX        The x velocity of sensing object
   * @param velocityY        The y velocity of sensing object
   * @param velocityZ        The z velocity of sensing object
   * @param locatingRegionId The locating regionId
   * @param createTime       The sensing object create time
   * @param updateTime       The sensing object update time
   */
  public SensingObject(String soId, String soType, Double positionX, Double positionY, Double positionZ,
      Double velocityX, Double velocityY, Double velocityZ, String locatingRegionId, Timestamp createTime,
      Timestamp updateTime) {
    super();
    this.soId = soId;
    this.soType = soType;
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
    this.velocityX = velocityX;
    this.velocityY = velocityY;
    this.velocityZ = velocityZ;
    this.locatingRegionId = locatingRegionId;
    this.createTime = createTime;
    this.updateTime = updateTime;
  }

  public String getSoId() {
    return soId;
  }

  public void setSoId(String soId) {
    this.soId = soId;
  }

  public String getSoType() {
    return soType;
  }

  public void setSoType(String soType) {
    this.soType = soType;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }

  public Double getVelocityX() {
    return velocityX;
  }

  public void setVelocityX(Double velocityX) {
    this.velocityX = velocityX;
  }

  public Double getVelocityY() {
    return velocityY;
  }

  public void setVelocityY(Double velocityY) {
    this.velocityY = velocityY;
  }

  public Double getVelocityZ() {
    return velocityZ;
  }

  public void setVelocityZ(Double velocityZ) {
    this.velocityZ = velocityZ;
  }

  public String getLocatingRegionId() {
    return locatingRegionId;
  }

  public void setLocatingRegionId(String locatingRegionId) {
    this.locatingRegionId = locatingRegionId;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

}
