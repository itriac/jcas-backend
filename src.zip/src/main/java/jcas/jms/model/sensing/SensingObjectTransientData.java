package jcas.jms.model.sensing;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SensingObjectTransientData is the class for sensing object transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class SensingObjectTransientData {
  public static Map<String, List<SensingObject>> soMap = new ConcurrentHashMap<String, List<SensingObject>>();
}
