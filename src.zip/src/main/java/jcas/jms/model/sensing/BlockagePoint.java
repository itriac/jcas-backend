package jcas.jms.model.sensing;

/**
 * BlockagePoint is the class for BlockagePoint bean.
 *
 * @author Industrial Technology Research Institute
 */
public class BlockagePoint {
  private Double positionX;
  private Double positionY;
  private Double positionZ;

  public BlockagePoint() {
    super();
  }

  /**
   * BlockagePoint constructor.
   *
   * @param positionX The x position of blockage point
   * @param positionY The y position of blockage point
   * @param positionZ The z position of blockage point
   */
  public BlockagePoint(Double positionX, Double positionY, Double positionZ) {
    super();
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }

}
