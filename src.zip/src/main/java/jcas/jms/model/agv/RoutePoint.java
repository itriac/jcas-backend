package jcas.jms.model.agv;

/**
 * RoutePoint is the class for RoutePoint bean.
 *
 * @author Industrial Technology Research Institute
 */
public class RoutePoint {
  private Double positionX;
  private Double positionY;
  private Double positionZ;

  public RoutePoint() {
    super();
  }

  /**
   * RoutePoint constructor.
   *
   * @param positionX The x position of route
   * @param positionY The y position of route
   * @param positionZ The z position of route
   */
  public RoutePoint(Double positionX, Double positionY, Double positionZ) {
    super();
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }
}
