package jcas.jms.model.agv;

import java.sql.Timestamp;

/**
 * AgvNaviAid is the class for AgvNaviAid bean.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvNaviAid {
  private String soAgvId;
  private String soAgvType;
  private String soTargetId;
  private String soTargetType;
  private Double agvTargetAngle;
  private Double agvTargetDistance;
  private Timestamp createTime;
  private Timestamp updateTime;

  public AgvNaviAid() {
    super();
  }

  /**
   * AgvNaviAid constructor.
   *
   * @param soAgvId           The agv id
   * @param soAgvType         The agv type
   * @param soTargetId        The target id
   * @param soTargetType      The target type
   * @param agvTargetAngle    The angle
   * @param agvTargetDistance The distance
   * @param createTime        The create time
   * @param updateTime        The update time
   */
  public AgvNaviAid(String soAgvId, String soAgvType, String soTargetId, String soTargetType, Double agvTargetAngle,
      Double agvTargetDistance, Timestamp createTime, Timestamp updateTime) {
    super();
    this.soAgvId = soAgvId;
    this.soAgvType = soAgvType;
    this.soTargetId = soTargetId;
    this.soTargetType = soTargetType;
    this.agvTargetAngle = agvTargetAngle;
    this.agvTargetDistance = agvTargetDistance;
    this.createTime = createTime;
    this.updateTime = updateTime;
  }

  public String getSoAgvId() {
    return soAgvId;
  }

  public void setSoAgvId(String soAgvId) {
    this.soAgvId = soAgvId;
  }

  public String getSoAgvType() {
    return soAgvType;
  }

  public void setSoAgvType(String soAgvType) {
    this.soAgvType = soAgvType;
  }

  public String getSoTargetId() {
    return soTargetId;
  }

  public void setSoTargetId(String soTargetId) {
    this.soTargetId = soTargetId;
  }

  public String getSoTargetType() {
    return soTargetType;
  }

  public void setSoTargetType(String soTargetType) {
    this.soTargetType = soTargetType;
  }

  public Double getAgvTargetAngle() {
    return agvTargetAngle;
  }

  public void setAgvTargetAngle(Double agvTargetAngle) {
    this.agvTargetAngle = agvTargetAngle;
  }

  public Double getAgvTargetDistance() {
    return agvTargetDistance;
  }

  public void setAgvTargetDistance(Double agvTargetDistance) {
    this.agvTargetDistance = agvTargetDistance;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

}
