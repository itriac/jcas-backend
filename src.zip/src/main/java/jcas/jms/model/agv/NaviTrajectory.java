package jcas.jms.model.agv;

import java.sql.Timestamp;

/**
 * NaviTrajectory is the class for NaviTrajectory bean.
 *
 * @author Industrial Technology Research Institute
 */
public class NaviTrajectory {
  private Double positionX;
  private Double positionY;
  private Double positionZ;
  private Timestamp createTime;

  public NaviTrajectory() {
    super();
  }

  /**
   * NaviTrajectory constructor.
   *
   * @param positionX  The x position of trajectory
   * @param positionY  The y position of trajectory
   * @param positionZ  The z position of trajectory
   * @param createTime The trajectory create time
   */
  public NaviTrajectory(Double positionX, Double positionY, Double positionZ, Timestamp createTime) {
    super();
    this.positionX = positionX;
    this.positionY = positionY;
    this.positionZ = positionZ;
    this.createTime = createTime;
  }

  public Double getPositionX() {
    return positionX;
  }

  public void setPositionX(Double positionX) {
    this.positionX = positionX;
  }

  public Double getPositionY() {
    return positionY;
  }

  public void setPositionY(Double positionY) {
    this.positionY = positionY;
  }

  public Double getPositionZ() {
    return positionZ;
  }

  public void setPositionZ(Double positionZ) {
    this.positionZ = positionZ;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

}
