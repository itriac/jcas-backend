package jcas.jms.model.agv;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import jcas.jms.api.agv.AgvNaviThread;

/**
 * AgvTransientData is the class for agv transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvTransientData {
  public static ExecutorService executorService = Executors
      .newFixedThreadPool(Runtime.getRuntime().availableProcessors());
  public static Map<String, Boolean> navigatingMap = new ConcurrentHashMap<String, Boolean>();
  public static Map<String, AgvNavi> agvNaviMap = new ConcurrentHashMap<String, AgvNavi>();
  public static Map<String, AgvNaviThread> agvNaviThreadMap = new ConcurrentHashMap<String, AgvNaviThread>();
  public static Map<String, AgvNaviAid> agvNaviAidMap = new ConcurrentHashMap<String, AgvNaviAid>();
  public static Map<String, Boolean> cooperatingMap = new ConcurrentHashMap<String, Boolean>();
}
