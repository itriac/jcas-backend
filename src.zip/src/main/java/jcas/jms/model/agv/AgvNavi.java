package jcas.jms.model.agv;

import java.util.List;

/**
 * AgvNavi is the class for AgvNavi bean.
 *
 * @author Industrial Technology Research Institute
 */
public class AgvNavi {
  private String soAgvId;
  private String soAgvType;
  private String soTargetId;
  private String soTargetType;
  private String targetRegionId;
  private String agvMotion;
  private String naviType;
  private String naviStatus;
  private List<NaviTrajectory> historyTrajectorys;
  private List<NaviRoute> planningRoutes;

  public AgvNavi() {
    super();
  }

  /**
   * AgvNavi constructor.
   *
   * @param soAgvId            The agv id
   * @param soAgvType          The agv type
   * @param soTargetId         The target id
   * @param soTargetType       The target type
   * @param targetRegionId     The target locating region id
   * @param agvMotion          The agv motion
   * @param naviType           The navi type
   * @param naviStatus         The navi status
   * @param historyTrajectorys {@code List<NaviTrajectory>}
   * @param planningRoutes     {@code List<NaviRoute>}
   */
  public AgvNavi(String soAgvId, String soAgvType, String soTargetId, String soTargetType, String targetRegionId,
      String agvMotion, String naviType, String naviStatus, List<NaviTrajectory> historyTrajectorys,
      List<NaviRoute> planningRoutes) {
    super();
    this.soAgvId = soAgvId;
    this.soAgvType = soAgvType;
    this.soTargetId = soTargetId;
    this.soTargetType = soTargetType;
    this.targetRegionId = targetRegionId;
    this.agvMotion = agvMotion;
    this.naviType = naviType;
    this.naviStatus = naviStatus;
    this.historyTrajectorys = historyTrajectorys;
    this.planningRoutes = planningRoutes;
  }

  public String getSoAgvId() {
    return soAgvId;
  }

  public void setSoAgvId(String soAgvId) {
    this.soAgvId = soAgvId;
  }

  public String getSoAgvType() {
    return soAgvType;
  }

  public void setSoAgvType(String soAgvType) {
    this.soAgvType = soAgvType;
  }

  public String getSoTargetId() {
    return soTargetId;
  }

  public void setSoTargetId(String soTargetId) {
    this.soTargetId = soTargetId;
  }

  public String getSoTargetType() {
    return soTargetType;
  }

  public void setSoTargetType(String soTargetType) {
    this.soTargetType = soTargetType;
  }

  public String getTargetRegionId() {
    return targetRegionId;
  }

  public void setTargetRegionId(String targetRegionId) {
    this.targetRegionId = targetRegionId;
  }

  public String getAgvMotion() {
    return agvMotion;
  }

  public void setAgvMotion(String agvMotion) {
    this.agvMotion = agvMotion;
  }

  public String getNaviType() {
    return naviType;
  }

  public void setNaviType(String naviType) {
    this.naviType = naviType;
  }

  public String getNaviStatus() {
    return naviStatus;
  }

  public void setNaviStatus(String naviStatus) {
    this.naviStatus = naviStatus;
  }

  public List<NaviTrajectory> getHistoryTrajectorys() {
    return historyTrajectorys;
  }

  public void setHistoryTrajectorys(List<NaviTrajectory> historyTrajectorys) {
    this.historyTrajectorys = historyTrajectorys;
  }

  public List<NaviRoute> getPlanningRoutes() {
    return planningRoutes;
  }

  public void setPlanningRoutes(List<NaviRoute> planningRoutes) {
    this.planningRoutes = planningRoutes;
  }

}
