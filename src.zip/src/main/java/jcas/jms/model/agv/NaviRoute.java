package jcas.jms.model.agv;

import java.sql.Timestamp;
import java.util.List;

/**
 * NaviRoute is the class for NaviRoute bean.
 *
 * @author Industrial Technology Research Institute
 */
public class NaviRoute {
  private List<RoutePoint> routePoints;
  private Timestamp createTime;

  public NaviRoute() {
    super();
  }

  /**
   * NaviRoute constructor.
   *
   * @param routePoints {@code List<RoutePoint>}
   * @param createTime  The route create time
   */
  public NaviRoute(List<RoutePoint> routePoints, Timestamp createTime) {
    super();
    this.routePoints = routePoints;
    this.createTime = createTime;
  }

  public List<RoutePoint> getRoutePoints() {
    return routePoints;
  }

  public void setRoutePoints(List<RoutePoint> routePoints) {
    this.routePoints = routePoints;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

}
