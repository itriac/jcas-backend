package jcas.jms.model.mode;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ModeTransientData is the class for mode transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class ModeTransientData {
  public static Map<String, Boolean> mmWPostureMap = new ConcurrentHashMap<String, Boolean>();
  public static Map<String, Boolean> csiPostureMap = new ConcurrentHashMap<String, Boolean>();

  public static Map<String, Boolean> lotteryMap = new ConcurrentHashMap<String, Boolean>();
  public static Map<String, Boolean> robotNaviMap = new ConcurrentHashMap<String, Boolean>();

  public static long POSTURE_SUPPRESSION_TIME = 500;

  public static String DOG_1_STATUS = "";
  public static String DOG_2_STATUS = "";
}
