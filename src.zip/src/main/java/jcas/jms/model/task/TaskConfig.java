package jcas.jms.model.task;

import java.sql.Timestamp;

/**
 * TaskConfig is the class for TaskConfig bean.
 *
 * @author Industrial Technology Research Institute
 */
public class TaskConfig {
  private Integer taskConfigId;
  private String taskName;
  private Integer taskPriority;
  private Integer taskLatencyMs;
  private Integer cpuMinCore;
  private Long gpuMinByte;
  private Long memoryMinByte;
  private Boolean taskPowerPlugged;
  private Timestamp createTime;
  private Timestamp updateTime;
  private String taskConfigInfo;

  public TaskConfig() {
    super();
  }

  /**
   * TaskConfig constructor.
   *
   * @param taskConfigId     The task config id
   * @param taskName         The task name
   * @param taskPriority     The task priority
   * @param taskLatencyMs    The task latency
   * @param cpuMinCore       The cpu prerequisite of task exec
   * @param gpuMinByte       The gpu prerequisite of task exec
   * @param memoryMinByte    The memory prerequisite of task exec
   * @param taskPowerPlugged The power plugged prerequisite of task exec
   * @param createTime       The task config create time
   * @param updateTime       The task config update time
   * @param taskConfigInfo   For extension use
   */
  public TaskConfig(Integer taskConfigId, String taskName, Integer taskPriority, Integer taskLatencyMs,
      Integer cpuMinCore, Long gpuMinByte, Long memoryMinByte, Boolean taskPowerPlugged, Timestamp createTime,
      Timestamp updateTime, String taskConfigInfo) {
    super();
    this.taskConfigId = taskConfigId;
    this.taskName = taskName;
    this.taskPriority = taskPriority;
    this.taskLatencyMs = taskLatencyMs;
    this.cpuMinCore = cpuMinCore;
    this.gpuMinByte = gpuMinByte;
    this.memoryMinByte = memoryMinByte;
    this.taskPowerPlugged = taskPowerPlugged;
    this.createTime = createTime;
    this.updateTime = updateTime;
    this.taskConfigInfo = taskConfigInfo;
  }

  public Integer getTaskConfigId() {
    return taskConfigId;
  }

  public void setTaskConfigId(Integer taskConfigId) {
    this.taskConfigId = taskConfigId;
  }

  public String getTaskName() {
    return taskName;
  }

  public void setTaskName(String taskName) {
    this.taskName = taskName;
  }

  public Integer getTaskPriority() {
    return taskPriority;
  }

  public void setTaskPriority(Integer taskPriority) {
    this.taskPriority = taskPriority;
  }

  public Integer getTaskLatencyMs() {
    return taskLatencyMs;
  }

  public void setTaskLatencyMs(Integer taskLatencyMs) {
    this.taskLatencyMs = taskLatencyMs;
  }

  public Integer getCpuMinCore() {
    return cpuMinCore;
  }

  public void setCpuMinCore(Integer cpuMinCore) {
    this.cpuMinCore = cpuMinCore;
  }

  public Long getGpuMinByte() {
    return gpuMinByte;
  }

  public void setGpuMinByte(Long gpuMinByte) {
    this.gpuMinByte = gpuMinByte;
  }

  public Long getMemoryMinByte() {
    return memoryMinByte;
  }

  public void setMemoryMinByte(Long memoryMinByte) {
    this.memoryMinByte = memoryMinByte;
  }

  public Boolean getTaskPowerPlugged() {
    return taskPowerPlugged;
  }

  public void setTaskPowerPlugged(Boolean taskPowerPlugged) {
    this.taskPowerPlugged = taskPowerPlugged;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  public String getTaskConfigInfo() {
    return taskConfigInfo;
  }

  public void setTaskConfigInfo(String taskConfigInfo) {
    this.taskConfigInfo = taskConfigInfo;
  }

}
