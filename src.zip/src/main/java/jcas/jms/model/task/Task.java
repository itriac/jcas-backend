package jcas.jms.model.task;

import java.sql.Timestamp;

/**
 * Task is the class for Task bean.
 *
 * @author Industrial Technology Research Institute
 */
public class Task {
  private String taskId;
  private Integer taskConfigId;
  private String cnSourceId;
  private String cnExecId;
  private String taskAction;
  private Integer cpuUsedCore;
  private Long gpuUsedByte;
  private Long memoryUsedByte;
  // private Integer nicUsedBit;
  private Double cnSourceUsedPowerW;
  // private Double nicUsedPowerW;
  private Double cnExecUsedPowerW;
  private Integer execTimeMs;
  private String execResult;
  private String taskStatus;
  private Timestamp createTime;
  private Timestamp updateTime;

  public Task() {
    super();
  }

  /**
   * Task constructor.
   *
   * @param taskId             The task id
   * @param taskConfigId       The task config id
   * @param cnSourceId         The task source node id
   * @param cnExecId           The task exec node id
   * @param taskAction         The task action
   * @param cpuUsedCore        The used cpu of task exec
   * @param gpuUsedByte        The used gpu of task exec
   * @param memoryUsedByte     The used memory of task exec
   * @param cnSourceUsedPowerW The used power of task exec in source node
   * @param cnExecUsedPowerW   The used power of task exec in exec node
   * @param execTimeMs         The task exec time
   * @param execResult         The task exec result
   * @param taskStatus         The task status
   * @param createTime         The task create time
   * @param updateTime         The task update time
   */
  public Task(String taskId, Integer taskConfigId, String cnSourceId, String cnExecId, String taskAction,
      Integer cpuUsedCore, Long gpuUsedByte, Long memoryUsedByte, Double cnSourceUsedPowerW, Double cnExecUsedPowerW,
      Integer execTimeMs, String execResult, String taskStatus, Timestamp createTime, Timestamp updateTime) {
    super();
    this.taskId = taskId;
    this.taskConfigId = taskConfigId;
    this.cnSourceId = cnSourceId;
    this.cnExecId = cnExecId;
    this.taskAction = taskAction;
    this.cpuUsedCore = cpuUsedCore;
    this.gpuUsedByte = gpuUsedByte;
    this.memoryUsedByte = memoryUsedByte;
    // this.nicUsedBit = nicUsedBit;
    this.cnSourceUsedPowerW = cnSourceUsedPowerW;
    // this.nicUsedPowerW = nicUsedPowerW;
    this.cnExecUsedPowerW = cnExecUsedPowerW;
    this.execTimeMs = execTimeMs;
    this.execResult = execResult;
    this.taskStatus = taskStatus;
    this.createTime = createTime;
    this.updateTime = updateTime;
  }

  public String getTaskId() {
    return taskId;
  }

  public void setTaskId(String taskId) {
    this.taskId = taskId;
  }

  public Integer getTaskConfigId() {
    return taskConfigId;
  }

  public void setTaskConfigId(Integer taskConfigId) {
    this.taskConfigId = taskConfigId;
  }

  public String getCnSourceId() {
    return cnSourceId;
  }

  public void setCnSourceId(String cnSourceId) {
    this.cnSourceId = cnSourceId;
  }

  public String getCnExecId() {
    return cnExecId;
  }

  public void setCnExecId(String cnExecId) {
    this.cnExecId = cnExecId;
  }

  public String getTaskAction() {
    return taskAction;
  }

  public void setTaskAction(String taskAction) {
    this.taskAction = taskAction;
  }

  public Integer getCpuUsedCore() {
    return cpuUsedCore;
  }

  public void setCpuUsedCore(Integer cpuUsedCore) {
    this.cpuUsedCore = cpuUsedCore;
  }

  public Long getGpuUsedByte() {
    return gpuUsedByte;
  }

  public void setGpuUsedByte(Long gpuUsedByte) {
    this.gpuUsedByte = gpuUsedByte;
  }

  public Long getMemoryUsedByte() {
    return memoryUsedByte;
  }

  public void setMemoryUsedByte(Long memoryUsedByte) {
    this.memoryUsedByte = memoryUsedByte;
  }

  // public Integer getNicUsedBit() {
  // return nicUsedBit;
  // }

  // public void setNicUsedBit(Integer nicUsedBit) {
  // this.nicUsedBit = nicUsedBit;
  // }

  public Double getCnSourceUsedPowerW() {
    return cnSourceUsedPowerW;
  }

  public void setCnSourceUsedPowerW(Double cnSourceUsedPowerW) {
    this.cnSourceUsedPowerW = cnSourceUsedPowerW;
  }

  // public Double getNicUsedPowerW() {
  // return nicUsedPowerW;
  // }

  // public void setNicUsedPowerW(Double nicUsedPowerW) {
  // this.nicUsedPowerW = nicUsedPowerW;
  // }

  public Double getCnExecUsedPowerW() {
    return cnExecUsedPowerW;
  }

  public void setCnExecUsedPowerW(Double cnExecUsedPowerW) {
    this.cnExecUsedPowerW = cnExecUsedPowerW;
  }

  public Integer getExecTimeMs() {
    return execTimeMs;
  }

  public void setExecTimeMs(Integer execTimeMs) {
    this.execTimeMs = execTimeMs;
  }

  public String getExecResult() {
    return execResult;
  }

  public void setExecResult(String execResult) {
    this.execResult = execResult;
  }

  public String getTaskStatus() {
    return taskStatus;
  }

  public void setTaskStatus(String taskStatus) {
    this.taskStatus = taskStatus;
  }

  public Timestamp getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  public Timestamp getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

}
