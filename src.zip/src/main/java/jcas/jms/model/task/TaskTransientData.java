package jcas.jms.model.task;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * TaskTransientData is the class for task transient data.
 *
 * @author Industrial Technology Research Institute
 */
public class TaskTransientData {
  public static Map<String, TaskConfig> taskConfigMap = new ConcurrentHashMap<String, TaskConfig>();
  public static Map<String, Task> taskMap = new ConcurrentHashMap<String, Task>();
}
