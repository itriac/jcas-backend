package jcas.jms.model.task;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import jcas.jms.db.DbManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * TaskConfigService is the class for task db management.
 *
 * @author Industrial Technology Research Institute
 */
@Component
public class TaskConfigService {
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskConfigService.class);
  private DbManager dbm;

  public TaskConfigService(@Autowired DbManager dbm) {
    this.dbm = dbm;
  }

  /**
   * Gets TaskConfig list from db.
   *
   * @return {@code List<TaskConfig>}
   */
  public List<TaskConfig> getTaskConfigList() {
    List<TaskConfig> taskConfigList = new ArrayList<TaskConfig>();
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "SELECT * FROM task_conf";
      ps = dbm.createPreparedStatement(sql, con);
      ResultSet rs = dbm.select(ps, con);
      while (rs.next()) {
        TaskConfig taskConfig = new TaskConfig(rs.getInt("task_conf_id"), rs.getString("task_name"),
            rs.getInt("task_priority"), rs.getInt("task_latency_ms"), rs.getInt("cpu_min_core"),
            rs.getLong("gpu_min_byte"), rs.getLong("memory_min_byte"), rs.getBoolean("task_power_plugged"),
            rs.getTimestamp("create_time"), rs.getTimestamp("update_time"), rs.getString("task_conf_info"));
        taskConfigList.add(taskConfig);
      }
      dbm.closePreparedStatement(ps);
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return taskConfigList;
  }

  /**
   * Adds TaskConfig into db.
   *
   * @param taskConfig {@code TaskConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean addTaskConfig(TaskConfig taskConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "INSERT INTO task_conf (`task_name`, `task_priority`, `task_latency_ms`, `cpu_min_core`, "
          + "`gpu_min_byte`, `memory_min_byte`, `task_power_plugged`, `create_time`, `update_time`, "
          + "`task_conf_info`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(taskConfig.getTaskName());
      data.add(taskConfig.getTaskPriority());
      data.add(taskConfig.getTaskLatencyMs());
      data.add(taskConfig.getCpuMinCore());
      data.add(taskConfig.getGpuMinByte());
      data.add(taskConfig.getMemoryMinByte());
      if (taskConfig.getTaskPowerPlugged()) {
        data.add(1);
      } else {
        data.add(0);
      }
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      data.add(nowTime);
      data.add(taskConfig.getTaskConfigInfo());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Add TaskConfig Success: " + taskConfig.getTaskName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Updates TaskConfig into db.
   *
   * @param taskConfig {@code TaskConfig}
   * @return {@code true} succeed; {@code false} fail
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Boolean updateTaskConfig(TaskConfig taskConfig) {
    Boolean result = false;
    PreparedStatement ps;
    Connection con = null;
    try {
      con = dbm.getConnection();
      String sql = "UPDATE task_conf SET task_priority=?, task_latency_ms=?, cpu_min_core=?, gpu_min_byte=?, "
          + "memory_min_byte=?, task_power_plugged=?, update_time=?, task_conf_info=? WHERE task_conf_id=?";
      ps = dbm.createPreparedStatement(sql, con);
      ArrayList data = new ArrayList();
      data.add(taskConfig.getTaskPriority());
      data.add(taskConfig.getTaskLatencyMs());
      data.add(taskConfig.getCpuMinCore());
      data.add(taskConfig.getGpuMinByte());
      data.add(taskConfig.getMemoryMinByte());
      if (taskConfig.getTaskPowerPlugged()) {
        data.add(1);
      } else {
        data.add(0);
      }
      Date date = new Date();
      Timestamp nowTime = new Timestamp(date.getTime());
      data.add(nowTime);
      data.add(taskConfig.getTaskConfigInfo());
      data.add(taskConfig.getTaskConfigId());
      dbm.update(ps, data);
      dbm.closePreparedStatement(ps);
      LOGGER.info("Update TaskConfig Success: " + taskConfig.getTaskName());
      result = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }

  /**
   * Deletes TaskConfig from db.
   *
   * @param taskConfigIds The task config ids
   * @return {@code true} succeed; {@code false} fail
   */
  public Boolean deleteTaskConfig(String taskConfigIds) {
    Boolean result = false;
    PreparedStatement ps;
    List<String> taskConfigIdList = Arrays.asList(taskConfigIds.split(","));
    Connection con = null;
    try {
      con = dbm.getConnection();
      for (String taskConfigId : taskConfigIdList) {
        String sql = "DELETE FROM task_conf WHERE task_conf_id=?";
        ps = dbm.createPreparedStatement(sql, con);
        ArrayList<String> data = new ArrayList<String>();
        data.add(taskConfigId);
        dbm.update(ps, data);
        dbm.closePreparedStatement(ps);
        LOGGER.info("Delete TaskConfig Success: " + taskConfigId);
        result = true;
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage());
    } finally {
      dbm.closeConnection(con);
    }
    return result;
  }
}
