/**
 * Copyright (C) 2023-2023 Information & Communications Research Laboratories, Industrial Technology
 * Research Institute.
 */
package jcas.jms;