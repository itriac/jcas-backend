package jcas.jms.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.servlet.http.HttpServlet;
import jcas.jms.mqtt.MqttAgent;
import jcas.jms.scheduler.SchedulerManager;
import jcas.jms.util.TransientDataUtil;
import org.apache.log4j.PropertyConfigurator;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.ini4j.Wini;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * WebConfig is the class to setup web configuration.
 *
 * @author Industrial Technology Research Institute
 */
@Configuration
@ComponentScan(basePackages = { "jcas" })
@PropertySource("classpath:jcas.properties")
public class WebConfig extends HttpServlet {
  private static final long serialVersionUID = 1L;
  private static final Logger LOGGER = LoggerFactory.getLogger(WebConfig.class);
  private static boolean schedulerInited = false;

  // TOMCAT JDBC Pool
  @Value("${db.url}")
  private String dbUrl;
  @Value("${db.username}")
  private String dbUsername;
  @Value("${db.password}")
  private String dbPassword;

  /**
   * Creates DataSource.
   *
   * @return {@code DataSource}
   */
  @Bean
  public DataSource getDataSource() {
    PoolProperties poolProperties = new PoolProperties();
    poolProperties.setUrl(dbUrl);
    poolProperties.setDriverClassName("com.mysql.cj.jdbc.Driver");
    poolProperties.setUsername(dbUsername);
    poolProperties.setPassword(dbPassword);
    poolProperties.setJmxEnabled(true);
    poolProperties.setTestWhileIdle(false);
    poolProperties.setTestOnBorrow(true);
    poolProperties.setValidationQuery("SELECT 1");
    poolProperties.setTestOnReturn(false);
    poolProperties.setValidationInterval(30000);
    poolProperties.setTimeBetweenEvictionRunsMillis(30000);
    poolProperties.setMaxActive(100);
    poolProperties.setInitialSize(10);
    poolProperties.setMaxWait(10000);
    poolProperties.setRemoveAbandonedTimeout(60);
    poolProperties.setMinEvictableIdleTimeMillis(30000);
    poolProperties.setMinIdle(10);
    poolProperties.setLogAbandoned(true);
    poolProperties.setRemoveAbandoned(true);
    poolProperties.setJdbcInterceptors("org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
        + "org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer;"
        + "org.apache.tomcat.jdbc.pool.interceptor.ResetAbandonedTimer");
    DataSource datasource = new DataSource();
    datasource.setPoolProperties(poolProperties);
    return datasource;
  }

  @Bean
  public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
    return new PropertySourcesPlaceholderConfigurer();
  }

  @Override
  public void init() {
    initScheduler();
    String realPath = getServletContext().getRealPath("/");
    LOGGER.info("Real Path: " + realPath);
    System.setProperty("realPath", realPath);
    try {
      Properties logProperties = new Properties();
      FileInputStream fiStream = new FileInputStream(
          realPath + "WEB-INF" + File.separator + "classes" + File.separator + "log4j.properties");
      logProperties.load(fiStream);
      fiStream.close();
      PropertyConfigurator.configure(logProperties);
      LOGGER.info("Log4j Init");

      Wini ini = new Wini(new File(realPath + "WEB-INF" + File.separator + "api.properties"));
      String hostUrl = ini.get("API", "host.url");
      LOGGER.info("Host URL: " + hostUrl);
      System.setProperty("hostUrl", hostUrl + "/jms");
      String projectVersion = ini.get("API", "project.version");
      LOGGER.info("Project Version: " + projectVersion);
      System.setProperty("projectVersion", projectVersion);
      String homePath = ini.get("ENV", "home.path");
      LOGGER.info("Home Path: " + homePath);
      System.setProperty("homePath", homePath);
      // MQTT
      String mqttEnable = ini.get("MQTT", "mqtt.enable");
      LOGGER.info("MQTT Enable: " + mqttEnable);
      System.setProperty("mqttEnable", mqttEnable);
      String mqttServer = ini.get("MQTT", "mqtt.server");
      LOGGER.info("MQTT Server: " + mqttServer);
      System.setProperty("mqttServer", mqttServer);
      String mqttPort = ini.get("MQTT", "mqtt.port");
      LOGGER.info("MQTT Port: " + mqttPort);
      System.setProperty("mqttPort", mqttPort);
      String mqttAccount = ini.get("MQTT", "mqtt.account");
      LOGGER.info("MQTT Account: " + mqttAccount);
      System.setProperty("mqttAccount", mqttAccount);
      String mqttPassword = ini.get("MQTT", "mqtt.password");
      LOGGER.info("MQTT Password: " + mqttPassword);
      System.setProperty("mqttPassword", mqttPassword);
      String mqttTopic = ini.get("MQTT", "mqtt.topic");
      LOGGER.info("MQTT Topic: " + mqttTopic);
      System.setProperty("mqttTopic", mqttTopic);
      MqttAgent.getInstance().executeMqttSubscribe("k300_dog_1/status");
      MqttAgent.getInstance().executeMqttSubscribe("k300_dog_2/status");
      LOGGER.info("MQTT Subscribed to topics for DOG status updates.");
      TransientDataUtil.refreshCnConfigMap();
      TransientDataUtil.refreshCnMap();
      TransientDataUtil.refreshTaskConfigMap();
      TransientDataUtil.refreshRegionMap();
      TransientDataUtil.refreshSupportedEventMap();
      TransientDataUtil.refreshEventConfigMap();
      TransientDataUtil.refreshUnfinishedEventMap();
      TransientDataUtil.refreshModeMap();
    } catch (IOException e) {
      LOGGER.error(e.getMessage());
    }
  }

  private void initScheduler() {
    if (!schedulerInited) {
      SchedulerManager sm = new SchedulerManager();
      sm.initScheduleJobs();
      schedulerInited = true;
      LOGGER.info("Scheduler Init");
    }
  }

}
