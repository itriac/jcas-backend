package jcas.jms.config;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * I18nFilter is the class to wrapper request.
 *
 * @author Industrial Technology Research Institute
 */
public class I18nFilter implements Filter {

  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
      FilterChain filterChain) throws IOException, ServletException {
    HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
    I18nRequestWrapper request = new I18nRequestWrapper(httpServletRequest);
    filterChain.doFilter(request, servletResponse);
  }

}