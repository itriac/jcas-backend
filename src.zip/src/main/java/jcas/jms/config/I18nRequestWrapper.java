package jcas.jms.config;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;

/**
 * I18nRequestWrapper is the class to use session locale to replace request's.
 *
 * @author Industrial Technology Research Institute
 */
public class I18nRequestWrapper extends HttpServletRequestWrapper {
  private Locale sessionLocale = null;

  /**
   * I18nRequestWrapper constructor.
   *
   * @param request {@code HttpServletRequest}
   */
  public I18nRequestWrapper(HttpServletRequest request) {
    super(request);
    Locale requestLocale = request.getLocale();
    HttpSession session = request.getSession();
    sessionLocale = (Locale) session.getAttribute("WW_TRANS_I18N_LOCALE");
    if (sessionLocale == null && !requestLocale.toString().isEmpty()) {
      sessionLocale = requestLocale;
    }
    session.setAttribute("WW_TRANS_I18N_LOCALE", sessionLocale);
  }

  @Override
  public Locale getLocale() {
    // Changes to session locale
    if (sessionLocale != null) {
      return sessionLocale;
    }
    return super.getLocale();
  }
}
